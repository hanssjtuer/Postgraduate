import csv
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import scipy as stats
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller
from scipy import stats
from statsmodels.tsa.arima_model import ARIMA
df=pd.read_csv('CCFI.csv',index_col='Date')
#读取数据
df.head()
df.index = pd.to_datetime(df.index)   #进行索引
df.index
ts=df['CCFI']  #时间序列的变量为"CCFI"，并赋值给"ts "
ts.head()  #读出CCFI的前5个数据
#print(ts)

#绘制趋势图
plt.rcParams['font.sans-serif'] = ['simhei']  #用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False #用来正常显示负号
ts.plot()
plt.title("CCFI change")  #添加图标题
plt.xticks(rotation=45)    #横坐标旋转45度
plt.xlabel('Date')   #添加图的标签（x轴，y轴）
plt.ylabel('CCFI')

#绘制自相关图
from statsmodels.graphics.tsaplots import plot_acf #导入自相关函数
plot_acf(ts,use_vlines=True,lags=30)  #绘制出原始数据"ts"的自相关图
plt.show()  #展示原始数据"ts"的自相关图

#ADF检验结果
CCFI = df['CCFI']
adf_result = adfuller(CCFI)
print('原始序列的ADF检验结果为：')
print(adf_result)
#print(adf_result[1])

# 差分计算
# 进行一阶差分
D_ts = ts.diff().dropna()   #对"ts数列"进行差分
D_ts.columns = [u'差分']
# 绘制差分后时序图
D_ts.plot()  #绘制出差分后的时序图
plt.title("CCFI差分")  #添加图标题
plt.show()   #展示差分后的时序图

from statsmodels.graphics.tsaplots import plot_acf #导入自相关函数 # 绘制差分后自相关图与偏自相关图
plot_acf(D_ts,use_vlines=True,lags=30)  #"lags"自相关函数的滞后取值范围，此处之后30阶，绘制出原始数据"ts"的自相关图
plt.show() #展示差分后数据"D_ts"的自相关图

from statsmodels.graphics.tsaplots import plot_pacf  #导入偏自相关函数
plot_pacf(D_ts,use_vlines=True,lags=30) #"lags"偏自相关函数的滞后取值范围，此处之后30阶，绘制出原始数据"ts"的自相关图
plt.show()  #展示差分后数据"D_ts"的偏自相关图

#一阶差分后的ADF检验
new_CCFI = D_ts
adf_result1 = adfuller(new_CCFI)
print('一阶差分后的ADF检验结果为：')
print(adf_result1)
#print(adf_result1[1])

# 对一阶差分后数据进行白噪声检验
from statsmodels.tsa import stattools #对差分后达到平稳的数据进行白噪声检验
LjungBox=stattools.q_stat(stattools.acf(D_ts)[1:12],len(D_ts)) #展示白噪声检验结果，返回统计量和p值
print(LjungBox[1][-1])


from statsmodels.tsa.arima.model import ARIMA
model = ARIMA(D_ts, order=(1,1,2)).fit()
print('模型报告为：\n', model.summary())
print('预测未来5个月，其预测结果、标准误差、置信区间如下：\n', model.forecast(5))
