﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Media3D;

namespace WindowsFormsApp1
{
    /// <summary>
    /// UserControl1.xaml 的交互逻辑
    /// </summary>
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }

        public void ChangCoordinateOfFace3(double x,double y,double z)
        {
            Point3DCollection myVertices = new Point3DCollection();
            Point3D myVertex1 = new Point3D(0.1*x, 0.1*y, 0.1*z);
            Point3D myVertex2 = new Point3D(0.1*(x+1), 0.1*y, 0.1*z);
            Point3D myVertex3 = new Point3D(0.1*x, 0.1*(y+1), 0.1*z);
            myVertices.Add(myVertex1);
            myVertices.Add(myVertex2);
            myVertices.Add(myVertex3);
            Face3.Positions = myVertices;
        }
        public void ChangCoordinateOfBaseB(double x, double y, double z)
        {
            Point3DCollection myVertices = new Point3DCollection();
            Point3D myVertex1 = new Point3D(0.1 * x, 0.1 * y, 0.1 * z);
            Point3D myVertex2 = new Point3D(0.1 * (x + 1), 0.1 * y, 0.1 * z);
            Point3D myVertex3 = new Point3D(0.1 * x, 0.1 * (y + 1), 0.1 * z);
            myVertices.Add(myVertex1);
            myVertices.Add(myVertex2);
            myVertices.Add(myVertex3);
            BaseB.Positions = myVertices;
        }
        public void ChangCoordinateOfBaseC(double x, double y, double z)
        {
            Point3DCollection myVertices = new Point3DCollection();
            Point3D myVertex1 = new Point3D(0.1 * x, 0.1 * y, 0.1 * z);
            Point3D myVertex2 = new Point3D(0.1 * (x + 1), 0.1 * y, 0.1 * z);
            Point3D myVertex3 = new Point3D(0.1 * x, 0.1 * (y + 1), 0.1 * z);
            myVertices.Add(myVertex1);
            myVertices.Add(myVertex2);
            myVertices.Add(myVertex3);
            BaseC.Positions = myVertices;
        }
        public void ChangCoordinateOfBaseD(double x, double y, double z)
        {
            Point3DCollection myVertices = new Point3DCollection();
            Point3D myVertex1 = new Point3D(0.1 * x, 0.1 * y, 0.1 * z);
            Point3D myVertex2 = new Point3D(0.1 * (x + 1), 0.1 * y, 0.1 * z);
            Point3D myVertex3 = new Point3D(0.1 * x, 0.1 * (y + 1), 0.1 * z);
            myVertices.Add(myVertex1);
            myVertices.Add(myVertex2);
            myVertices.Add(myVertex3);
            BaseD.Positions = myVertices;
        }
    }
}
