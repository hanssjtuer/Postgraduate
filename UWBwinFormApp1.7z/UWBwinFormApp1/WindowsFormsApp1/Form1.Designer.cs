﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            this.elementHost1 = new System.Windows.Forms.Integration.ElementHost();
            this.userControl1 = new WindowsFormsApp1.UserControl1();
            this.dataGridView_BS_SET = new System.Windows.Forms.DataGridView();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.x = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.y = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.z = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView_TAG = new System.Windows.Forms.DataGridView();
            this.TAG_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DW_X = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DW_Y = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DW_Z = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DIS_A = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DIS_B = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DIS_C = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DIS_D = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnWrite = new System.Windows.Forms.Button();
            this.btnRead = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.comboSerial = new System.Windows.Forms.ComboBox();
            this.timer_connect_Flag = new System.Windows.Forms.Timer(this.components);
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.timer_MODBUS_connet = new System.Windows.Forms.Timer(this.components);
            this.timer_display = new System.Windows.Forms.Timer(this.components);
            this.timer_DW = new System.Windows.Forms.Timer(this.components);
            this.timer_state = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_BS_SET)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_TAG)).BeginInit();
            this.SuspendLayout();
            // 
            // elementHost1
            // 
            this.elementHost1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.elementHost1.Location = new System.Drawing.Point(323, 12);
            this.elementHost1.Name = "elementHost1";
            this.elementHost1.Size = new System.Drawing.Size(782, 455);
            this.elementHost1.TabIndex = 1;
            this.elementHost1.Text = "elementHost1";
            this.elementHost1.ChildChanged += new System.EventHandler<System.Windows.Forms.Integration.ChildChangedEventArgs>(this.elementHost1_ChildChanged);
            this.elementHost1.Child = this.userControl1;
            // 
            // dataGridView_BS_SET
            // 
            this.dataGridView_BS_SET.AllowUserToAddRows = false;
            this.dataGridView_BS_SET.AllowUserToDeleteRows = false;
            this.dataGridView_BS_SET.AllowUserToResizeColumns = false;
            this.dataGridView_BS_SET.AllowUserToResizeRows = false;
            this.dataGridView_BS_SET.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridView_BS_SET.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_BS_SET.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.name,
            this.x,
            this.y,
            this.z});
            this.dataGridView_BS_SET.EnableHeadersVisualStyles = false;
            this.dataGridView_BS_SET.Location = new System.Drawing.Point(48, 319);
            this.dataGridView_BS_SET.MultiSelect = false;
            this.dataGridView_BS_SET.Name = "dataGridView_BS_SET";
            this.dataGridView_BS_SET.RowHeadersVisible = false;
            this.dataGridView_BS_SET.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView_BS_SET.RowTemplate.Height = 23;
            this.dataGridView_BS_SET.Size = new System.Drawing.Size(225, 120);
            this.dataGridView_BS_SET.TabIndex = 25;
            this.dataGridView_BS_SET.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_BS_SET_CellContentClick);
            // 
            // name
            // 
            dataGridViewCellStyle25.Format = "N0";
            dataGridViewCellStyle25.NullValue = "0";
            this.name.DefaultCellStyle = dataGridViewCellStyle25;
            this.name.HeaderText = "基站  ID";
            this.name.Name = "name";
            this.name.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.name.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.name.Width = 70;
            // 
            // x
            // 
            dataGridViewCellStyle26.Format = "N0";
            dataGridViewCellStyle26.NullValue = "0";
            this.x.DefaultCellStyle = dataGridViewCellStyle26;
            this.x.HeaderText = "  X轴   (cm)";
            this.x.Name = "x";
            this.x.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.x.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.x.Width = 50;
            // 
            // y
            // 
            dataGridViewCellStyle27.Format = "N0";
            dataGridViewCellStyle27.NullValue = "0";
            this.y.DefaultCellStyle = dataGridViewCellStyle27;
            this.y.HeaderText = "  Y轴   (cm)";
            this.y.Name = "y";
            this.y.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.y.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.y.Width = 50;
            // 
            // z
            // 
            dataGridViewCellStyle28.Format = "N0";
            dataGridViewCellStyle28.NullValue = "0";
            this.z.DefaultCellStyle = dataGridViewCellStyle28;
            this.z.HeaderText = "  Z轴   (cm)";
            this.z.Name = "z";
            this.z.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.z.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.z.Width = 50;
            // 
            // dataGridView_TAG
            // 
            this.dataGridView_TAG.AllowUserToAddRows = false;
            this.dataGridView_TAG.AllowUserToDeleteRows = false;
            this.dataGridView_TAG.AllowUserToResizeColumns = false;
            this.dataGridView_TAG.AllowUserToResizeRows = false;
            this.dataGridView_TAG.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridView_TAG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_TAG.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TAG_ID,
            this.DW_X,
            this.DW_Y,
            this.DW_Z,
            this.DIS_A,
            this.DIS_B,
            this.DIS_C,
            this.DIS_D});
            this.dataGridView_TAG.EnableHeadersVisualStyles = false;
            this.dataGridView_TAG.Location = new System.Drawing.Point(444, 485);
            this.dataGridView_TAG.MultiSelect = false;
            this.dataGridView_TAG.Name = "dataGridView_TAG";
            this.dataGridView_TAG.RowHeadersVisible = false;
            this.dataGridView_TAG.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView_TAG.RowTemplate.Height = 23;
            this.dataGridView_TAG.Size = new System.Drawing.Size(538, 49);
            this.dataGridView_TAG.TabIndex = 24;
            // 
            // TAG_ID
            // 
            dataGridViewCellStyle29.Format = "N0";
            this.TAG_ID.DefaultCellStyle = dataGridViewCellStyle29;
            this.TAG_ID.HeaderText = "TAG ID";
            this.TAG_ID.Name = "TAG_ID";
            this.TAG_ID.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.TAG_ID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TAG_ID.Width = 62;
            // 
            // DW_X
            // 
            dataGridViewCellStyle30.Format = "N0";
            dataGridViewCellStyle30.NullValue = "0";
            this.DW_X.DefaultCellStyle = dataGridViewCellStyle30;
            this.DW_X.HeaderText = "X轴  (cm)";
            this.DW_X.Name = "DW_X";
            this.DW_X.ReadOnly = true;
            this.DW_X.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DW_X.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DW_X.Width = 67;
            // 
            // DW_Y
            // 
            dataGridViewCellStyle31.Format = "N0";
            dataGridViewCellStyle31.NullValue = "0";
            this.DW_Y.DefaultCellStyle = dataGridViewCellStyle31;
            this.DW_Y.HeaderText = "Y轴  (cm)";
            this.DW_Y.Name = "DW_Y";
            this.DW_Y.ReadOnly = true;
            this.DW_Y.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DW_Y.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DW_Y.Width = 67;
            // 
            // DW_Z
            // 
            dataGridViewCellStyle32.Format = "N0";
            dataGridViewCellStyle32.NullValue = "0";
            this.DW_Z.DefaultCellStyle = dataGridViewCellStyle32;
            this.DW_Z.HeaderText = "Z轴  (cm)";
            this.DW_Z.Name = "DW_Z";
            this.DW_Z.ReadOnly = true;
            this.DW_Z.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DW_Z.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DW_Z.Width = 67;
            // 
            // DIS_A
            // 
            dataGridViewCellStyle33.Format = "N0";
            dataGridViewCellStyle33.NullValue = "0";
            this.DIS_A.DefaultCellStyle = dataGridViewCellStyle33;
            this.DIS_A.HeaderText = "A基站  (cm)";
            this.DIS_A.Name = "DIS_A";
            this.DIS_A.ReadOnly = true;
            this.DIS_A.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DIS_A.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DIS_A.Width = 68;
            // 
            // DIS_B
            // 
            dataGridViewCellStyle34.Format = "N0";
            dataGridViewCellStyle34.NullValue = "0";
            this.DIS_B.DefaultCellStyle = dataGridViewCellStyle34;
            this.DIS_B.HeaderText = "B基站  (cm)";
            this.DIS_B.Name = "DIS_B";
            this.DIS_B.ReadOnly = true;
            this.DIS_B.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DIS_B.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DIS_B.Width = 68;
            // 
            // DIS_C
            // 
            dataGridViewCellStyle35.Format = "N0";
            dataGridViewCellStyle35.NullValue = "0";
            this.DIS_C.DefaultCellStyle = dataGridViewCellStyle35;
            this.DIS_C.HeaderText = "C基站  (cm)";
            this.DIS_C.Name = "DIS_C";
            this.DIS_C.ReadOnly = true;
            this.DIS_C.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DIS_C.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DIS_C.Width = 68;
            // 
            // DIS_D
            // 
            dataGridViewCellStyle36.Format = "N0";
            dataGridViewCellStyle36.NullValue = "0";
            this.DIS_D.DefaultCellStyle = dataGridViewCellStyle36;
            this.DIS_D.HeaderText = "D基站  (cm)";
            this.DIS_D.Name = "DIS_D";
            this.DIS_D.ReadOnly = true;
            this.DIS_D.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DIS_D.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DIS_D.Width = 68;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(174, 106);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 21);
            this.textBox1.TabIndex = 23;
            this.textBox1.Text = "115200";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 22;
            this.label2.Text = "BaudRate";
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(174, 240);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 21;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnWrite
            // 
            this.btnWrite.Location = new System.Drawing.Point(174, 194);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(75, 23);
            this.btnWrite.TabIndex = 20;
            this.btnWrite.Text = "Write";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(48, 194);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(75, 23);
            this.btnRead.TabIndex = 19;
            this.btnRead.Text = "Read";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(48, 240);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 23);
            this.btnStop.TabIndex = 18;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(174, 147);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 17;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(48, 147);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(75, 23);
            this.btnOpen.TabIndex = 16;
            this.btnOpen.Text = "Open";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 15;
            this.label1.Text = "Port";
            // 
            // comboSerial
            // 
            this.comboSerial.FormattingEnabled = true;
            this.comboSerial.Location = new System.Drawing.Point(174, 66);
            this.comboSerial.Name = "comboSerial";
            this.comboSerial.Size = new System.Drawing.Size(121, 20);
            this.comboSerial.TabIndex = 14;
            // 
            // timer_connect_Flag
            // 
            this.timer_connect_Flag.Enabled = true;
            this.timer_connect_Flag.Interval = 1;
            this.timer_connect_Flag.Tick += new System.EventHandler(this.timer_connect_Flag_Tick);
            // 
            // timer_MODBUS_connet
            // 
            this.timer_MODBUS_connet.Interval = 1000;
            this.timer_MODBUS_connet.Tick += new System.EventHandler(this.timer_MODBUS_connet_Tick);
            // 
            // timer_display
            // 
            this.timer_display.Enabled = true;
            this.timer_display.Interval = 50;
            // 
            // timer_DW
            // 
            this.timer_DW.Interval = 200;
            this.timer_DW.Tick += new System.EventHandler(this.timer_DW_Tick);
            // 
            // timer_state
            // 
            this.timer_state.Enabled = true;
            this.timer_state.Interval = 30;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1138, 561);
            this.Controls.Add(this.dataGridView_BS_SET);
            this.Controls.Add(this.dataGridView_TAG);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnWrite);
            this.Controls.Add(this.btnRead);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboSerial);
            this.Controls.Add(this.elementHost1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_BS_SET)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_TAG)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Integration.ElementHost elementHost1;
        private UserControl1 userControl1;
        public System.Windows.Forms.DataGridView dataGridView_BS_SET;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn x;
        private System.Windows.Forms.DataGridViewTextBoxColumn y;
        private System.Windows.Forms.DataGridViewTextBoxColumn z;
        private System.Windows.Forms.DataGridView dataGridView_TAG;
        private System.Windows.Forms.DataGridViewTextBoxColumn TAG_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn DW_X;
        private System.Windows.Forms.DataGridViewTextBoxColumn DW_Y;
        private System.Windows.Forms.DataGridViewTextBoxColumn DW_Z;
        private System.Windows.Forms.DataGridViewTextBoxColumn DIS_A;
        private System.Windows.Forms.DataGridViewTextBoxColumn DIS_B;
        private System.Windows.Forms.DataGridViewTextBoxColumn DIS_C;
        private System.Windows.Forms.DataGridViewTextBoxColumn DIS_D;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboSerial;
        private System.Windows.Forms.Timer timer_connect_Flag;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Timer timer_MODBUS_connet;
        private System.Windows.Forms.Timer timer_display;
        private System.Windows.Forms.Timer timer_DW;
        private System.Windows.Forms.Timer timer_state;
    }
}

