﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using System.Reflection;
using System.IO;
using System.Windows.Forms.Integration;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private int state_Flag = 0;                   //状态标志
        private int GETDATA_NEW = 0;                  //是否为新数据标志位
        private Int16 time_SCAN_NUM = 0;              //扫描MODBUS—ID标志计数用
        private static volatile byte[] rBuff = null;                              //串口接收数据缓存
        private int[] Flag_BaudRate_Delay = new int[] { 13, 10, 4, 3, 2, 1, 1, 1, 1, 1 };      //波特率决定接收延时
        private Int16 CJ_EN = 0;                    //测距发送协议使能
        private Int16 CJ_END = 0;

        private int connect_Flag = 0;                                            //0：未搜索 1：未连接串口  2：未扫描设备  3：未连接设备  4：通讯成功中 5：通讯失败中
        private int Flag_BaudRate = 0;                                           //波特率选择，默认选择为115200
        private Byte Click_Flag = 0;                //按钮执行事件标志  0：读取配置   1：写入配置  2：一、二维定位  4：三维定位  8：停止测距
        private int CRCL, CRCH, CRCBL, CRCBH;
        private Byte NOW_ID = 1;
        private int KALMAN_Q = 1;      	                     //卡尔曼-Q
        private int KALMAN_R = 500;					         //卡尔曼-R
        private static double[] x_last = new double[512];    //卡尔曼
        private double[] p_last = new double[512];           //卡尔曼     
        private float Triangle_scale = 1.2f;    //基站筛选过程使用的比例参数


        #region CRC校验数组
        //CRC校验数组
        private byte[] aucCRCHi = new byte[]  {
   0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
};


        private byte[] aucCRCLo = new byte[] {
    0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 0xCC,
    0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09, 0x08, 0xC8, 0xD8,
    0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 0x14,
    0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3, 0x11, 0xD1, 0xD0, 0x10, 0xF0,
    0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4, 0x3C,
    0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 0x28,
    0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C, 0xE4,
    0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26, 0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0,
    0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 0x6C,
    0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 0x78,
    0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4,
    0x74, 0x75, 0xB5, 0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 0x50,
    0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 0x9C,
    0x5C, 0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 0x88,
    0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C, 0x44,
    0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80, 0x40
};
        #endregion
        #region CRC校验函数
        //通过逆序CRC16表, 逆序CRC计算  
        int CRC16(byte[] Frame, int Length)     // 传入要校验的数组名及其长度    
        {
            byte CRCHi = 0xFF;
            byte CRCLo = 0xFF;
            int iIndex = 0;


            for (int i = 0; i < Length; i++)
            {
                iIndex = CRCHi ^ (Frame[i]);
                CRCHi = (byte)(CRCLo ^ aucCRCHi[iIndex]);
                CRCLo = aucCRCLo[iIndex];
            }
            return (int)(CRCHi << 8 | CRCLo);        // CRC校验返回值   // CRCHI 向左移动，就是逆序计算的代表              
        }
        #endregion
        #region 串口发送的函数
        void senddata(byte[] Frame, int Length)     // 串口发送数据    
        {
            Int32 crc;
            crc = CRC16(Frame, Length - 2);    //进行CRC校验码的计算
            Frame[Length - 2] = (byte)(crc / 256);
            Frame[Length - 1] = (byte)(crc % 256);      //将计算得到的CRC校验码一起写入发送数据

            //printf_data(Frame, Length, 0);

            try
            {
                serialPort1.Write(Frame, 0, Length);
            }
            catch
            {
                MessageBox.Show("串口通讯错误", "提示");
                return;
            }
        }
        #endregion
        #region 串口接收中团函数
        private void SerDataReceive(object sender, SerialDataReceivedEventArgs e)  //串口接收数据程序
        {
            int Text_Len = 0; //串口数据长度
            if (serialPort1.IsOpen == false)
            {
                return;
            }

            if (Click_Flag == 0)
            {
                Thread.Sleep((Int32)(Flag_BaudRate_Delay[Flag_BaudRate]) * 30);
            }
            else
            {
                Thread.Sleep((Int32)(Flag_BaudRate_Delay[Flag_BaudRate]) * 4);
            }
            byte[] byteReceive;  //串口数据接收数组
            try
            {
                byteReceive = new byte[serialPort1.BytesToRead];
            }
            catch (InvalidOperationException ex)
            {
                return;
            }


            serialPort1.Read(byteReceive, 0, byteReceive.Length);

            serialPort1.DiscardInBuffer();
            if (byteReceive.Length < 5)
            {
                return;
            }
            Text_Len = byteReceive.Length;
            {
                Int32 crc;
                crc = CRC16(byteReceive, Text_Len - 2);
                CRCH = crc / 256;
                CRCL = crc % 256;
                CRCBH = byteReceive[Text_Len - 2];
                CRCBL = byteReceive[Text_Len - 1];

                if (CRCBH != CRCH) return;
                if (CRCBL != CRCL) return;
            }
            GETDATA_NEW = 1;   //标志接收到了数据
            rBuff = new byte[Text_Len];
            Array.Copy(byteReceive, rBuff, Text_Len);
        }
        #endregion
        #region 当收到串口数据进入到次函数进行串口信息处理
        private void connect_Flag_Tick()   //在按钮执行事件  0：读取配置   1：写入配置  2：一维、二维测距   5：三维测距 这些事件触发后的接收数据处理
        {
            if (Click_Flag == 0)
            {
                if (rBuff[0] == NOW_ID)
                {
                    if (rBuff[1] == 0x03 && rBuff.Length == 217)
                    {
                        int i;
                        this.dataGridView_BS_SET.Rows[0].Cells[1].Value = Convert.ToInt16((Int16)(((rBuff[21] << 8) & 0xFF00) | rBuff[22]));
                        this.dataGridView_BS_SET.Rows[0].Cells[2].Value = Convert.ToInt16((Int16)(((rBuff[23] << 8) & 0xFF00) | rBuff[24]));
                        this.dataGridView_BS_SET.Rows[0].Cells[3].Value = Convert.ToInt16((Int16)(((rBuff[25] << 8) & 0xFF00) | rBuff[26]));
                        for (i = 0; i < 3; i++)
                        {
                            this.dataGridView_BS_SET.Rows[i + 1].Cells[1].Value = Convert.ToInt16((Int16)(((rBuff[26 + 8 * i + 3] << 8) & 0xFF00) | rBuff[26 + 8 * i + 4]));
                            this.dataGridView_BS_SET.Rows[i + 1].Cells[2].Value = Convert.ToInt16((Int16)(((rBuff[26 + 8 * i + 5] << 8) & 0xFF00) | rBuff[26 + 8 * i + 6]));
                            this.dataGridView_BS_SET.Rows[i + 1].Cells[3].Value = Convert.ToInt16((Int16)(((rBuff[26 + 8 * i + 7] << 8) & 0xFF00) | rBuff[26 + 8 * i + 8]));
                        }

                        for (i = 0; i < rBuff[86]; i++)
                        {
                            if ((i % 2) == 1)//如果为奇数
                            {
                                dataGridView_TAG.Rows[i].Cells[0].Value = rBuff[113 + i - 1];
                            }
                            else
                            {
                                dataGridView_TAG.Rows[i].Cells[0].Value = rBuff[113 + i + 1];
                            }
                        }
                        if (rBuff[214] != 32)//若为版本以外的
                        {
                            state_Flag = 10;
                            Click_Flag = 100;
                            MessageBox.Show("不支持此设备固件版本，请使用V3.2固件版本的设备，请关闭软件谢谢！", "提示");
                            return;
                        }
                        state_Flag = 3;
                        Click_Flag = 100;    //跳出读取配置的状态（防止定时器重复发送读取配置的命令）
                        MessageBox.Show("读取配置成功", "提示");
                    }
                }
            }
            if (Click_Flag == 1)  //发送写入配置后接收数据的判断
            {
                if (rBuff[0] == NOW_ID)
                {
                    if (rBuff[1] == 0x10 && rBuff.Length == 8)
                    {
                        Click_Flag = 100;    //跳出写入配置的状态
                        MessageBox.Show("写入配置成功", "提示");

                    }
                }
            }
            if (Click_Flag == 2)  //一、二维、三维开始定位程序
            {
                if (rBuff[0] == NOW_ID)
                {
                    if (rBuff[1] == 0x10 && rBuff.Length == 8)  //收到协议应答
                    {
                        CJ_EN = 0;
                    }
                    if (rBuff[1] == 0x03 && rBuff[2] == 0x1A && rBuff.Length == 31)//收到定位数据返回
                    {
                        int i;
                        CJ_EN = 0;
                        for (i = 0; i < dataGridView_TAG.RowCount; i++)
                        {
                            Int16 TAG_ID;

                            if (dataGridView_TAG.Rows[i].Cells[0].Value == null)//取标签测量表格的ID
                            {
                                TAG_ID = 0;
                            }
                            else
                            {
                                TAG_ID = Convert.ToInt16(dataGridView_TAG.Rows[i].Cells[0].Value.ToString());
                            }

                            if (rBuff[4] == TAG_ID)
                            {
                                int f;
                                Color OK_color = Color.FromArgb(144, 238, 144);
                                Color NG_color = Color.FromArgb(255, 48, 48);

                                if (((rBuff[5] >> 0) & 0x01) == 0x00)//没有计算成功
                                {
                                    dataGridView_TAG.Rows[i].Cells[1].Style.BackColor = NG_color;
                                    dataGridView_TAG.Rows[i].Cells[2].Style.BackColor = NG_color;
                                    dataGridView_TAG.Rows[i].Cells[3].Style.BackColor = NG_color;
                                }
                                else
                                {
                                    dataGridView_TAG.Rows[i].Cells[1].Style.BackColor = OK_color;
                                    dataGridView_TAG.Rows[i].Cells[2].Style.BackColor = OK_color;
                                    dataGridView_TAG.Rows[i].Cells[3].Style.BackColor = OK_color;
                                }
                                for (f = 0; f < 4; f++) //输出测距错误的基站
                                {

                                    if (((rBuff[6] >> f) & 0x01) == 0x01)
                                    {
                                        dataGridView_TAG.Rows[i].Cells[4 + f].Style.BackColor = OK_color;
                                    }
                                    else
                                    {
                                        dataGridView_TAG.Rows[i].Cells[4 + f].Style.BackColor = NG_color;
                                    }
                                }
                                if (rBuff[6] != 0x00)
                                {
                                    this.dataGridView_TAG.Rows[i].Cells[4].Value = Convert.ToInt16((Int16)(((rBuff[13] << 8) & 0xFF00) | rBuff[14]));
                                    this.dataGridView_TAG.Rows[i].Cells[5].Value = Convert.ToInt16((Int16)(((rBuff[15] << 8) & 0xFF00) | rBuff[16]));
                                    this.dataGridView_TAG.Rows[i].Cells[6].Value = Convert.ToInt16((Int16)(((rBuff[17] << 8) & 0xFF00) | rBuff[18]));
                                    this.dataGridView_TAG.Rows[i].Cells[7].Value = Convert.ToInt16((Int16)(((rBuff[19] << 8) & 0xFF00) | rBuff[20]));



                                    this.dataGridView_TAG.Rows[i].Cells[1].Value = Convert.ToInt16((Int16)(((rBuff[7] << 8) & 0xFF00) | rBuff[8]));
                                    this.dataGridView_TAG.Rows[i].Cells[2].Value = Convert.ToInt16((Int16)(((rBuff[9] << 8) & 0xFF00) | rBuff[10]));
                                    this.dataGridView_TAG.Rows[i].Cells[3].Value = Convert.ToInt16((Int16)(((rBuff[11] << 8) & 0xFF00) | rBuff[12]));

                                    userControl1.ChangCoordinateOfFace3(Convert.ToDouble(dataGridView_TAG.Rows[0].Cells[1].Value.ToString()), Convert.ToDouble(dataGridView_TAG.Rows[0].Cells[2].Value.ToString()), Convert.ToDouble(dataGridView_TAG.Rows[0].Cells[3].Value.ToString()));
                                    userControl1.ChangCoordinateOfBaseB(Convert.ToDouble(dataGridView_BS_SET.Rows[1].Cells[1].Value.ToString()), Convert.ToDouble(dataGridView_BS_SET.Rows[1].Cells[2].Value.ToString()), Convert.ToDouble(dataGridView_BS_SET.Rows[1].Cells[3].Value.ToString()));
                                    userControl1.ChangCoordinateOfBaseC(Convert.ToDouble(dataGridView_BS_SET.Rows[2].Cells[1].Value.ToString()), Convert.ToDouble(dataGridView_BS_SET.Rows[2].Cells[2].Value.ToString()), Convert.ToDouble(dataGridView_BS_SET.Rows[2].Cells[3].Value.ToString()));
                                    userControl1.ChangCoordinateOfBaseD(Convert.ToDouble(dataGridView_BS_SET.Rows[3].Cells[1].Value.ToString()), Convert.ToDouble(dataGridView_BS_SET.Rows[3].Cells[2].Value.ToString()), Convert.ToDouble(dataGridView_BS_SET.Rows[3].Cells[3].Value.ToString()));
                                }

                            }

                        }
                    }
                }
            }
            if (Click_Flag == 8)//结束定位
            {
                if (rBuff[0] == NOW_ID)
                {
                    if (rBuff[1] == 0x10 && rBuff.Length == 8)  //收到协议应答
                    {
                        CJ_END = 0;
                        state_Flag = 3;
                        timer_DW.Enabled = false;
                        //MessageBox.Show("已取消定位", "提示");
                    }
                }
            }


        }
        #endregion
        #region 计算三维坐标预先处理函数
        void PersonPosition_xyz(int NUM)  //四个基站解算标签三维坐标
        {
            double[,] point = new double[70, 3];  //每四个基站循环定位得到的坐标数据缓存，8取4的组合数量为70
            Int16[,] BS_buf = new Int16[8, 4];   //界面输入的所有基站的x,y,z坐标及r 
            Int16[,] BS_buf_EN = new Int16[8, 4];  //实际勾选了的基站的数据
            double[] point_out = new double[3];    //四个基站解算得到的x,y,z坐标
            int BS_EN_num = 1;   //选中的基站数量计数,至少一个（主基站）
            int i = 0, num = 0;
            int E = 0, R = 0, T = 0, K = 0;

            for (i = 0; i < 8; i++)  //将界面的所有基站信息存入BS_buf数组
            {
                if (dataGridView_BS_SET.Rows[i].Cells[1].Value == null)
                {
                    BS_buf[i, 0] = 0;
                }
                else BS_buf[i, 0] = (Int16)(Convert.ToInt16(dataGridView_BS_SET.Rows[i].Cells[1].Value.ToString()));//界面输入的基站x坐标

                if (dataGridView_BS_SET.Rows[i].Cells[2].Value == null)
                {
                    BS_buf[i, 1] = 0;
                }
                else BS_buf[i, 1] = (Int16)(Convert.ToInt16(dataGridView_BS_SET.Rows[i].Cells[2].Value.ToString()));//界面输入的基站y坐标

                if (dataGridView_BS_SET.Rows[i].Cells[3].Value == null)
                {
                    BS_buf[i, 2] = 0;
                }
                else BS_buf[i, 2] = (Int16)(Convert.ToInt16(dataGridView_BS_SET.Rows[i].Cells[3].Value.ToString()));//界面输入的基站z坐标
                if (dataGridView_TAG.Rows[NUM].Cells[4 + i].Value == null)
                {
                    BS_buf[i, 3] = 0;
                }
                else BS_buf[i, 3] = (Int16)(Convert.ToInt16(dataGridView_TAG.Rows[NUM].Cells[4 + i].Value.ToString()));//r值
            }
            //A基站的数据
            BS_buf_EN[0, 0] = BS_buf[0, 0];
            BS_buf_EN[0, 1] = BS_buf[0, 1];
            BS_buf_EN[0, 2] = BS_buf[0, 2];
            BS_buf_EN[0, 3] = BS_buf[0, 3];


            BS_buf_EN[BS_EN_num, 0] = BS_buf[1, 0];
            BS_buf_EN[BS_EN_num, 1] = BS_buf[1, 1];
            BS_buf_EN[BS_EN_num, 2] = BS_buf[1, 2];
            BS_buf_EN[BS_EN_num, 3] = BS_buf[1, 3];
            BS_EN_num++;



            BS_buf_EN[BS_EN_num, 0] = BS_buf[2, 0];
            BS_buf_EN[BS_EN_num, 1] = BS_buf[2, 1];
            BS_buf_EN[BS_EN_num, 2] = BS_buf[2, 2];
            BS_buf_EN[BS_EN_num, 3] = BS_buf[2, 3];
            BS_EN_num++;


            BS_buf_EN[BS_EN_num, 0] = BS_buf[3, 0];
            BS_buf_EN[BS_EN_num, 1] = BS_buf[3, 1];
            BS_buf_EN[BS_EN_num, 2] = BS_buf[3, 2];
            BS_buf_EN[BS_EN_num, 3] = BS_buf[3, 3];
            BS_EN_num++;



            if (BS_EN_num < 4)    //少于4个基站，无法定位
            {

                return;
            }



            for (E = 0; E < (BS_EN_num - 3); E++)  //将所有使能的基站每四个分组进行循环定位
            {
                for (R = E + 1; R < (BS_EN_num - 2); R++)
                {
                    for (T = R + 1; T < (BS_EN_num - 1); T++)
                    {
                        for (K = T + 1; K < BS_EN_num; K++)
                        {
                            Int16 flag = 0;
                            flag += Judge_3D(BS_buf_EN[E, 0], BS_buf_EN[E, 1], BS_buf_EN[E, 2], BS_buf_EN[R, 0], BS_buf_EN[R, 1], BS_buf_EN[R, 2], BS_buf_EN[T, 0], BS_buf_EN[T, 1], BS_buf_EN[T, 2]);
                            flag += Judge_3D(BS_buf_EN[E, 0], BS_buf_EN[E, 1], BS_buf_EN[E, 2], BS_buf_EN[R, 0], BS_buf_EN[R, 1], BS_buf_EN[R, 2], BS_buf_EN[K, 0], BS_buf_EN[K, 1], BS_buf_EN[K, 2]);
                            flag += Judge_3D(BS_buf_EN[E, 0], BS_buf_EN[E, 1], BS_buf_EN[E, 2], BS_buf_EN[T, 0], BS_buf_EN[T, 1], BS_buf_EN[T, 2], BS_buf_EN[K, 0], BS_buf_EN[K, 1], BS_buf_EN[K, 2]);
                            flag += Judge_3D(BS_buf_EN[R, 0], BS_buf_EN[R, 1], BS_buf_EN[R, 2], BS_buf_EN[T, 0], BS_buf_EN[T, 1], BS_buf_EN[T, 2], BS_buf_EN[K, 0], BS_buf_EN[K, 1], BS_buf_EN[K, 2]);

                            if (flag > 2)  //筛选合格的四个基站才进行坐标解算
                            {
                                double[] point_xyz = new double[3];

                                point_xyz = Get_three_BS_Out_XYZ(BS_buf_EN[E, 0], BS_buf_EN[E, 1], BS_buf_EN[E, 2], BS_buf_EN[E, 3],
                                                                     BS_buf_EN[R, 0], BS_buf_EN[R, 1], BS_buf_EN[R, 2], BS_buf_EN[R, 3],
                                                                     BS_buf_EN[T, 0], BS_buf_EN[T, 1], BS_buf_EN[T, 2], BS_buf_EN[T, 3],
                                                                     BS_buf_EN[K, 0], BS_buf_EN[K, 1], BS_buf_EN[K, 2], BS_buf_EN[K, 3]);

                                point[num, 0] = point_xyz[0];
                                point[num, 1] = point_xyz[1];
                                point[num, 2] = point_xyz[2];
                                num++;    //计算得到的坐标数据存入point数组
                            }
                        }
                    }
                }
            }
            //求一个初略的质心
            point_out[0] = 0.0;
            point_out[1] = 0.0;
            point_out[2] = 0.0;
            for (i = 0; i < num; i++)  //将所有计算得到的数据相加存入point_out
            {
                point_out[0] += point[i, 0];
                point_out[1] += point[i, 1];
                point_out[2] += point[i, 2];
            }
            if (num != 0)       //取平均值输出坐标数据
            {
                point_out[0] = point_out[0] / num;
                point_out[1] = point_out[1] / num;
                point_out[2] = point_out[2] / num;
            }
            KALMAN_Q = (Int16)(3);
            KALMAN_R = (Int16)(10);

            if ((point_out[0] != 0) && (point_out[1] != 0) && (point_out[2] != 0))
            {
                Color OK_color = Color.FromArgb(144, 238, 144); ;
                point_out[0] = KalmanFilter(point_out[0], KALMAN_Q, KALMAN_R, (Int16)(0 + 3 * NUM));
                point_out[1] = KalmanFilter(point_out[1], KALMAN_Q, KALMAN_R, (Int16)(1 + 3 * NUM));
                point_out[2] = KalmanFilter(point_out[2], KALMAN_Q, KALMAN_R, (Int16)(2 + 3 * NUM));
                //将坐标数据显示到界面
                dataGridView_TAG.Rows[NUM].Cells[1].Value = (Int16)point_out[0];
                dataGridView_TAG.Rows[NUM].Cells[2].Value = (Int16)point_out[1];
                dataGridView_TAG.Rows[NUM].Cells[3].Value = (Int16)point_out[2];
                dataGridView_TAG.Rows[NUM].Cells[1].Style.BackColor = OK_color;     //计算成功为绿色
                dataGridView_TAG.Rows[NUM].Cells[2].Style.BackColor = OK_color;     //计算成功为绿色
                dataGridView_TAG.Rows[NUM].Cells[3].Style.BackColor = OK_color;     //计算成功为绿色
            }
            else
            {
                Color NG_color = Color.FromArgb(255, 48, 48);
                dataGridView_TAG.Rows[NUM].Cells[1].Style.BackColor = NG_color;     //计算失败为红色
                dataGridView_TAG.Rows[NUM].Cells[2].Style.BackColor = NG_color;     //计算失败为红色
                dataGridView_TAG.Rows[NUM].Cells[3].Style.BackColor = NG_color;     //计算失败为红色
            }


        }
        #endregion
        #region 三维算法基站筛选函数
        Int16 Judge_3D(double x1, double y1, double z1, double x2, double y2, double z2, double x3, double y3, double z3)
        {
            double Dist_12, Dist_13, Dist_23;
            //int a = 100;
            Dist_12 = Math.Sqrt(Math.Pow((x1 - x2), 2) + Math.Pow((y1 - y2), 2) + Math.Pow((z1 - z2), 2));//1、2基站距离
            Dist_13 = Math.Sqrt(Math.Pow((x1 - x3), 2) + Math.Pow((y1 - y3), 2) + Math.Pow((z1 - z3), 2));//1、3基站距离
            Dist_23 = Math.Sqrt(Math.Pow((x2 - x3), 2) + Math.Pow((y2 - y3), 2) + Math.Pow((z2 - z3), 2));//2、3基站距离

            if ((Dist_12 + Dist_13) > (Dist_23 * Triangle_scale) && (Dist_12 + Dist_23) > (Dist_13 * Triangle_scale) && (Dist_13 + Dist_23) > (Dist_12 * Triangle_scale))
                return 1;
            else return 0;

        }
        #endregion
        #region 三维算法
        double[] Get_three_BS_Out_XYZ(double x1, double y1, double z1, double r1,
                                      double x2, double y2, double z2, double r2,
                                      double x3, double y3, double z3, double r3,
                                      double x4, double y4, double z4, double r4)//三维坐标求解
        {
            double[,] A = new double[3, 3];
            double[,] B = new double[3, 3];
            double[] C = new double[3];
            double[] Point_xyz = new double[3];
            A[0, 0] = 2 * (x1 - x2); A[0, 1] = 2 * (y1 - y2); A[0, 2] = 2 * (z1 - z2);
            A[1, 0] = 2 * (x1 - x3); A[1, 1] = 2 * (y1 - y3); A[1, 2] = 2 * (z1 - z3);
            A[2, 0] = 2 * (x1 - x4); A[2, 1] = 2 * (y1 - y4); A[2, 2] = 2 * (z1 - z4);
            //B = Inverse(A);

            double det = 0;    //determinant
            det =
                 A[0, 0] * A[1, 1] * A[2, 2] + A[0, 1] * A[1, 2] * A[2, 0] + A[0, 2] * A[1, 0] * A[2, 1] - A[2, 0] * A[1, 1] * A[0, 2] - A[1, 0] * A[0, 1] * A[2, 2] - A[0, 0] * A[2, 1] * A[1, 2];

            if (det != 0)
            {
                B[0, 0] = (A[1, 1] * A[2, 2] - A[1, 2] * A[2, 1]) / det;
                B[0, 1] = -(A[0, 1] * A[2, 2] - A[0, 2] * A[2, 1]) / det;
                B[0, 2] = (A[0, 1] * A[1, 2] - A[0, 2] * A[1, 1]) / det;

                B[1, 0] = -(A[1, 0] * A[2, 2] - A[1, 2] * A[2, 0]) / det;
                B[1, 1] = (A[0, 0] * A[2, 2] - A[0, 2] * A[2, 0]) / det;
                B[1, 2] = -(A[0, 0] * A[1, 2] - A[0, 2] * A[1, 0]) / det;

                B[2, 0] = (A[1, 0] * A[2, 1] - A[1, 1] * A[2, 0]) / det;
                B[2, 1] = -(A[0, 0] * A[2, 1] - A[0, 1] * A[2, 0]) / det;
                B[2, 2] = (A[0, 0] * A[1, 1] - A[0, 1] * A[1, 0]) / det;


                C[0] = r2 * r2 - r1 * r1 - x2 * x2 + x1 * x1 - y2 * y2 + y1 * y1 - z2 * z2 + z1 * z1;
                C[1] = r3 * r3 - r1 * r1 - x3 * x3 + x1 * x1 - y3 * y3 + y1 * y1 - z3 * z3 + z1 * z1;
                C[2] = r4 * r4 - r1 * r1 - x4 * x4 + x1 * x1 - y4 * y4 + y1 * y1 - z4 * z4 + z1 * z1;
                Point_xyz[0] = B[0, 0] * C[0] + B[0, 1] * C[1] + B[0, 2] * C[2];
                Point_xyz[1] = B[1, 0] * C[0] + B[1, 1] * C[1] + B[1, 2] * C[2];
                Point_xyz[2] = B[2, 0] * C[0] + B[2, 1] * C[1] + B[2, 2] * C[2];
                return Point_xyz;
            }
            else
            {
                Point_xyz[0] = 0;
                Point_xyz[1] = 0;
                Point_xyz[2] = 0;
                return Point_xyz;
            }
        }
        #endregion
        #region 卡尔曼滤波函数
        double KalmanFilter(double ResrcData, double ProcessNiose_Q, double MeasureNoise_R, Int16 db)
        {
            double R = MeasureNoise_R;
            double Q = ProcessNiose_Q;
            double x_mid = x_last[db];
            double x_now;
            double p_mid;
            double p_now;
            double kg;

            x_mid = x_last[db];                       //x_last=x(k-1|k-1),x_mid=x(k|k-1)
            p_mid = p_last[db] + Q;                     //p_mid=p(k|k-1),p_last=p(k-1|k-1),Q=??
            kg = p_mid / (p_mid + R);                 //kg?kalman filter,R ???
            x_now = x_mid + kg * (ResrcData - x_mid);   //???????
            p_now = (1 - kg) * p_mid;                 //??????covariance
            p_last[db] = p_now;                     //??covariance ?
            x_last[db] = x_now;                     //???????	
            return x_now;
        }
        #endregion
        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        private void elementHost1_ChildChanged(object sender, System.Windows.Forms.Integration.ChildChangedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            string[] ports = SerialPort.GetPortNames();
            Array.Sort(ports);
            comboSerial.Items.Clear();
            comboSerial.Items.AddRange(ports);
            btnClose.Enabled = false;
            Int16 i, j;


            this.dataGridView_TAG.Rows.Add(); //添加行
            for (j = 0; j < 7; j++)
            {
                this.dataGridView_TAG.Rows[0].Cells[j].Value = 0;
            }

            for (i = 0; i < 4; i++)
            {
                this.dataGridView_BS_SET.Rows.Add();  //添加行
            }

            this.dataGridView_BS_SET.Rows[0].Cells[0].Value = "    A基站";
            this.dataGridView_BS_SET.Rows[1].Cells[0].Value = "    B基站";
            this.dataGridView_BS_SET.Rows[2].Cells[0].Value = "    C基站";
            this.dataGridView_BS_SET.Rows[3].Cells[0].Value = "    D基站";
            //设置为只读
            dataGridView_BS_SET.Columns[0].ReadOnly = true;
        }

        private void dataGridView_BS_SET_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void timer_MODBUS_connet_Tick(object sender, EventArgs e)
        {
            byte[] send_buf = new byte[300];
            Int32 send_length = 0;
            timer_MODBUS_connet.Enabled = false;
            //01 03 00 20 00 17
            // send_buf[0] = (byte)Convert.ToInt16(comboBox_Rate.SelectedItem.ToString());
            if (Click_Flag == 0) //读取配置
            {
                send_buf[0] = NOW_ID;
                send_buf[1] = 0x03;
                send_buf[2] = 0x00;
                send_buf[3] = 0x00;
                send_buf[4] = 0x00;
                send_buf[5] = 0x6A;
                send_buf[6] = 0x00;
                send_buf[7] = 0x00;
                send_length = 8;
                senddata(send_buf, send_length);
            }
            if (Click_Flag == 1)//写入配置
            {
                int i;
                int buff_t;
                send_buf[0] = NOW_ID;
                send_buf[1] = 0x10;
                send_buf[2] = 0x00;
                send_buf[3] = 0x00;
                send_buf[4] = 0x00;
                send_buf[5] = 0x6A;
                send_buf[6] = 0xD4;

                send_buf[7] = 0x00;
                send_buf[8] = (byte)(7);

                send_buf[9] = 0x00;
                send_buf[10] = (byte)(1);

                send_buf[11] = (byte)(0);
                send_buf[12] = (byte)(2);

                send_buf[13] = 0x00;
                send_buf[14] = (byte)(2);



                send_buf[15] = 0x00; send_buf[16] = 0x00;



                send_buf[17] = (byte)(2);//空中信道
                send_buf[18] = (byte)(0);//空中速率

                send_buf[19] = (byte)(3 / 256);
                send_buf[20] = (byte)(3 % 256);

                send_buf[21] = (byte)(10 / 256);
                send_buf[22] = (byte)(10 % 256);

                send_buf[23] = (byte)(32975 / 256);
                send_buf[24] = (byte)(32975 % 256);

                if (dataGridView_BS_SET.Rows[0].Cells[1].Value == null) buff_t = 0;
                else buff_t = Convert.ToInt16(dataGridView_BS_SET.Rows[0].Cells[1].Value.ToString());
                send_buf[25] = (byte)((buff_t >> 8) & 0xFF);
                send_buf[26] = (byte)((buff_t & 0xFF));


                if (dataGridView_BS_SET.Rows[0].Cells[2].Value == null) buff_t = 0;
                else buff_t = Convert.ToInt16(dataGridView_BS_SET.Rows[0].Cells[2].Value.ToString());
                send_buf[27] = (byte)((buff_t >> 8) & 0xFF);
                send_buf[28] = (byte)(buff_t & 0xFF);

                if (dataGridView_BS_SET.Rows[0].Cells[3].Value == null) buff_t = 0;
                else buff_t = Convert.ToInt16(dataGridView_BS_SET.Rows[0].Cells[3].Value.ToString());
                send_buf[29] = (byte)((buff_t >> 8) & 0xFF);
                send_buf[30] = (byte)(buff_t & 0xFF);


                send_buf[31] = 0x00; send_buf[32] = 0x01;


                send_buf[39] = 0x00; send_buf[40] = 0x01;


                send_buf[47] = 0x00; send_buf[48] = 0x01;



                send_buf[55] = 0x00; send_buf[56] = 0x00;

                send_buf[63] = 0x00; send_buf[64] = 0x00;

                send_buf[71] = 0x00; send_buf[72] = 0x00;

                send_buf[79] = 0x00; send_buf[80] = 0x00;

                for (i = 0; i < 3; i++)
                {

                    if (dataGridView_BS_SET.Rows[i + 1].Cells[1].Value == null) buff_t = 0;
                    else buff_t = Convert.ToInt16(dataGridView_BS_SET.Rows[i + 1].Cells[1].Value.ToString());
                    send_buf[30 + 8 * i + 3] = (byte)((buff_t >> 8) & 0xFF);
                    send_buf[30 + 8 * i + 4] = (byte)(buff_t & 0xFF);

                    if (dataGridView_BS_SET.Rows[i + 1].Cells[2].Value == null) buff_t = 0;
                    else buff_t = Convert.ToInt16(dataGridView_BS_SET.Rows[i + 1].Cells[2].Value.ToString());
                    send_buf[30 + 8 * i + 5] = (byte)((buff_t >> 8) & 0xFF);
                    send_buf[30 + 8 * i + 6] = (byte)(buff_t & 0xFF);

                    if (dataGridView_BS_SET.Rows[i + 1].Cells[3].Value == null) buff_t = 0;
                    else buff_t = Convert.ToInt16(dataGridView_BS_SET.Rows[i + 1].Cells[3].Value.ToString());
                    send_buf[30 + 8 * i + 7] = (byte)((buff_t >> 8) & 0xFF);
                    send_buf[30 + 8 * i + 8] = (byte)(buff_t & 0xFF);

                }

                send_buf[90] = (byte)(1);

                for (i = 0; i < (byte)(1); i++)
                {
                    if (dataGridView_TAG.Rows[i].Cells[0].Value == null)
                    {
                        if ((i % 2) == 1)//如果是奇数
                        {
                            send_buf[116 + i] = 0;
                        }
                        else  //偶数
                        {
                            send_buf[116 + i + 2] = 0;
                        }
                    }
                    else
                    {
                        if ((i % 2) == 1)//如果是奇数
                        {
                            send_buf[116 + i] = (byte)Convert.ToInt16(dataGridView_TAG.Rows[i].Cells[0].Value.ToString());
                        }
                        else  //偶数
                        {
                            send_buf[116 + i + 2] = (byte)Convert.ToInt16(dataGridView_TAG.Rows[i].Cells[0].Value.ToString());
                        }

                    }


                }


                send_length = 221;
                senddata(send_buf, send_length);
            }


            timer_MODBUS_connet.Enabled = true;
        }

        private void timer_connect_Flag_Tick(object sender, EventArgs e)
        {
            if (GETDATA_NEW == 1)//接收到新数据
            {

                GETDATA_NEW = 0;
                timer_connect_Flag.Enabled = false; //关闭自己时钟使能
                /*if (isSCAN == 1)//正在扫描状态
                {
                    if (rBuff[1] == 0x03)
                    {
                        SCAN_ID_Click(rBuff[0]);
                    }

                }
                else
                {*/

                // T_C.Start();

                connect_Flag_Tick();
                //}


                timer_connect_Flag.Enabled = true; //打开自己时钟使能
                
            }
        }

        private void timer_DW_Tick(object sender, EventArgs e)
        {
            byte[] send_buf = new byte[100];
            Int32 send_length = 0;
            if (Click_Flag == 2 || Click_Flag == 4) //开始测距
            {
                if (CJ_EN == 1)
                {
                    send_buf[0] = NOW_ID;
                    send_buf[1] = 0x10;
                    send_buf[2] = 0x00;
                    send_buf[3] = 0x28;
                    send_buf[4] = 0x00;
                    send_buf[5] = 0x01;
                    send_buf[6] = 0x02;
                    send_buf[7] = 0x00;
                    send_buf[8] = 0x04; //持续检测自动发送

                    send_length = 11;

                    senddata(send_buf, send_length);

                }
            }
            if (Click_Flag == 8) //停止测距
            {
                if (CJ_END == 1)
                {
                    send_buf[0] = NOW_ID;
                    send_buf[1] = 0x10;
                    send_buf[2] = 0x00;
                    send_buf[3] = 0x28;
                    send_buf[4] = 0x00;
                    send_buf[5] = 0x01;
                    send_buf[6] = 0x02;
                    send_buf[7] = 0x00;
                    send_buf[8] = 0x00; //停止定位00                               
                    send_length = 11;
                    senddata(send_buf, send_length);

                }
            }
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            serialPort1.PortName = comboSerial.SelectedItem.ToString();
            serialPort1.BaudRate = Convert.ToInt32(textBox1.Text);
            Flag_BaudRate = 7;
            timer_MODBUS_connet.Interval = 1000;
            serialPort1.DataBits = 8;
            serialPort1.StopBits = StopBits.One;
            serialPort1.Parity = Parity.None;
            serialPort1.ReadTimeout = 100;
            serialPort1.WriteTimeout = 100;
            try
            {
                serialPort1.Open();
            }
            catch (System.UnauthorizedAccessException)
            {
                MessageBox.Show("串口打开失败", "提示");
                return;
            }
            state_Flag = 1;
            btnClose.Enabled = true;
            btnOpen.Enabled = false;
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(SerDataReceive);
            connect_Flag = 2;
            if (connect_Flag == 2 || connect_Flag == 3)
            {
                { //清楚测距模式
                    UInt16 i;
                    for (i = 0; i < 10; i++)
                    {
                        byte[] send_buf = new byte[300];
                        Int32 send_length = 0;
                        send_buf[0] = NOW_ID;
                        send_buf[1] = 0x06;
                        send_buf[2] = 0x00;
                        send_buf[3] = 0x28;
                        send_buf[4] = 0x00;
                        send_buf[5] = 0x00;
                        send_buf[6] = 0x00;
                        send_buf[7] = 0x00;
                        send_length = 8;
                        senddata(send_buf, send_length);
                        Thread.Sleep(5);
                    }
                }
                try
                {
                    NOW_ID = (byte)Convert.ToInt16(1);
                }
                catch
                {
                    MessageBox.Show("请输入正确ID", "提示");
                    return;
                }
                connect_Flag = 5;
                state_Flag = 2;
                timer_MODBUS_connet.Enabled = true;
                Click_Flag = 0;

                return;
            }

            if (connect_Flag == 4 || connect_Flag == 5)
            {

                state_Flag = 1;
                timer_MODBUS_connet.Enabled = false;
                Thread.Sleep(5);
                connect_Flag = 3;


                return;
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            state_Flag = 4;
            Click_Flag = 2;
            timer_DW.Enabled = true;
            timer_display.Enabled = true;
            CJ_EN = 1;
            
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            Click_Flag = 0;
        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            Click_Flag = 1;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            Click_Flag = 8;
            CJ_END = 1;
            timer_display.Enabled = true;
            timer_DW.Enabled = true;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            state_Flag = 0;
            connect_Flag = 1;
            timer_MODBUS_connet.Enabled = false;
            //timer_SCAN_ID.Enabled = false;
            Thread.Sleep(5);
            serialPort1.Close();
        }
    }
}
