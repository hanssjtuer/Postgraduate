import math

pi = math.pi

degrees = math.degrees
radians = math.radians
