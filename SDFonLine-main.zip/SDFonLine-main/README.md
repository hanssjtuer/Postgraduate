# SDFonLine
This is an app providing a way to easily get models(.stl files) online.
&emsp;  
&emsp;  
The sdf part is from github repository: https://github.com/fogleman/sdf.git
Thanks to fogleman!
&emsp;  
&emsp;  
You can view the webapp at https://qwangxiang-sdfonline-sdfonline-dyergp.streamlitapp.com/  
Any problems, **put forward issues** or contact me at **qwangxiang@sjtu.edu.cn**
