import csv, requests, urllib, json
file1 = open('广州地址.csv', 'r', encoding='UTF-8')
read1 = csv.reader(file1)
position = [row[1] for row in read1]
file2 = open('D2常去地点距离.csv', 'r', encoding='UTF-8')
read2 = csv.reader(file2)
typeof = next(read2)
del(typeof[0])
ak = "mbgyNE5QQGb7NlGRcy1jHoqdF8F9HZD4"
r = 1000
resultCsvRow = []
for i in position:
    csvRow = [];
    csvRow.append(i)
    url = "https://api.map.baidu.com/geocoding/v3/?address=%s&output=json&ak=%s&city=%s"%(i, ak, "广州市")    
    lat_lng = eval(requests.get(url).text)['result']['location']
    lat = lat_lng['lat']
    lng = lat_lng['lng']
    for j in typeof:
        print(j)
        minDistance = 100000000
        pageOrder = 0
        url1 = "http://api.map.baidu.com/place/v2/search?ak=%s&output=json&query=%s&location=%s,%s&page_size=20&page_num=%s&radius=%s"%(ak, j ,lat, lng, pageOrder, r)
        result = eval(requests.get(url1).text)
        pageTotal = int(result['total']) / 20
        while (pageOrder < pageTotal):
            url2 = "http://api.map.baidu.com/place/v2/search?ak=%s&output=json&query=%s&location=%s,%s&page_size=20&page_num=%s&radius=%s"%(ak, j ,lat, lng, pageOrder, r)
            pageOrder = pageOrder + 1
            for k in eval(requests.get(url2).text)['results']:
                lat1 = k['location']['lat']
                lng1 = k['location']['lng']
                url3  = "https://api.map.baidu.com/routematrix/v2/walking?output=json&origins=%s,%s&destinations=%s,%s&ak=%s"%(lat, lng, lat1, lng1, ak)
                walk = json.loads(urllib.request.urlopen(url3).read())
                status = walk['status']
                if status == 0:
                    distance = walk['result'][0]['distance']['value']
                else:
                    distance = 100000000
                if (distance <= minDistance):
                    minDistance = distance
        csvRow.append(minDistance)
    print(csvRow)
    break
