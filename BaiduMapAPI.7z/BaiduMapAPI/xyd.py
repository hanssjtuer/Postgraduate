import csv
import urllib,json
from urllib.parse import quote
import string
import requests

ak = 'E8sqHFhRFC0hkW7Wen17yKVDLF9BGPtI'
url = 'https://api.map.baidu.com/geocoding/v3/?address='

def create_json(url):   
    url = quote(url, safe=string.printable)
    url_file = urllib.request.urlopen(url)
    json_file = url_file.read()
    json_dict = json.loads(json_file)
    return json_dict

def read_json(json_dict,pois_list):
    temp=[]
    for text in json_dict["results"]:
        temp.append(text["name"]+":"+str(text["location"]['lat'])+","+str(text["location"]['lng']))
    return temp

#获得地址经纬度
def get_latlng(Fir_KeyWord,ak,Fir_region):
    Fir_region = "广州市"
    Sec_KeyWord = "公交站" 
    Fir_url = url+ str(Fir_KeyWord) + "&output=json&ak=" + str(ak) + "&city=" + Fir_region
    html = requests.get(url = Fir_url)
    html.encoding = html.apparent_encoding
    page_text = html.text
    list = eval(page_text)
    data = list['result']
    data_ = data["location"]
    Sec_location_lat = data_['lat']
    Sec_location_lng = data_['lng']
    return Sec_location_lat,Sec_location_lng

#获得目标变量
def get_num( page_size,radius,ak,Sec_KeyWord,Sec_location_lat,Sec_location_lng,Sec_page_num):

    Sec_url = "http://api.map.baidu.com/place/v2/search?ak=" + str(ak) + "&output=json&query=" + \
                  str(Sec_KeyWord) + "&location=" + str(Sec_location_lat) + "," + str(Sec_location_lng) + "&page_size=" + \
                  str(page_size) + "&page_num=" + str(Sec_page_num) + "&radius=" + str(radius)
    #print("寻找" + Fir_KeyWord + "的百度地图周边半径" + str(radius) + "m的网址:" + Sec_url)
    Sec_pois_list = []
    Sec_json_dict = create_json(Sec_url)
    Sec_pois_list = read_json(Sec_json_dict, Sec_pois_list)
    Sec_total = int(Sec_json_dict["total"])
    Sec_Page = Sec_total / page_size
    _All_ = []
    while (Sec_page_num < Sec_Page):
        if Sec_pois_list:
                Sec_url = "http://api.map.baidu.com/place/v2/search?ak=" + str(ak) + "&output=json&query=" + \
                          str(Sec_KeyWord) + "&location=" + str(Sec_location_lat) + "," + str(Sec_location_lng) + "&page_size=" + \
                          str(page_size) + "&page_num=" + str(Sec_page_num) + "&radius=" + str(radius)
                Sec_page_num=Sec_page_num+1
                Sec_json_dict = create_json(Sec_url)
                for i in read_json(Sec_json_dict, Sec_pois_list):                    
                    _All_.append(i)      
    return _All_

def get_min_dis_time(Fir_KeyWord,_All_):
    temp_dis = []
    temp_time = []
    temp_name = []
    for i in _All_:
        lat = i.split(':')[1].split(',')[0]
        lng = i.split(':')[1].split(',')[1]
        name = i.split(':')[0]
        temp_name.append(name)
        dis_url  = "https://api.map.baidu.com/routematrix/v2/walking?output=json&origins=%s,%s&destinations=%s,%s&ak=%s"%(Sec_location_lat,Sec_location_lng,lat,lng,ak)
        result_walk = json.loads(urllib.request.urlopen(dis_url).read())
        status_walk = result_walk['status']
        if status_walk == 0:
                distance_walk = result_walk['result'][0]['distance']['value']
                timesec_walk = result_walk['result'][0]['duration']['value']
                temp_dis.append(distance_walk)
                temp_time.append(timesec_walk)
    if(temp_dis == []):
        temp_dis.append(0)
        temp_time.append(0)
        temp_name.append("None")
    min_dis = min(temp_dis)
    min_time = temp_time[temp_dis.index(min_dis)]
    min_dis_sta = temp_name[temp_dis.index(min_dis)]
    return "%s\t%s\t%sm\t%ss\t%s\n"%(Fir_KeyWord, len(_All_), min_dis,min_time,min_dis_sta)

f1 = open('广州地址.csv','r',encoding='UTF-8')
reader = csv.reader(f1)

Fir_pois_list = [row[1] for row in reader]
f2 = open('广州地址周边公交站.csv','w')
f_writer = csv.writer(f2,dialect='excel')
for i in Fir_pois_list:
    Fir_KeyWord = i
    Fir_region = "广州市"
    Sec_KeyWord = "公交站" 
    Sec_location_lat,Sec_location_lng = get_latlng(Fir_KeyWord,ak,Fir_region)
    
    page_size = 20
    radius = 500
    Sec_page_num = 0
    _All_ = get_num( page_size,radius,ak,Sec_KeyWord,Sec_location_lat,Sec_location_lng,Sec_page_num)
    
    result = get_min_dis_time(Fir_KeyWord,_All_)
    print(result)
    f_writer.writerow(result.split('\t'))
f2.close()
print("Success!")
