import csv, requests, urllib, json
from geopy.distance import geodesic
file1 = open('广州地址.csv', 'r', encoding='UTF-8')
read1 = csv.reader(file1)
position = [row[1] for row in read1]
file2 = open('D2常去地点距离.csv', 'r', encoding='UTF-8')
read2 = csv.reader(file2)
typeof = next(read2)
head = typeof
del(typeof[0])
file3 = open('D2.csv','w')
write = csv.writer(file3, dialect='excel')
write.writerow(typeof)
ak = "mbgyNE5QQGb7NlGRcy1jHoqdF8F9HZD4"
r = 100000
for i in position:
    csvRow = [];
    csvRow.append(i)
    url = "https://api.map.baidu.com/geocoding/v3/?address=%s&output=json&ak=%s&city=%s"%(i, ak, "广州市")    
    lat_lng = eval(requests.get(url).text)['result']['location']
    lat = float(lat_lng['lat'])
    lng = float(lat_lng['lng'])
    for j in typeof:
        minDistance = 100000000
        pageOrder = 0
        url1 = "http://api.map.baidu.com/place/v2/search?ak=%s&output=json&query=%s&location=%s,%s&page_size=20&page_num=%s&radius=%s"%(ak, j ,lat, lng, pageOrder, r)
        result = eval(requests.get(url1).text)
        pageTotal = int(result['total']) / 20
        while (pageOrder < pageTotal):
            url2 = "http://api.map.baidu.com/place/v2/search?ak=%s&output=json&query=%s&location=%s,%s&page_size=20&page_num=%s&radius=%s"%(ak, j ,lat, lng, pageOrder, r)
            pageOrder = pageOrder + 1
            for k in eval(requests.get(url2).text)['results']:
                lat1 = float(k['location']['lat'])
                lng1 = float(k['location']['lng'])
                distance = geodesic((lat1, lng1), (lat, lng)).m
                if (distance <= minDistance):
                    minDistance = distance
        csvRow.append(minDistance)
        write.writerow(csvRow)
