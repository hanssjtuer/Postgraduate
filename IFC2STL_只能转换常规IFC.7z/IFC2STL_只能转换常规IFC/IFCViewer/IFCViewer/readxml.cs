﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Threading;

namespace IFCViewer
{
    class readxml
    {
        public static int count = 1;
        public static Dictionary<string, string> dict = new Dictionary<string, string>();
        private delegate void SetPos(int ipos, string vinfo);
        public static void do_stl()
        {
            string path = "TreeXml.xml";
            XmlDocument Doc = new XmlDocument();
            Doc.Load(path);
            XmlNode pro = Doc.SelectNodes("/Tree/Node")[1];
            DelectDir("GIM/MOD");
            DelectDir("GIM/PHM");
            readnode(pro);
            //Console.ReadKey();
        }
        public static void DelectDir(string srcPath)
        {
            try
            {
                DirectoryInfo dir = new DirectoryInfo(srcPath);
                FileSystemInfo[] fileinfo = dir.GetFileSystemInfos();
                foreach (FileSystemInfo i in fileinfo)
                {
                    if (i is DirectoryInfo)
                    {
                        DirectoryInfo subdir = new DirectoryInfo(i.FullName);
                        subdir.Delete(true);
                    }
                    else
                    {
                        File.Delete(i.FullName);
                    }
                }
            }
            catch (Exception e)
            {
                throw;
            }
        }
        public static void readnode(XmlNode node)
        {
            int length = node.ChildNodes.Count;
            foreach (XmlNode i in node.ChildNodes)
            {
                foreach (XmlAttribute j in i.Attributes)
                {
                    if (j.Value.Contains("IfcWall") || j.Value.Contains("IfcWindow") || j.Value.Contains("IfcBeam")|| j.Value.Contains("IfcBuildingElementProxy") ||
                j.Value.Contains("IfcDoor") || j.Value.Contains("IfcColumn") || j.Value.Contains("IfcSlab"))
                    {
                        string data = j.Value.Split(')')[1]; 
                        List<List<double>> vertexes = new List<List<double>>();
                        double[] data_double = data.Split(',').Select(n => Convert.ToDouble(n)).ToArray();
                        for (int p = 0; p < data_double.Length / 3; p++)
                        {
                            vertexes.Add(new List<double>() { data_double[p * 3], data_double[p * 3 + 1], data_double[p * 3 + 2] });
                        }
                        string guid = Guid.NewGuid().ToString();
                        FileStream fs = new FileStream("GIM/MOD/" + guid + ".stl", FileMode.Create, FileAccess.ReadWrite);
                        StreamWriter sw = new StreamWriter(fs);
                        FileStream fs1 = new FileStream("GIM/PHM/" + guid + ".phm", FileMode.Create, FileAccess.ReadWrite);
                        StreamWriter sw1 = new StreamWriter(fs1);
                        FileStream fs2 = new FileStream("GIM/PHM/" + guid + ".fam", FileMode.Create, FileAccess.ReadWrite);
                        StreamWriter sw2 = new StreamWriter(fs2);
                        string phm = "";
                        string fam = "";
                        phm = "SOLIDMODELS.NUM = 1\nSOLIDMODEL0 = " + guid + ".stl\nTRANSFORMMATRIX0 = 1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1\nCOLOR0 = 125,125,125";
                        sw1.Write(phm);
                        sw1.Flush();
                        sw1.Close();
                        string stl = "";
                        stl = stl + "solid\tpart\tstl\n";
                        for (int p = 0; p < vertexes.Count / 3; p++)
                        {
                            stl = stl + "facet\tnormal\t0\t0\t0\n";
                            stl = stl + "outer\tloop\n";
                            stl = stl + "vertex\t" + vertexes[p * 3][0] + "\t" + vertexes[p * 3][1] + "\t" + vertexes[p * 3][2] + "\n";
                            stl = stl + "vertex\t" + vertexes[p * 3 + 1][0] + "\t" + vertexes[p * 3 + 1][1] + "\t" + vertexes[p * 3 + 1][2] + "\n";
                            stl = stl + "vertex\t" + vertexes[p * 3 + 2][0] + "\t" + vertexes[p * 3 + 2][1] + "\t" + vertexes[p * 3 + 2][2] + "\n";
                            stl = stl + "endloop\n";
                            stl = stl + "endfacet\n";
                        }
                        stl = stl + "endsolid\tpart\tstl";
                        sw.Write(stl);
                        sw.Flush();
                        sw.Close();
                        sw2.Write(fam);
                        sw2.Flush();
                        sw2.Close();
                        count++;
                    }
                }
                readnode(i);
            }
        }
    }
}
