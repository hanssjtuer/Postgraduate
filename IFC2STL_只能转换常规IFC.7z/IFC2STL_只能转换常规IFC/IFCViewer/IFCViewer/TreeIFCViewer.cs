﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Drawing;

#if _WIN64
using int_t = System.Int64;
#else
using int_t = System.Int32;
#endif

namespace IFCViewer
{
    /// <summary>
    /// Presentation of an IFC structure as a tree.
    /// </summary>
    class TreeIFCViewer : IIFCViewer
    {
        #region Members

        /// <summary>
        /// IFC Model
        /// </summary>
        private IFCModel _model = null;

        /// <summary>
        /// Tree control
        /// </summary>
        public static TreeView _treeControl = null;

        /// <summary>
        /// Zero-based indices of the images inside the image list.
        /// </summary>
        public const int IMAGE_CHECKED = 0;
        public const int IMAGE_MIDDLE = 1;
        public const int IMAGE_UNCHECKED = 2;
        public const int IMAGE_PROPERTY_SET = 3;
        public const int IMAGE_PROPERTY = 4;
        public const int IMAGE_NOT_REFERENCED = 5;

        #endregion // Members

        /// <summary>
        /// ctor
        /// </summary>
        public TreeIFCViewer(IFCModel model, TreeView treeControl)
        {
            if (model == null)
            {
                throw new ArgumentNullException();
            }

            _model = model;

            _model.ModelLoaded += (s, e) =>
            {
                _treeControl.Nodes.Clear();

                if (_model.Model == 0)
                {
                    return;
                }

                if (_model.Root == null)
                {
                    return;
                }

                Cursor.Current = Cursors.WaitCursor;                

                CreateHeaderTreeItems();
                CreateProjectTreeItems();
                CreateNotReferencedTreeItems();
            };

            if (treeControl == null)
            {
                throw new ArgumentNullException();
            }

            _treeControl = treeControl;

            /*
             * NodeMouseClick event handler
             */
            _treeControl.NodeMouseClick += (s, e) =>
                {
                    if (e.Button == System.Windows.Forms.MouseButtons.Left)
                    {
                        Rectangle rcIcon = new Rectangle(e.Node.Bounds.Location - new Size(16, 0), new Size(16, 16));
                        if (!rcIcon.Contains(e.Location))
                        {
                            return;
                        }

                        if (e.Node.Tag == null)
                        {
                            // skip properties
                            return;
                        }

                        switch (e.Node.ImageIndex)
                        {
                            case IMAGE_CHECKED:
                            case IMAGE_MIDDLE:
                                {
                                    e.Node.ImageIndex = e.Node.SelectedImageIndex = IMAGE_UNCHECKED;

                                    UpdateChildrenTreeItems(e.Node);
                                    UpdateParentTreeItems(e.Node);

                                    this.Renderer.Redraw();
                                }
                                break;

                            case IMAGE_UNCHECKED:
                                {
                                    e.Node.ImageIndex = e.Node.SelectedImageIndex = IMAGE_CHECKED;

                                    UpdateChildrenTreeItems(e.Node);
                                    UpdateParentTreeItems(e.Node);

                                    this.Renderer.Redraw();
                                }
                                break;
                        } // switch (e.Node.ImageIndex)
                    } // if (e.Button == System.Windows.Forms.MouseButtons.Left)
                    else
                    {
                        if (e.Button == System.Windows.Forms.MouseButtons.Right)
                        {
                            _treeControl.SelectedNode = e.Node;
                        }
                    }
                };

            /*
             * AfterSelect event handler
             */
            _treeControl.AfterSelect += (s, e) =>
                {
                    if (e.Node.Tag == null)
                    {
                        // skip properties
                        return;
                    }

                    if (e.Node.ImageIndex != IMAGE_CHECKED)
                    {
                        // skip invisible & not referenced items
                        return;
                    }

                    this.Renderer.OnSelect((e.Node.Tag as TreeIFCitemView).Item);
                };

            /*
             * MouseUp event handler
             */
            _treeControl.MouseUp += (s, e) =>
                {
                    if (e.Button == System.Windows.Forms.MouseButtons.Right)
                    {
                        ContextMenuStrip contextMenu = new ContextMenuStrip();
                        contextMenu.Items.Clear();

                        Dictionary<string, int> dicIfcType2VisibleCount = new Dictionary<string, int>();
                        foreach (var item in _model.Geometry)
                        {
                            if (!dicIfcType2VisibleCount.ContainsKey(item.ifcType))
                            {
                                dicIfcType2VisibleCount[item.ifcType] = 0;
                            }

                            if (item.ifcTreeView.IsVisible)
                            {
                                dicIfcType2VisibleCount[item.ifcType]++;
                            }
                        }

                        foreach (var pair in dicIfcType2VisibleCount)
                        {
                            ToolStripMenuItem menuItem = contextMenu.Items.Add(pair.Key) as ToolStripMenuItem;
                            menuItem.CheckOnClick = true;
                            menuItem.Checked = pair.Value > 0;

                            menuItem.Click += new EventHandler(delegate(object item, EventArgs args)
                            {
                                foreach (TreeNode node in _treeControl.Nodes)
                                {
                                    OnContextMenu_UpdateTreeElement(node, pair.Key, menuItem.Checked);
                                }

                                this.Renderer.Redraw();
                            });
                        }

                        contextMenu.Show(_treeControl, new Point(e.X, e.Y));
                    }
                };
        }

        /// <summary>
        /// Helper
        /// </summary>
        private void CreateHeaderTreeItems()
        {
            // Header info
            TreeNode tnHeaderInfo = _treeControl.Nodes.Add("Header Info");
            tnHeaderInfo.ImageIndex = tnHeaderInfo.SelectedImageIndex = IMAGE_PROPERTY_SET;

            // Descriptions
            TreeNode tnDescriptions = tnHeaderInfo.Nodes.Add("Descriptions");
            tnDescriptions.ImageIndex = tnDescriptions.SelectedImageIndex = IMAGE_PROPERTY;

            int i = 0;
            IntPtr description;
            while (IfcEngine.x86_64.GetSPFFHeaderItem(_model.Model, 0, i++, IfcEngine.x86_64.sdaiUNICODE, out description) == 0)
            {
                TreeNode tnDescription = tnDescriptions.Nodes.Add(Marshal.PtrToStringUni(description));
                tnDescription.ImageIndex = tnDescription.SelectedImageIndex = IMAGE_PROPERTY;
            }

            // ImplementationLevel
            IntPtr implementationLevel;
            IfcEngine.x86_64.GetSPFFHeaderItem(_model.Model, 1, 0, IfcEngine.x86_64.sdaiUNICODE, out implementationLevel);

            TreeNode tnImplementationLevel = tnHeaderInfo.Nodes.Add("ImplementationLevel = '" + Marshal.PtrToStringUni(implementationLevel) + "'");
            tnImplementationLevel.ImageIndex = tnImplementationLevel.SelectedImageIndex = IMAGE_PROPERTY;

            // Name
            IntPtr name;
            IfcEngine.x86_64.GetSPFFHeaderItem(_model.Model, 2, 0, IfcEngine.x86_64.sdaiUNICODE, out name);

            TreeNode tnName = tnHeaderInfo.Nodes.Add("Name = '" + Marshal.PtrToStringUni(name) + "'");
            tnName.ImageIndex = tnName.SelectedImageIndex = IMAGE_PROPERTY;

            // TimeStamp
            IntPtr timeStamp;
            IfcEngine.x86_64.GetSPFFHeaderItem(_model.Model, 3, 0, IfcEngine.x86_64.sdaiUNICODE, out timeStamp);

            TreeNode tnTimeStamp = tnHeaderInfo.Nodes.Add("TimeStamp = '" + Marshal.PtrToStringUni(timeStamp) + "'");
            tnTimeStamp.ImageIndex = tnTimeStamp.SelectedImageIndex = IMAGE_PROPERTY;

            // Authors
            TreeNode tnAuthors = tnHeaderInfo.Nodes.Add("Authors");
            tnAuthors.ImageIndex = tnAuthors.SelectedImageIndex = IMAGE_PROPERTY;

            i = 0;
            IntPtr author;
            while (IfcEngine.x86_64.GetSPFFHeaderItem(_model.Model, 4, i++, IfcEngine.x86_64.sdaiUNICODE, out author) == 0)
            {
                TreeNode tnAuthor = tnAuthors.Nodes.Add(Marshal.PtrToStringUni(author));
                tnAuthor.ImageIndex = tnAuthor.SelectedImageIndex = IMAGE_PROPERTY;
            }

            // Organizations
            TreeNode tnOrganizations = tnHeaderInfo.Nodes.Add("Organizations");
            tnOrganizations.ImageIndex = tnOrganizations.SelectedImageIndex = IMAGE_PROPERTY;

            i = 0;
            IntPtr organization;
            while (IfcEngine.x86_64.GetSPFFHeaderItem(_model.Model, 5, i++, IfcEngine.x86_64.sdaiUNICODE, out organization) == 0)
            {
                TreeNode tnOrganization = tnOrganizations.Nodes.Add(Marshal.PtrToStringUni(organization));
                tnOrganization.ImageIndex = tnOrganization.SelectedImageIndex = IMAGE_PROPERTY;
            }

            // PreprocessorVersion
            IntPtr preprocessorVersion;
            IfcEngine.x86_64.GetSPFFHeaderItem(_model.Model, 6, 0, IfcEngine.x86_64.sdaiUNICODE, out preprocessorVersion);

            TreeNode tnPreprocessorVersion = tnHeaderInfo.Nodes.Add("PreprocessorVersion = '" + Marshal.PtrToStringUni(preprocessorVersion) + "'");
            tnPreprocessorVersion.ImageIndex = tnPreprocessorVersion.SelectedImageIndex = IMAGE_PROPERTY;

            // OriginatingSystem
            IntPtr originatingSystem;
            IfcEngine.x86_64.GetSPFFHeaderItem(_model.Model, 7, 0, IfcEngine.x86_64.sdaiUNICODE, out originatingSystem);

            TreeNode tnOriginatingSystem = tnHeaderInfo.Nodes.Add("OriginatingSystem = '" + Marshal.PtrToStringUni(originatingSystem) + "'");
            tnOriginatingSystem.ImageIndex = tnOriginatingSystem.SelectedImageIndex = IMAGE_PROPERTY;

            // Authorization
            IntPtr authorization;
            IfcEngine.x86_64.GetSPFFHeaderItem(_model.Model, 8, 0, IfcEngine.x86_64.sdaiUNICODE, out authorization);

            TreeNode tnAuthorization = tnHeaderInfo.Nodes.Add("Authorization = '" + Marshal.PtrToStringUni(authorization) + "'");
            tnAuthorization.ImageIndex = tnAuthorization.SelectedImageIndex = IMAGE_PROPERTY;

            // FileSchemas
            TreeNode tnFileSchemas = tnHeaderInfo.Nodes.Add("FileSchemas");
            tnFileSchemas.ImageIndex = tnFileSchemas.SelectedImageIndex = IMAGE_PROPERTY;

            i = 0;
            IntPtr fileSchema;
            while (IfcEngine.x86_64.GetSPFFHeaderItem(_model.Model, 9, i++, IfcEngine.x86_64.sdaiUNICODE, out fileSchema) == 0)
            {
                TreeNode tnFileSchema = tnFileSchemas.Nodes.Add(Marshal.PtrToStringUni(fileSchema));
                tnFileSchema.ImageIndex = tnFileSchema.SelectedImageIndex = IMAGE_PROPERTY;
            }
        }

        /// <summary>
        /// Helper
        /// </summary>
        private void CreateProjectTreeItems()
        {
            int_t iEntityID = IfcEngine.x86_64.sdaiGetEntityExtentBN(_model.Model, "IfcProject");
            int_t iEntitiesCount = IfcEngine.x86_64.sdaiGetMemberCount(iEntityID);

            for (int_t iEntity = 0; iEntity < iEntitiesCount; iEntity++)
            {
                int_t iInstance = 0;
                IfcEngine.x86_64.engiGetAggrElement(iEntityID, iEntity, IfcEngine.x86_64.sdaiINSTANCE, out iInstance);

                TreeIFCitemView ifcTreeItem = new TreeIFCitemView(iInstance);

                CreateTreeItem(null, ifcTreeItem);
                ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_CHECKED;

                AddChildrenTreeItems(ifcTreeItem, iInstance, "IfcSite");
            } // for (int_t iEntity = ...
        }

        /// <summary>
        /// Helper
        /// </summary>
        private void CreateNotReferencedTreeItems()
        {
            TreeIFCitemView ifcTreeItem = new TreeIFCitemView();
            ifcTreeItem.Node = _treeControl.Nodes.Add("Not Referenced");
            ifcTreeItem.Node.ForeColor = Color.Gray;
            ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_CHECKED;
            ifcTreeItem.Node.Tag = ifcTreeItem;

            FindNonReferencedIFCItems(_model.Root, ifcTreeItem.Node);

            if (ifcTreeItem.Node.Nodes.Count == 0)
            {
                // don't show empty Not Referenced item
                _treeControl.Nodes.Remove(ifcTreeItem.Node);
            }
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="ifcParent"></param>
        /// <param name="iParentInstance"></param>
        /// <param name="strEntityName"></param>

        private void AddChildrenTreeItems(TreeIFCitemView ifcParent, int_t iParentInstance, string strEntityName)
        {
            // check for decomposition
            IntPtr decompositionInstance;
            IfcEngine.x86_64.sdaiGetAttrBN(iParentInstance, "IsDecomposedBy", IfcEngine.x86_64.sdaiAGGR, out decompositionInstance);

            if (decompositionInstance == IntPtr.Zero)
            {
                return;
            }

            int_t iDecompositionsCount = IfcEngine.x86_64.sdaiGetMemberCount((int_t)decompositionInstance);
            for (int_t iDecomposition = 0; iDecomposition < iDecompositionsCount; iDecomposition++)
            {
                int_t iDecompositionInstance = 0;
                IfcEngine.x86_64.engiGetAggrElement((int_t)decompositionInstance, iDecomposition, IfcEngine.x86_64.sdaiINSTANCE, out iDecompositionInstance);

                if (!IsInstanceOf(iDecompositionInstance, "IFCRELAGGREGATES"))
                {
                    continue;
                }

                IntPtr objectInstances;
                IfcEngine.x86_64.sdaiGetAttrBN(iDecompositionInstance, "RelatedObjects", IfcEngine.x86_64.sdaiAGGR, out objectInstances);

                int_t iObjectsCount = IfcEngine.x86_64.sdaiGetMemberCount((int_t)objectInstances);
                for (int_t iObject = 0; iObject < iObjectsCount; iObject++)
                {
                    int_t iObjectInstance = 0;
                    IfcEngine.x86_64.engiGetAggrElement((int_t)objectInstances, iObject, IfcEngine.x86_64.sdaiINSTANCE, out iObjectInstance);

                    if (!IsInstanceOf(iObjectInstance, strEntityName))
                    {
                        continue;
                    }

                    TreeIFCitemView ifcTreeItem = new TreeIFCitemView(iObjectInstance);

                    CreateTreeItem(ifcParent, ifcTreeItem);
                    ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_CHECKED;

                    switch (strEntityName)
                    {
                        case "IfcSite":
                            {
                                AddChildrenTreeItems(ifcTreeItem, iObjectInstance, "IfcBuilding");
                            }
                            break;

                        case "IfcBuilding":
                            {
                                AddChildrenTreeItems(ifcTreeItem, iObjectInstance, "IfcBuildingStorey");
                            }
                            break;

                        case "IfcBuildingStorey":
                            {
                                AddElementTreeItems(ifcTreeItem, iObjectInstance);
                            }
                            break;

                        default:
                            break;
                    }
                } // for (int_t iObject = ...
            } // for (int_t iDecomposition = ...
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="ifcParent"></param>
        /// <param name="iParentInstance"></param>     
        private void AddElementTreeItems(TreeIFCitemView ifcParent, int_t iParentInstance)
        {
            IntPtr decompositionInstance;
            IfcEngine.x86_64.sdaiGetAttrBN(iParentInstance, "IsDecomposedBy", IfcEngine.x86_64.sdaiAGGR, out decompositionInstance);

            if (decompositionInstance == IntPtr.Zero)
            {
                return;
            }

            int_t iDecompositionsCount = IfcEngine.x86_64.sdaiGetMemberCount((int_t)decompositionInstance);
            for (int_t iDecomposition = 0; iDecomposition < iDecompositionsCount; iDecomposition++)
            {
                int_t iDecompositionInstance = 0;
                IfcEngine.x86_64.engiGetAggrElement((int_t)decompositionInstance, iDecomposition, IfcEngine.x86_64.sdaiINSTANCE, out iDecompositionInstance);

                if (!IsInstanceOf(iDecompositionInstance, "IFCRELAGGREGATES"))
                {
                    continue;
                }

                IntPtr objectInstances;
                IfcEngine.x86_64.sdaiGetAttrBN(iDecompositionInstance, "RelatedObjects", IfcEngine.x86_64.sdaiAGGR, out objectInstances);

                int_t iObjectsCount = IfcEngine.x86_64.sdaiGetMemberCount((int_t)objectInstances);
                for (int_t iObject = 0; iObject < iObjectsCount; iObject++)
                {
                    int_t iObjectInstance = 0;
                    IfcEngine.x86_64.engiGetAggrElement((int_t)objectInstances, iObject, IfcEngine.x86_64.sdaiINSTANCE, out iObjectInstance);

                    TreeIFCitemView ifcTreeItem = new TreeIFCitemView(iObjectInstance, FindIFCItem(_model.Root, iObjectInstance));

                    CreateTreeItem(ifcParent, ifcTreeItem);

                    if (ifcTreeItem.Item != null)
                    {
                        ifcTreeItem.Item.ifcTreeView = ifcTreeItem;
                        ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_CHECKED;
                    }
                    else
                    {
                        ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_NOT_REFERENCED;
                    }
                } // for (int_t iObject = ...
            } // for (int_t iDecomposition = ...

            // check for elements
            IntPtr elementsInstance;
            IfcEngine.x86_64.sdaiGetAttrBN(iParentInstance, "ContainsElements", IfcEngine.x86_64.sdaiAGGR, out elementsInstance);

            if (elementsInstance == IntPtr.Zero)
            {
                return;
            }

            int_t iElementsCount = IfcEngine.x86_64.sdaiGetMemberCount((int_t)elementsInstance);
            for (int_t iElement = 0; iElement < iElementsCount; iElement++)
            {
                int_t iElementInstance = 0;
                IfcEngine.x86_64.engiGetAggrElement((int_t)elementsInstance, iElement, IfcEngine.x86_64.sdaiINSTANCE, out iElementInstance);

                if (!IsInstanceOf(iElementInstance, "IFCRELCONTAINEDINSPATIALSTRUCTURE"))
                {
                    continue;
                }

                IntPtr objectInstances;
                IfcEngine.x86_64.sdaiGetAttrBN(iElementInstance, "RelatedElements", IfcEngine.x86_64.sdaiAGGR, out objectInstances);

                int_t iObjectsCount = IfcEngine.x86_64.sdaiGetMemberCount((int_t)objectInstances);
                for (int_t iObject = 0; iObject < iObjectsCount; iObject++)
                {
                    int_t iObjectInstance = 0;
                    IfcEngine.x86_64.engiGetAggrElement((int_t)objectInstances, iObject, IfcEngine.x86_64.sdaiINSTANCE, out iObjectInstance);

                    TreeIFCitemView ifcTreeItem = new TreeIFCitemView(iObjectInstance, FindIFCItem(_model.Root, iObjectInstance));

                    CreateTreeItem(ifcParent, ifcTreeItem);
                    
                    if (ifcTreeItem.Item != null)
                    {
                        ifcTreeItem.Item.ifcTreeView = ifcTreeItem;
                        ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_CHECKED;
                    }
                    else
                    {
                        ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_NOT_REFERENCED;
                    }                    

                    IntPtr definedByInstances;
                    IfcEngine.x86_64.sdaiGetAttrBN(iObjectInstance, "IsDefinedBy", IfcEngine.x86_64.sdaiAGGR, out definedByInstances);

                    if (definedByInstances == IntPtr.Zero)
                    {
                        continue;
                    }

                    int_t iDefinedByCount = IfcEngine.x86_64.sdaiGetMemberCount((int_t)definedByInstances);
                    for (int_t iDefinedBy = 0; iDefinedBy < iDefinedByCount; iDefinedBy++)
                    {
                        int_t iDefinedByInstance = 0;
                        IfcEngine.x86_64.engiGetAggrElement((int_t)definedByInstances, iDefinedBy, IfcEngine.x86_64.sdaiINSTANCE, out iDefinedByInstance);

                        if (IsInstanceOf(iDefinedByInstance, "IFCRELDEFINESBYPROPERTIES"))
                        {
                            AddPropertyTreeItems(ifcTreeItem, iDefinedByInstance);
                        }
                        else
                        {
                            if (IsInstanceOf(iDefinedByInstance, "IFCRELDEFINESBYTYPE"))
                            {
                                // NA
                            }
                        }
                    }
                } // for (int_t iObject = ...
            } // for (int_t iDecomposition = ...
        }        

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="ifcParent"></param>
        /// <param name="iParentInstance"></param>     
        private void AddPropertyTreeItems(TreeIFCitemView ifcParent, int_t iParentInstance)
        {
            IntPtr propertyInstances;
            IfcEngine.x86_64.sdaiGetAttrBN(iParentInstance, "RelatingPropertyDefinition", IfcEngine.x86_64.sdaiINSTANCE, out propertyInstances);

            if (IsInstanceOf((int_t)propertyInstances, "IFCELEMENTQUANTITY"))
            {
                TreeIFCitemView ifcPropertySetTreeItem = new TreeIFCitemView((int_t)propertyInstances);

                CreateTreeItem(ifcParent, ifcPropertySetTreeItem);
                ifcPropertySetTreeItem.Node.ImageIndex = ifcPropertySetTreeItem.Node.SelectedImageIndex = IMAGE_PROPERTY_SET;

                // check for quantity
                IntPtr quantitiesInstance;
                IfcEngine.x86_64.sdaiGetAttrBN((int_t)propertyInstances, "Quantities", IfcEngine.x86_64.sdaiAGGR, out quantitiesInstance);

                if (quantitiesInstance == IntPtr.Zero)
                {
                    return;
                }

                int_t iQuantitiesCount = IfcEngine.x86_64.sdaiGetMemberCount((int_t)quantitiesInstance);
                for (int_t iQuantity = 0; iQuantity < iQuantitiesCount; iQuantity++)
                {
                    int_t iQuantityInstance = 0;
                    IfcEngine.x86_64.engiGetAggrElement((int_t)quantitiesInstance, iQuantity, IfcEngine.x86_64.sdaiINSTANCE, out iQuantityInstance);

                    TreeIFCitemView ifcQuantityTreeItem = new TreeIFCitemView(iQuantityInstance);

                    if (IsInstanceOf(iQuantityInstance, "IFCQUANTITYLENGTH"))
                        CreatePropertyTreeItem(ifcPropertySetTreeItem, ifcQuantityTreeItem, "IFCQUANTITYLENGTH");
                    else
                        if (IsInstanceOf(iQuantityInstance, "IFCQUANTITYAREA"))
                            CreatePropertyTreeItem(ifcPropertySetTreeItem, ifcQuantityTreeItem, "IFCQUANTITYAREA");
                        else
                            if (IsInstanceOf(iQuantityInstance, "IFCQUANTITYVOLUME"))
                                CreatePropertyTreeItem(ifcPropertySetTreeItem, ifcQuantityTreeItem, "IFCQUANTITYVOLUME");
                            else
                                if (IsInstanceOf(iQuantityInstance, "IFCQUANTITYCOUNT"))
                                    CreatePropertyTreeItem(ifcPropertySetTreeItem, ifcQuantityTreeItem, "IFCQUANTITYCOUNT");
                                else
                                    if (IsInstanceOf(iQuantityInstance, "IFCQUANTITYWEIGTH"))
                                        CreatePropertyTreeItem(ifcPropertySetTreeItem, ifcQuantityTreeItem, "IFCQUANTITYWEIGTH");
                                    else
                                        if (IsInstanceOf(iQuantityInstance, "IFCQUANTITYTIME"))
                                            CreatePropertyTreeItem(ifcPropertySetTreeItem, ifcQuantityTreeItem, "IFCQUANTITYTIME");
                } // for (int iQuantity = ...
            }
            else
            {
                if (IsInstanceOf((int_t)propertyInstances, "IFCPROPERTYSET"))
                {
                    TreeIFCitemView ifcPropertySetTreeItem = new TreeIFCitemView((int_t)propertyInstances);

                    CreateTreeItem(ifcParent, ifcPropertySetTreeItem);
                    ifcPropertySetTreeItem.Node.ImageIndex = ifcPropertySetTreeItem.Node.SelectedImageIndex = IMAGE_PROPERTY_SET;

                    // check for quantity
                    IntPtr propertiesInstance;
                    IfcEngine.x86_64.sdaiGetAttrBN((int_t)propertyInstances, "HasProperties", IfcEngine.x86_64.sdaiAGGR, out propertiesInstance);

                    if (propertiesInstance == IntPtr.Zero)
                    {
                        return;
                    }

                    int_t iPropertiesCount = IfcEngine.x86_64.sdaiGetMemberCount((int_t)propertiesInstance);
                    for (int_t iProperty = 0; iProperty < iPropertiesCount; iProperty++)
                    {
                        int_t iPropertyInstance = 0;
                        IfcEngine.x86_64.engiGetAggrElement((int_t)propertiesInstance, iProperty, IfcEngine.x86_64.sdaiINSTANCE, out iPropertyInstance);
                        
                        if (!IsInstanceOf(iPropertyInstance, "IFCPROPERTYSINGLEVALUE"))
                            continue;

                        TreeIFCitemView ifcPropertyTreeItem = new TreeIFCitemView(iPropertyInstance);

                        CreatePropertyTreeItem(ifcPropertySetTreeItem, ifcPropertyTreeItem, "IFCPROPERTYSINGLEVALUE");
                    } // for (int iProperty = ...
                }
            }
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="ifcParent"></param>
        /// <param name="ifcItem"></param>
        private void CreateTreeItem(TreeIFCitemView ifcParent, TreeIFCitemView ifcItem)
        {
            string strItemText = BuildItemText(ifcItem.Instance);

            if ((ifcParent != null) && (ifcParent.Node != null))
            {
                ifcItem.Node = ifcParent.Node.Nodes.Add(strItemText);
            }
            else
            {
                ifcItem.Node = _treeControl.Nodes.Add(strItemText);
            }

            if (ifcItem.Item == null)
            {
                // item without visual representation
                ifcItem.Node.ForeColor = Color.Gray;
            }

            ifcItem.Node.Tag = ifcItem;
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="ifcParent"></param>
        /// <param name="ifcItem"></param>
        /// <param name="strProperty"></param>
        private void CreatePropertyTreeItem(TreeIFCitemView ifcParent, TreeIFCitemView ifcItem, string strProperty)
        {
            //IntPtr ifcType = IfcEngine.x86.engiGetInstanceClassInfo(ifcItem.instance);
            int_t entity = IfcEngine.x86_64.sdaiGetInstanceType(ifcItem.Instance);
            IntPtr entityNamePtr = IntPtr.Zero;
            IfcEngine.x86_64.engiGetEntityName(entity, IfcEngine.x86_64.sdaiUNICODE, out entityNamePtr);
            //string strIfcType = Marshal.PtrToStringUni(ifcType);
            string strIfcType = Marshal.PtrToStringUni(entityNamePtr);

            IntPtr name;
            IfcEngine.x86_64.sdaiGetAttrBN(ifcItem.Instance, "Name", IfcEngine.x86_64.sdaiUNICODE, out name);

            string strName = Marshal.PtrToStringUni(name);

            string strValue = string.Empty;
            switch (strProperty)
            {
                case "IFCQUANTITYLENGTH":
                    {
                        IntPtr value;
                        IfcEngine.x86_64.sdaiGetAttrBN(ifcItem.Instance, "LengthValue", IfcEngine.x86_64.sdaiUNICODE, out value);

                        strValue = Marshal.PtrToStringUni(value);
                    }
                    break;

                case "IFCQUANTITYAREA":
                    {
                        IntPtr value;
                        IfcEngine.x86_64.sdaiGetAttrBN(ifcItem.Instance, "AreaValue", IfcEngine.x86_64.sdaiUNICODE, out value);

                        strValue = Marshal.PtrToStringUni(value);
                    }
                    break;

                case "IFCQUANTITYVOLUME":
                    {
                        IntPtr value;
                        IfcEngine.x86_64.sdaiGetAttrBN(ifcItem.Instance, "VolumeValue", IfcEngine.x86_64.sdaiUNICODE, out value);

                        strValue = Marshal.PtrToStringUni(value);
                    }
                    break;

                case "IFCQUANTITYCOUNT":
                    {
                        IntPtr value;
                        IfcEngine.x86_64.sdaiGetAttrBN(ifcItem.Instance, "CountValue", IfcEngine.x86_64.sdaiUNICODE, out value);

                        strValue = Marshal.PtrToStringUni(value);
                    }
                    break;

                case "IFCQUANTITYWEIGTH":
                    {
                        IntPtr value;
                        IfcEngine.x86_64.sdaiGetAttrBN(ifcItem.Instance, "WeigthValue", IfcEngine.x86_64.sdaiUNICODE, out value);

                        strValue = Marshal.PtrToStringUni(value);
                    }
                    break;

                case "IFCQUANTITYTIME":
                    {
                        IntPtr value;
                        IfcEngine.x86_64.sdaiGetAttrBN(ifcItem.Instance, "TimeValue", IfcEngine.x86_64.sdaiUNICODE, out value);

                        strValue = Marshal.PtrToStringUni(value);
                    }
                    break;

                case "IFCPROPERTYSINGLEVALUE":
                    {
                        IntPtr value;
                        IfcEngine.x86_64.sdaiGetAttrBN(ifcItem.Instance, "NominalValue", IfcEngine.x86_64.sdaiUNICODE, out value);

                        strValue = Marshal.PtrToStringUni(value);
                    }
                    break;

                default:
                    throw new Exception("Unknown property.");
            } // switch (strProperty)    

            string strItemText = "'" + (string.IsNullOrEmpty(strName) ? "<name>" : strName) +
                    "' = '" + (string.IsNullOrEmpty(strValue) ? "<value>" : strValue) +
                    "' (" + strIfcType + ")";

            if ((ifcParent != null) && (ifcParent.Node != null))
            {
                ifcItem.Node = ifcParent.Node.Nodes.Add(strItemText);
            }
            else
            {
                ifcItem.Node = _treeControl.Nodes.Add(strItemText);
            }

            if (ifcItem.Item == null)
            {
                // item without visual representation
                ifcItem.Node.ForeColor = Color.Gray;
            }

            ifcItem.Node.ImageIndex = ifcItem.Node.SelectedImageIndex = IMAGE_PROPERTY;
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="ifcParent"></param>
        /// <param name="iInstance"></param>
        /// <returns></returns>
        private IFCItem FindIFCItem(IFCItem ifcParent, int_t iInstance)
        {
            if (ifcParent == null)
            {
                return null;
            }

            IFCItem ifcIterator = ifcParent;
            while (ifcIterator != null)
            {
                if (ifcIterator.instance == iInstance)
                {
                    return ifcIterator;
                }

                IFCItem ifcItem = FindIFCItem(ifcIterator.child, iInstance);
                if (ifcItem != null)
                {
                    return ifcItem;
                }

                ifcIterator = ifcIterator.next;
            }

            return FindIFCItem(ifcParent.child, iInstance);
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="ifcParent"></param>
        /// <param name="tnNotReferenced"></param>
        private void FindNonReferencedIFCItems(IFCItem ifcParent, TreeNode tnNotReferenced)
        {
            if (ifcParent == null)
            {
                return;
            }

            IFCItem ifcIterator = ifcParent;
            while (ifcIterator != null)
            {
                if ((ifcIterator.ifcTreeView == null) && (ifcIterator.instance != 0))
                {
                    string strItemText = BuildItemText(ifcIterator.instance);

                    TreeIFCitemView ifcTreeItem = new TreeIFCitemView(ifcIterator.instance, FindIFCItem(_model.Root, ifcIterator.instance));
                    ifcTreeItem.Node = tnNotReferenced.Nodes.Add(strItemText);
                    ifcIterator.ifcTreeView = ifcTreeItem;
                    ifcTreeItem.Node.Tag = ifcTreeItem;

                    if (ifcTreeItem.Item != null)
                    {
                        ifcTreeItem.Item.ifcTreeView = ifcTreeItem;
                        ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_CHECKED;
                    }
                    else
                    {
                        ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_NOT_REFERENCED;
                    }
                }

                FindNonReferencedIFCItems(ifcIterator.child, tnNotReferenced);

                ifcIterator = ifcIterator.next;
            }

            FindNonReferencedIFCItems(ifcParent.child, tnNotReferenced);
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="iInstance"></param>
        /// <returns></returns>
        private string GetItemType(int_t iInstance)
        {
            int_t entity = IfcEngine.x86_64.sdaiGetInstanceType(iInstance);
            IntPtr entityNamePtr = IntPtr.Zero;
            IfcEngine.x86_64.engiGetEntityName(entity, IfcEngine.x86_64.sdaiUNICODE, out entityNamePtr);

            return Marshal.PtrToStringUni(entityNamePtr);
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="iInstance"></param>
        /// <param name="strType"></param>
        /// <returns></returns>
        private bool IsInstanceOf(int_t iInstance, string strType)
        {
            if (IfcEngine.x86_64.sdaiGetInstanceType(iInstance) == IfcEngine.x86_64.sdaiGetEntity(_model.Model, strType))
            {
                return true;
            }

            return false;
        }        
        
        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="tnParent"></param>
        private void UpdateChildrenTreeItems(TreeNode tnParent)
        {
            foreach (TreeNode tnChild in tnParent.Nodes)
            {
                if ((tnChild.ImageIndex != IMAGE_CHECKED) && (tnChild.ImageIndex != IMAGE_UNCHECKED) && (tnChild.ImageIndex != IMAGE_MIDDLE))
                {
                    // skip properties
                    continue;
                }

                switch (tnParent.ImageIndex)
                {
                    case IMAGE_CHECKED:
                    case IMAGE_MIDDLE:
                        {
                            tnChild.ImageIndex = tnChild.SelectedImageIndex = IMAGE_CHECKED;
                        }
                        break;

                    case IMAGE_UNCHECKED:
                        {
                            tnChild.ImageIndex = tnChild.SelectedImageIndex = IMAGE_UNCHECKED;
                        }
                        break;
                } // switch (tnParent.ImageIndex)

                UpdateChildrenTreeItems(tnChild);
            } // foreach (TreeNode tnChild in ...
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="tnItem"></param>
        private void UpdateParentTreeItems(TreeNode tnItem)
        {
            if (tnItem.Parent == null)
            {
                return;
            }

            int iCheckedChildrenCount = 0;
            bool bMiddleStateChild = false;
            foreach (TreeNode tnChild in tnItem.Parent.Nodes)
            {
                if (tnChild.ImageIndex == IMAGE_MIDDLE)
                {
                    bMiddleStateChild = true;
                }

                if (tnChild.ImageIndex == IMAGE_CHECKED)
                {
                    iCheckedChildrenCount++;
                }                
            }

            if (!bMiddleStateChild)
            {
                if (iCheckedChildrenCount > 0)
                {
                    tnItem.Parent.ImageIndex = tnItem.Parent.SelectedImageIndex =
                        iCheckedChildrenCount == tnItem.Parent.Nodes.Count ? IMAGE_CHECKED : IMAGE_MIDDLE;
                }
                else
                {
                    tnItem.Parent.ImageIndex = tnItem.Parent.SelectedImageIndex = IMAGE_UNCHECKED;
                }
            }
            else
            {
                tnItem.Parent.ImageIndex = tnItem.Parent.SelectedImageIndex = IMAGE_MIDDLE;
            }                                    

            UpdateParentTreeItems(tnItem.Parent);
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="tnParent"></param>
        /// <param name="strIfcType"></param>
        /// <param name="bCheck"></param>
        private void OnContextMenu_UpdateTreeElement(TreeNode tnParent, string strIfcType, bool bCheck)
        {
            if (tnParent.Tag != null)
            {
                OnContextMenu_UpdateTreeElement(tnParent.Tag as TreeIFCitemView, strIfcType, bCheck);
            }

            foreach (TreeNode tnChild in tnParent.Nodes)
            {
                OnContextMenu_UpdateTreeElement(tnChild, strIfcType, bCheck);
            } 
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="ifcTreeItem"></param>
        /// <param name="strIfcType"></param>
        /// <param name="bCheck"></param>
        private void OnContextMenu_UpdateTreeElement(TreeIFCitemView ifcTreeItem, string strIfcType, bool bCheck)
        {   
            if (ifcTreeItem.Item == null)
            {
                // skip not referenced items
                return;
            }

            if (string.IsNullOrEmpty(ifcTreeItem.Item.ifcType) || (ifcTreeItem.Item.ifcType != strIfcType))
            {
                // filter the items 
                return;
            }

            if (bCheck)
            {
                ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_CHECKED;
            }
            else
            {
                ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_UNCHECKED;
            }

            UpdateChildrenTreeItems(ifcTreeItem.Node);
            UpdateParentTreeItems(ifcTreeItem.Node);
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="iInstance"></param>
        /// <returns></returns>
        private string BuildItemText(int_t iInstance)
        {
            if (iInstance == 0)
            {
                System.Diagnostics.Debug.Assert(false);

                return string.Empty;
            }

            int_t iType = IfcEngine.x86_64.sdaiGetInstanceType(iInstance);

            IntPtr type = IntPtr.Zero;
            IfcEngine.x86_64.engiGetEntityName(iType, IfcEngine.x86_64.sdaiUNICODE, out type);

            string strIfcType = Marshal.PtrToStringUni(type);

            IntPtr name;
            IfcEngine.x86_64.sdaiGetAttrBN(iInstance, "Name", IfcEngine.x86_64.sdaiUNICODE, out name);

            string strName = Marshal.PtrToStringUni(name);

            IntPtr description;
            IfcEngine.x86_64.sdaiGetAttrBN(iInstance, "Description", IfcEngine.x86_64.sdaiUNICODE, out description);

            string strDescription = Marshal.PtrToStringUni(description);

            string strItemText = "'" + (string.IsNullOrEmpty(strName) ? "<name>" : strName) +
                    "', '" + (string.IsNullOrEmpty(strDescription) ? "<description>" : strDescription) +
                    "' (" + strIfcType + ")";

            return strItemText;
        }

        /// <summary>
        /// Accessor
        /// </summary>
        public IIFCRenderer Renderer
        {
            get;
            set;
        }

        /// <summary>
        /// IIFCViewer
        /// </summary>
        /// <param name="ifcItem"></param>
        public void OnSelect(IFCItem ifcItem)
        {
            System.Diagnostics.Debug.Assert(ifcItem != null, "Internal error.");

            TreeIFCitemView treeItem = ifcItem.ifcTreeView as TreeIFCitemView;
            System.Diagnostics.Debug.Assert(treeItem != null, "Internal error.");
            System.Diagnostics.Debug.Assert(treeItem.Node != null, "Internal error.");

            _treeControl.SelectedNode = treeItem.Node;
        }
    }
}
