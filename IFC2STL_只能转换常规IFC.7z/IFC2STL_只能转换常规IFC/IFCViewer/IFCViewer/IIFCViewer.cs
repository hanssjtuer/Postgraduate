﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#if _WIN64
using int_t = System.Int64;
#else
using int_t = System.Int32;
#endif

namespace IFCViewer
{
    /// <summary>
    /// Viewer.
    /// </summary>
    interface IIFCViewer
    {
        /// <summary>
        /// Accessor
        /// </summary>
        IIFCRenderer Renderer
        {
            get;
            set;
        }

        /// <summary>
        /// An IFC item has been selected
        /// </summary>
        /// <param name="ifcItem"></param>
        void OnSelect(IFCItem ifcItem);
    }
}
