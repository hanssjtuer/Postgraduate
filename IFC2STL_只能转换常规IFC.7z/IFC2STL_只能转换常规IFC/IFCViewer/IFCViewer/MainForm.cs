﻿using SharpDX.Direct3D9;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using System.Threading;


namespace IFCViewer
{
    /// <summary>
    /// Main form
    /// </summary>
    public partial class MainForm : Form
    {
        //[DllImport("kernel32.dll")]
        //public static extern Boolean AllocConsole();
        //[DllImport("kernel32.dll")]
        //public static extern Boolean FreeConsole();

        int data_index = 0;

        #region Members

        /// <summary>
        /// IFC Model
        /// </summary>
        IFCModel _model = null;

        /// <summary>
        /// IFC Renderer
        /// </summary>
        IIFCRenderer _renderer = null;

        /// <summary>
        /// IFC Viewer
        /// </summary>
        IIFCViewer _viewer = null;

        #endregion // Members

        /// <summary>
        /// ctor
        /// </summary>
        public MainForm()
        {
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            //this.Hide();
            InitializeComponent();
            //this.Hide();
            //AllocConsole();
            /*
             * Model
             */
            _model = new IFCModel();

            /*
             * Viewer
             */
            _viewer = new TreeIFCViewer(_model, _treeView);

            /*
             * Renderer
             */
            _renderer = new SharpDXRenderer(_model, this.splitContainer.Panel2);

            _viewer.Renderer = _renderer;
            _renderer.Viewer = _viewer;
            //_model.Load("exampleWall.ifc");
            //dataToolStripMenuItem_Click_copy();
            //readxml.do_stl();
        }
        private delegate void SetPos(int ipos, string vinfo);
        private void SetTextMesssage(int ipos, string vinfo)
        {
            if (this.InvokeRequired)
            {
                SetPos setpos = new SetPos(SetTextMesssage);
                this.Invoke(setpos, new object[] { ipos, vinfo });
            }
            else
            {
                //this.progressBar1.Value = Convert.ToInt32(ipos);
            }
        }
        private void dataToolStripMenuItem_Click_copy()
        {
            StringBuilder sb = new StringBuilder();
            StringBuilder sb1 = new StringBuilder();
            string xmlLine = "";
            sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
            sb.Append("<Tree>\n");
            foreach (TreeNode node in TreeIFCViewer._treeControl.Nodes)
            {
                xmlLine = GetRSSText(node);
                sb.Append(xmlLine);
                parseNode(node, sb);
                sb.Append("</Node>\n");
            }
            sb.Append("</Tree>\n");
            StreamWriter sr = new StreamWriter("TreeXml.xml", false, System.Text.Encoding.UTF8);
            sr.Write(sb.ToString());
            sr.Close();
            foreach (string sub_vertexes in IFCModel.data)
            {
                sb1.Append(sub_vertexes + "\n");
            }
            StreamWriter sr1 = new StreamWriter("VertexXml.xml", false, System.Text.Encoding.UTF8);
            sr1.Write(sb1.ToString());
            sr1.Close();
        }
        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "IFC files (*.ifc)|*.ifc";
            dialog.Title = "Open";

            if (dialog.ShowDialog() != DialogResult.OK)
            {
                return;
            }

            if (_model.Load(dialog.FileName))
            {
                this.Text = string.Format("{0} - IFCViewer", System.IO.Path.GetFileNameWithoutExtension(dialog.FileName));
                //dataToolStripMenuItem_Click_copy();
                dataToolStripMenuItem_Click_copy();
                //readxml.do_stl();
            }
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolStripMenuSaveAs_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "JPG files (*.jpg)|*.jpg|PNG files (*.png)|*.png|BMP files (*.bmp)|*.bmp";
            dialog.Title = "Save as...";

            if (dialog.ShowDialog() != DialogResult.OK)
            {
                return;
            }

            _renderer.SaveToFile(dialog.FileName, dialog.FilterIndex == 1 ? ImageFileFormat.Jpg : dialog.FilterIndex == 2 ? ImageFileFormat.Png : ImageFileFormat.Bmp);
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_Load(object sender, EventArgs e)
        {
            this.splitContainer.Panel2.BackColor = Color.Transparent;
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {            
            _renderer.Reset();
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void viewFacesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (viewFacesToolStripMenuItem == sender)
            {
                _renderer.ShowFaces = viewFacesToolStripMenuItem.Checked;
            }
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void viewWireFrameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (viewWireFrameToolStripMenuItem == sender)
            {
                _renderer.ShowWireframes = viewWireFrameToolStripMenuItem.Checked;
            }           
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void selectOnOverIn3DToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (selectOnOverIn3DToolStripMenuItem == sender)
            {
                _renderer.SelectOnMouseHover = selectOnOverIn3DToolStripMenuItem.Checked;
            }
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void aboutIfcviewerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox aboutBox = new AboutBox();
            aboutBox.ShowDialog();            
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            if (_renderer != null)
            {
                _renderer.Dispose();
            }

            base.Dispose(disposing);
        }

        private void dataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            StringBuilder sb1 = new StringBuilder();
            string xmlLine = "";
            sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
            sb.Append("<Tree>\n");
            foreach (TreeNode node in TreeIFCViewer._treeControl.Nodes)
            {
                 xmlLine = GetRSSText(node);
                 sb.Append(xmlLine);
                 parseNode(node, sb);
                 sb.Append("</Node>\n");
            }
            sb.Append("</Tree>\n");
            StreamWriter sr = new StreamWriter("TreeXml.xml", false, System.Text.Encoding.UTF8);
            sr.Write(sb.ToString());
            sr.Close();
            foreach(string sub_vertexes in IFCModel.data)
            {
                sb1.Append(sub_vertexes+"\n");
            }
            StreamWriter sr1 = new StreamWriter("VertexXml.xml", false, System.Text.Encoding.UTF8);
            sr1.Write(sb1.ToString());
            sr1.Close();
        }

        private void parseNode(TreeNode tn, StringBuilder sb)
        {
            IEnumerator ie = tn.Nodes.GetEnumerator();

            while (ie.MoveNext())
            {
                TreeNode ctn = (TreeNode)ie.Current;
                sb.Append(GetRSSText(ctn));
                if (ctn.Nodes.Count > 0)
                {
                    parseNode(ctn, sb);
                }
                sb.Append("</Node>\n");
            }
        }

        private string GetRSSText(TreeNode node)
        {
            string rssText = "";
            if (node.Text.Contains("IfcWall") || node.Text.Contains("IfcWindow") || node.Text.Contains("IfcBeam") || node.Text.Contains("IfcBuildingElementProxy") || 
                node.Text.Contains("IfcDoor") || node.Text.Contains("IfcColumn") || node.Text.Contains("IfcSlab"))
            {
                rssText = "<Node Name=\"" + node.Name + "\" Text=\"" + node.Text.Replace("<", "").Replace(">", "") + IFCModel.data[data_index] + "\" >\n";
                data_index++;
            }
            else
            {
                rssText = "<Node Name=\"" + node.Name + "\" Text=\"" + node.Text.Replace("<", "").Replace(">", "") + "\" >\n";
            }
            return rssText;
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void _treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {
            //readxml.do_stl();
        }

        private void exportSTLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Thread fThread = new Thread(new ThreadStart(SleepT));
            //fThread.Start();
            readxml.do_stl();
        }
        private void SleepT()
        {
            for (int i = 0; i < 500; i++)
            {
                System.Threading.Thread.Sleep(10);
                SetTextMesssage(100 * i / 500, i.ToString() + "\r\n");
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
