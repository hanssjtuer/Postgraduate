import re

class isoinfo(object):
	def __init__(self):
		super(isoinfo, self).__init__()
		self.isoinfo = {}
		self.prepare = ['iso'.upper()]

	def fillisoinfo(self, filepath):
		ifcstr = open(filepath).read()
		iso = re.search(self.prepare[0] + '(.*?);', ifcstr).group(0).strip(';')
		self.isoinfo["iso ''('').standard"] = iso
		return self.isoinfo
