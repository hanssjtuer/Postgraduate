import re
from isoinfo import isoinfo
from headerinfo import headerinfo
from projectinfo import projectinfo
from nestdict import deflat
from nestdict import merge
from nestdict import unpack

filepath = 'exampleWall.ifc'
commondict = {}
nestdict = {}

isodict = isoinfo().fillisoinfo(filepath)
commondict.update(isodict)

headerdict = headerinfo().fillheaderinfo(filepath)
commondict.update(headerdict)

projectdict = projectinfo().fillprojectinfo(filepath)
commondict.update(projectdict)

for d in deflat(commondict):
	merge(nestdict, d)

print(nestdict)