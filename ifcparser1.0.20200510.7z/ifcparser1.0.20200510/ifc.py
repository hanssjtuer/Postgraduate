import re
import codecs
import sys
from PyQt5.QtWidgets import *


class IsoInfo(object):
	def __init__(self):
		super(IsoInfo, self).__init__()

	def get_iso(self, ifc_str):
		iso = re.search('%s(.*?);'%('ISO'), ifc_str)
		if iso:
			iso = iso.group(0).strip(';')
		else:
			iso = None
		return {'Ifciso': iso}


class HeaderInfo(object):
	def __init__(self):
		super(HeaderInfo, self).__init__()

	def get_header(self, ifc_str):
		header_info = {}
		ifc_str = ifc_str.replace('(', '[').replace(')', ']')
		description = re.search('%s(.*?);\s*\n'%('FILE_DESCRIPTION'), ifc_str)
		if description:
			description = eval(description.group(1))
			for index, item in enumerate(description[0]):
				header_info['Setofdescriptions.Descriptions.Description%s'%(index+1)] = item
			header_info['Implementationlevel'] = description[1]
		else:
			print('No file description')
		name = re.search('%s(.*?);\s*\n'%('FILE_NAME'), ifc_str)
		if name:
			name = eval(name.group(1))
			header_info['Timestamp'] = name[1]
			for index, item in enumerate(name[2]):
				header_info['Setofauthors.Authors.Author%s'%(index+1)] = item
			for index, item in enumerate(name[3]):
				header_info['Setoforganizations.Organizations.Organization%s'%(index+1)] = item
			header_info['Preprocessorversion'] = name[4]
			header_info['Originatingsystem'] = name[5]
			header_info['Authorization'] = name[6]
		else:
			print('No file name')
		schema = re.search('%s(.*?);\s*\n'%('FILE_SCHEMA'), ifc_str)
		if schema:
			schema = eval(schema.group(1))
			for index, item in enumerate(schema[0]):
				header_info['SetOffileschemas.Fileschemas.Fileschema%s'%(index+1)] = item
		else:
			print('No file schema')
		buff = {}
		for key, value in header_info.items():
			buff['Header.%s'%key] = value
		nest_dict = {}
		for d in self.deflat(buff):
			self.merge(nest_dict, d)
		return nest_dict

	def unpack(self, key, value):
		return {key[0]: value} if len(key) == 1 else {key.pop(0): self.unpack(key, value)}

	def deflat(self, x):
		for key, value in x.items():
			yield self.unpack(key.split('.'), value)

	def merge(self, dst, src):
		for key, value in src.items():
			if key not in dst:
				dst[key] = value
			elif isinstance(dst[key], dict) and isinstance(value, dict):
				self.merge(dst[key], value)


class Ergodic(object):
	def __init__(self):
		super(Ergodic, self).__init__()

	def get_ergodic_element(self, ifc_str):
		ergodic_element = {}
		result = re.compile('IFCRELAGGREGATES.*;').findall(ifc_str)
		if result:
			for i in result:
				middle = re.search('IFCRELAGGREGATES(.*?);', i).group(1).replace('(', '[').replace(')', ']')
				for j in re.findall('#\s*\d*', middle):
					middle = middle.replace(j, "'%s'"%j, 1)
				middle = eval(middle)
				second = re.search('%s\s*=\s*(.*?);'%middle[-2].strip(), ifc_str)
				if second:
					values = {}
					keys = '%s(%s)'%(re.search('\w*', second.group(1)).group().title(), middle[-2])
					for index, item in enumerate(middle[-1]):
						last = re.search('%s\s*=\s*(.*?);'%item.strip(), ifc_str)
						if last:
							values.update({'Decomposition%s'%(index+1): '%s(%s)'%(re.search('\w*', last.group(1)).group().title(), item)})
						else:
							print('No line number as %s'%item)
					ergodic_element.update({keys: values})
				else:
					print('No line number as %s'%middle[-2])
		else:
			print('No IFCRELAGGREGATES')
		result = re.compile('IFCRELCONTAINEDINSPATIALSTRUCTURE.*;').findall(ifc_str)
		if result:
			for i in result:
				middle = re.search('IFCRELCONTAINEDINSPATIALSTRUCTURE(.*?);', i).group(1).replace('(', '[').replace(')', ']')
				for j in re.findall('#\s*\d*', middle):
					middle = middle.replace(j, "'%s'"%j, 1)
				middle = eval(middle)
				second = re.search('%s\s*=\s*(.*?);'%middle[-1].strip(), ifc_str)
				if second:
					values = {}
					keys = '%s(%s)'%(re.search('\w*', second.group(1)).group().title(), middle[-1])
					for index, item in enumerate(middle[-2]):
						last = re.search('%s\s*=\s*(.*?);'%item.strip(), ifc_str)
						if last:
							values.update({'Decomposition%s'%(index+1): '%s(%s)'%(re.search('\w*', last.group(1)).group().title(), item)})
						else:
							print('No line number as %s'%item)
					ergodic_element.update({keys: values})  #TODO: Group as different types <door window roof space and so on> 2020/5/9 18:44
				else:
					print('No line number as %s'%middle[-1])			
		else:
			print('No IFCRELAGGREGATES')
		for key, value in ergodic_element.items():
			for m in range(0, len(value), 1):
				m = m + 1
				if value['Decomposition%s'%m] in ergodic_element:
					value['Decomposition%s'%m] = {value['Decomposition%s'%m]: ergodic_element[value['Decomposition%s'%m]]}
		return self.get_longest_value(ergodic_element)

	def get_longest_value(self, common_dict):
		lens = []
		k = -1
		for key, value in common_dict.items():
			lens.append(len(str(value)))
		for index, item in enumerate(lens):
			if item == max(lens):
				for key, value in common_dict.items():
					k = k + 1
					if k == index:
						return {key: common_dict[key]}


class NestDict(object):
	def __init__(self):
		super(NestDict, self).__init__()
		self.ifc_set = []

	def parser_nest_dict(self, nest_dict):
		if type(nest_dict) != dict:
			print('Dict supported')
			return
		else:
			for key, value in nest_dict.items():
				if 'Ifc' in key:
					self.ifc_set.append(key)
				if type(value) == str:
					if 'Ifc' in value:
						self.ifc_set.append(value)
				else:
					if type(value) == dict:
						self.parser_nest_dict(value)
		return self.ifc_set

	def parser_string(self, string):
		"""
		Parameter: 'Ifcproject(#1)' 'Ifcsite(#2)'
		Return: ['#1', 'IFCPROJECT'] ['#2', 'IFCSITE']
		"""
		double = []
		if type(string) != str:
			print('Str supported')
		else:
			num = re.search('#\d*', string)
			if num:
				double.append(num.group())
			else:
				print('No line number in string')
			ifc = re.search('\w*', string)
			if ifc:
				double.append(ifc.group().upper())
			else:
				print('No ifc element in string')
				return
		return double

	def call(self, array, ifc_str):
		if type(array) != list:
			print('List supported')
			return
		else:
			if array[1] == 'IFCPROJECT':
				return ProjectInfo().get_project(ifc_str, array[0])
			elif array[1] == 'IFCSITE':
				pass
			elif array[1] == 'IFCBUILDING':
				pass
			elif array[1] == 'IFCBUILDINGSTOREY':
				pass
			elif array[1] == 'IFCWALL':
				pass
			elif array[1] == 'IFCDOOR':
				pass
			elif array[1] == 'IFCWINDOW':
				pass
			elif array[1] == 'IFCSPACE':
				pass
			elif array[1] == 'IFCSLAB':
				pass
			else:
				pass


class OwnerHistoryInfo(object):
	"""
	Doc: get the information of an owner history
	"""
	def __init__(self):
		"""
		Doc: none
		Param: none
		Return: none
		"""
		super(OwnerHistoryInfo, self).__init__()
		self.owner_history_key = ['OwningUser', 'OwningApplication', 'State', 'ChangeAction', 'LastModifiedDate', 
		'LastModifyingUser', 'LastModifyingApplication', 'CreationDate']
		self.person_organization_attribute = ['ThePerson', 'TheOrganization', 'Roles']
		self.person_attribute = ['Id', 'FamilyName', 'GivenName', 'MiddleNames', 'PrefixTitles', 'SuffixTitles', 
		'Roles', 'Addresses', 'EngagedIn']
		self.organization_attribute = ['Id', 'Name', 'Description', 'Roles', 'Addresses', 'IsRelatedBy', 'Relates', 'Engages']
		self.application_attribute = ['ApplicationDeveloper', 'Version', 'ApplicationFullName', 'ApplicationIdentifier']
	
	def get_owner_history(self, ifc_str, line_number):
		"""
		Doc: none
		Param: none
		Return: none
		"""
		owner_history_data = {}
		result = re.search('%s\s*=\s*IFCOWNERHISTORY\s*[\[|\()](.*?)[\]|\)]\s*;'%line_number, ifc_str)
		if result:
			owner_history_value = result.group(1).split(',')
			for index, item in enumerate(owner_history_value):
				owner_history_value[index] = item.lstrip().rstrip()
			owner_history_value[0] = self.get_person_organization(ifc_str, owner_history_value[0])
			owner_history_value[1] = self.get_application(ifc_str, owner_history_value[1])
			owner_history_data = dict(zip(self.owner_history_key, owner_history_value))
			print('Owner history beginning with %s is %s'%(line_number, owner_history_data))
		else:
			print('No owner history beginning with %s'%line_number)
		return owner_history_data

	def get_person_organization(self, ifc_str, line_number):
		result = re.search('%s\s*=\s*IFCPERSONANDORGANIZATION\s*\[(.*?)\]\s*;'%line_number, ifc_str)
		if result:
			person_organization_value = result.group(1).split(',')
			for index, item in enumerate(person_organization_value):
				person_organization_value[index] = item.lstrip().rstrip()
			person_organization_value[0] = self.get_person(ifc_str, person_organization_value[0])
			person_organization_value[1] = self.get_organization(ifc_str, person_organization_value[1])
			return person_organization_value
		else:
			print('No person and organization beginning with %s.'%line_number)
			return line_number

	def get_person(self, ifc_str, line_number):
		result = re.search('%s\s*=\s*IFCPERSON\s*\[(.*?)\]\s*;'%line_number, ifc_str)
		if result:
			person_value = result.group(1).split(',')
			for index, item in enumerate(person_value):
				person_value[index] = item.lstrip().rstrip()
			return person_value
		else:
			print('No person beginning with %s'%line_number)
			return line_number

	def get_organization(self, ifc_str, line_number):
		result = re.search('%s\s*=\s*IFCORGANIZATION\s*\[(.*?)\]\s*;'%line_number, ifc_str)
		if result:
			organization_value = result.group(1).split(',')
			for index, item in enumerate(organization_value):
				organization_value[index] = item.lstrip().rstrip()
			return organization_value
		else:
			print('No organization beginning with %s'%line_number)
			return line_number

	def get_application(self, ifc_str, line_number):
		result = re.search('%s\s*=\s*IFCAPPLICATION\s*\[(.*?)\]\s*;'%line_number, ifc_str)
		if result:
			application_value = result.group(1).split(',')
			for index, item in enumerate(application_value):
				application_value[index] = item.lstrip().rstrip()
			application_value[0] = self.get_organization(ifc_str, application_value[0])
			return application_value
		else:
			print('No application beginning with %s'%line_number)
			return line_number


class UnitAssignmentInfo(object):
	"""
	Doc: get the information of an unit assignment
	"""
	def __init__(self):
		super(UnitAssignmentInfo, self).__init__()
		"""
		TODO: add decsription here
		"""
		#self.unit_assignment_attribute = ['Units']  #TODO
		self.measure_unit_attribute = ['ValueComponent', 'UnitComponent']
		self.dimensional_exponents_attribute = ['LengthExponent', 'MassExponent', 'TimeExponent', 'ElectricCurrentExponent', 'ThermondynamicTemperatureExponent', 'AmountOfSubstanceExponent', 'LuminousIntensityExponent']
		self.si_unit_key = ['Dimensions', 'UnitType', 'Prefix', 'Name']
		self.conversion_based_uint_key = ['Dimensions', 'UnitType', 'Name', 'ConversionFactor']
		self.context_dependent_unit = ['Dimensions', 'UnitType', 'Name']  #TODO

	def get_unit_assignment(self, file_path, line_number):
		"""
		TODO: add decsription here
		"""
		unit_data = {}
		result = re.search('%s\s*=\s*IFCUNITASSIGNMENT\s*\(\s*[\(|\[](.*?)[\)|\]]\s*\)\s*;'%line_number, ifc_str)
		if result:
			unit_assignemnet_value = result.group(1).split(',')
			for index, item in enumerate(unit_assignemnet_value):
				unit_assignemnet_value[index] = item.lstrip().rstrip()
			for index, item in enumerate(unit_assignemnet_value):
				unit_data.update(self.get_unit(ifc_str, item))
			print('Unit assignment beginning with %s is %s'%(line_number, unit_data))
		else:
			print('No unit assignment beginning with %s. So get an empty %s'%(line_number, unit_data))
		return unit_data

	def get_unit(self, ifc_str, line_number):
		"""
		TODO: add decsription here
		"""
		result = re.search('%s\s*=(.*?);'%line_number, ifc_str)
		if result:
			unit_value = result.group(1)
			if 'IFCSIUNIT' in unit_value:
				si_unit = re.search('IFCSIUNIT\s*[\(|\[](.*?)[\)|\]]\s*', unit_value).group(1).split(',')
				for index, item in enumerate(si_unit):
					si_unit[index] = item.lstrip().rstrip()
				return {si_unit[1].lower().replace('.', ''): dict(zip(self.si_unit_key, si_unit))}

			elif 'IFCCONVERSIONBASEDUNIT' in unit_value:
				conversion_based_uint = re.search('IFCCONVERSIONBASEDUNIT\s*[\(|\[](.*?)[\)|\]]\s*', unit_value).group(1).split(',')
				for index, item in enumerate(conversion_based_uint):
					conversion_based_uint[index] = item.lstrip().rstrip()
				conversion_based_uint[0] = self.get_demensional_exponent(ifc_str, conversion_based_uint[0])
				conversion_based_uint[-1] = self.get_measure_unit(ifc_str, conversion_based_uint[-1])
				return {conversion_based_uint[1].lower().replace('.', ''): dict(zip(self.conversion_based_uint_key, conversion_based_uint))}

			elif 'IFCCONTEXTDEPENDENTUNIT' in unit_value:
				pass  #TODO
		else:
			print('No unit beginning with %s.'%line_number)
			return {line_number: None}

	def get_demensional_exponent(self, ifc_str, line_number):
		"""
		TODO: add decsription here
		"""
		result = re.search('%s\s*=\s*IFCDIMENSIONALEXPONENTS\s*[\(|\[](.*?)[\)|\]]\s*;'%line_number, ifc_str)
		if result:
			dimensional_exponent_value = result.group(1).split(',')
			return dict(zip(self.dimensional_exponents_attribute, dimensional_exponent_value))
		else:
			print('No dimensional exponent beginning with %s.'%line_number)
			return {line_number: None}

	def get_measure_unit(self, ifc_str, line_number):
		"""
		TODO: add decsription here
		"""	
		result = re.search('%s\s*=\s*IFCMEASUREWITHUNIT\s*[\(|\[](.*?)[\)|\]]\s*;'%line_number, ifc_str)
		if result:
			measure_unit_value = result.group(1).split(',')
			measure_unit_value[-1] = self.get_unit(ifc_str, measure_unit_value[-1])
			return dict(zip(self.measure_unit_attribute, measure_unit_value))
		else:
			print('No measure unit beginning with %s.'%line_number)
			return {line_number: None}


# 2020/05/11 16:38 GOOD
class ProjectInfo(object):
	"""
	Doc: get the information of a project
	"""
	def __init__(self):
		"""
		Doc: none
		Param: none
		Return: none
		"""
		super(ProjectInfo, self).__init__()

	def get_project(self, ifc_str, line_number):
		"""
		Doc: get the information of a project beginning with a line number
		Params: 
			ifc_str = read .ifc
			line_number = '#\d*'
				for example, '#1' '#2', '#12', '#121', '#1212'
		Return: a nested dictionary
		"""


		ifc_str = ifc_str.replace('(', '[').replace(')', ']').replace('$', 'None')  #TODO: replace '$' with "'$'" but not in id

		
		project = re.search('%s\s*=\s*IFCPROJECT(.*?);\s*\n'%line_number, ifc_str)
		if project:
			project = project.group(1)
			for i in re.findall('#\s*\d*', project):
				project = project.replace(i, "'%s'"%i, 1)
			project = eval(project)  #TODO: eval() or string.split(',')
			project[1] = OwnerHistoryInfo().get_owner_history(ifc_str, project[1].strip())
			project[-1] = UnitAssignmentInfo().get_unit_assignment(ifc_str, project[-1].strip())


			#TODO: project[-2]


			project_info =  {'Private': dict(zip(['GlobalId', 'OwnerHistory', 'Name', 'Description', 'ObjectType', 
				'LongName', 'Phase', 'RepresentationContexts', 'UnitsInContext'], project))}
		else:
			print('No project beginning with %s'%line_number)
			project_info = {'Private': None}
		return project_info
# 2020/05/11 16:38 GOOD


# 2020/05/11 19:30 GOOD
class SiteInfo(object):
	"""
	Doc: get the information of a site
	"""
	def __init__(self):
		"""
		Doc: none
		Param: none
		Return: none
		"""
		super(SiteInfo, self).__init__()

	def get_site(self, ifc_str, line_number):
		"""
		Doc: get the information of a site beginning with a line number
		Params: 
			ifc_str = read .ifc
			line_number = '#\d*'
				for example, '#1' '#2', '#12', '#121', '#1212'
		Return: a nested dictionary
		"""


		ifc_str = ifc_str.replace('(', '[').replace(')', ']').replace('$', 'None')  #TODO: replace '$' with "'$'" but not in id

		
		site = re.search('%s\s*=\s*IFCSITE(.*?);\s*\n'%line_number, ifc_str)
		if site:
			site = site.group(1)
			for i in re.findall('#\s*\d*', site):
				site = site.replace(i, "'%s'"%i, 1)
			for i in re.findall('\.\w*\.', site):
				site = site.replace(i, "'%s'"%i, 1)
			site = eval(site)  #TODO: eval() or string.split(',')
			site[1] = OwnerHistoryInfo().get_owner_history(ifc_str, site[1].strip())

			#TODO: site[5]


			site_info =  {'Private': dict(zip(['GlobalId', 'OwnerHistory', 'Name', 'Description', 'ObjectType', 
				'ObjectPlacement', 'Representation', 'LongName', 'CompositionType', 'RefLatitude', 'RefLongitude', 
				'RefElevation', 'LandTitleNumber', 'SiteAddress'], site))}
		else:
			print('No site beginning with %s'%line_number)
			site_info = {'Private': None}
		return site_info
# 2020/05/11 19:30 GOOD


# 2020/05/11 19:54 GOOD
class BuildingInfo(object):
	"""
	Doc: get the information of a building
	"""
	def __init__(self):
		"""
		Doc: none
		Param: none
		Return: none
		"""
		super(BuildingInfo, self).__init__()

	def get_building(self, ifc_str, line_number):
		"""
		Doc: get the information of a building beginning with a line number
		Params: 
			ifc_str = read .ifc
			line_number = '#\d*'
				for example, '#1' '#2', '#12', '#121', '#1212'
		Return: a nested dictionary
		"""


		ifc_str = ifc_str.replace('(', '[').replace(')', ']').replace('$', 'None')  #TODO: replace '$' with "'$'" but not in id

		
		building = re.search('%s\s*=\s*IFCBUILDING(.*?);\s*\n'%line_number, ifc_str)
		if building:
			building = building.group(1)
			for i in re.findall('#\s*\d*', building):
				building = building.replace(i, "'%s'"%i, 1)
			for i in re.findall('\.\w*\.', building):
				building = building.replace(i, "'%s'"%i, 1)
			building = eval(building)  #TODO: eval() or string.split(',')
			building[1] = OwnerHistoryInfo().get_owner_history(ifc_str, building[1].strip())

			#TODO: building[5]


			building_info =  {'Private': dict(zip(['GlobalId', 'OwnerHistory', 'Name', 'Description', 'ObjectType', 
				'ObjectPlacement', 'Representation', 'LongName', 'CompositionType', 'ElevationOfRefHeight', 'ElevationOfTerrain', 
				'BuildingAddress'], building))}
		else:
			print('No building beginning with %s'%line_number)
			building_info = {'Private': None}
		return building_info
# 2020/05/11 19:54 GOOD


# 2020/05/11 20:02 GOOD
class BuildingStoreyInfo(object):
	"""
	Doc: get the information of a building storey
	"""
	def __init__(self):
		"""
		Doc: none
		Param: none
		Return: none
		"""
		super(BuildingStoreyInfo, self).__init__()

	def get_building_storey(self, ifc_str, line_number):
		"""
		Doc: get the information of a building storey beginning with a line number
		Params: 
			ifc_str = read .ifc
			line_number = '#\d*'
				for example, '#1' '#2', '#12', '#121', '#1212'
		Return: a nested dictionary
		"""


		ifc_str = ifc_str.replace('(', '[').replace(')', ']').replace('$', 'None')  #TODO: replace '$' with "'$'" but not in id

		
		building_storey = re.search('%s\s*=\s*IFCBUILDINGSTOREY(.*?);\s*\n'%line_number, ifc_str)
		if building_storey:
			building_storey = building_storey.group(1)
			for i in re.findall('#\s*\d*', building_storey):
				building_storey = building_storey.replace(i, "'%s'"%i, 1)
			for i in re.findall('\.\w*\.', building_storey):
				building_storey = building_storey.replace(i, "'%s'"%i, 1)
			building_storey = eval(building_storey)  #TODO: eval() or string.split(',')
			building_storey[1] = OwnerHistoryInfo().get_owner_history(ifc_str, building_storey[1].strip())

			#TODO: building_storey[5]


			building_storey_info =  {'Private': dict(zip(['GlobalId', 'OwnerHistory', 'Name', 'Description', 'ObjectType', 
				'ObjectPlacement', 'Representation', 'LongName', 'CompositionType', 'Elevation'], building_storey))}
		else:
			print('No building storey beginning with %s'%line_number)
			building_storey_info = {'Private': None}
		return building_storey_info
# 2020/05/11 20:02 GOOD


# 2020/05/11 20:09 GOOD
class DoorInfo(object):
	"""
	Doc: get the information of a door
	"""
	def __init__(self):
		"""
		Doc: none
		Param: none
		Return: none
		"""
		super(DoorInfo, self).__init__()

	def get_door(self, ifc_str, line_number):
		"""
		Doc: get the information of a door beginning with a line number
		Params: 
			ifc_str = read .ifc
			line_number = '#\d*'
				for example, '#1' '#2', '#12', '#121', '#1212'
		Return: a nested dictionary
		"""


		ifc_str = ifc_str.replace('(', '[').replace(')', ']').replace('$', 'None')  #TODO: replace '$' with "'$'" but not in id

		
		door = re.search('%s\s*=\s*IFCDOOR(.*?);\s*\n'%line_number, ifc_str)
		if door:
			door = door.group(1)
			for i in re.findall('#\s*\d*', door):
				door = door.replace(i, "'%s'"%i, 1)
			for i in re.findall('\.\w*\.', door):
				door = door.replace(i, "'%s'"%i, 1)
			door = eval(door)  #TODO: eval() or string.split(',')
			door[1] = OwnerHistoryInfo().get_owner_history(ifc_str, door[1].strip())

			#TODO: door[5]


			door_info =  {'Private': dict(zip(['GlobalId', 'OwnerHistory', 'Name', 'Description', 'ObjectType', 
				'ObjectPlacement', 'Representation', 'Tag', 'OverallHeight', 'OverallWidth', 
				'PredefinedType', 'OperationType', 'UserDefinedOperationType'], door))}
		else:
			print('No door beginning with %s'%line_number)
			door_info = {'Private': None}
		return door_info
# 2020/05/11 20:09 GOOD


class ObjectPlacementInfo(object):
	def __init__(self):
		super(ObjectPlacementInfo, self).__init__()
		self.relative = []

	def get_final_placement(self, ifc_str, line_number):
		return self.hash(self.get_object_placement(ifc_str, line_number))

	def get_object_placement(self, ifc_str, line_number):
		result = re.search('%s\s*=\s*IFCLOCALPLACEMENT\s*[\(|\[](.*?)[\)|\]]\s*;'%line_number, ifc_str)
		if result:
			object_placement_value = result.group(1).split(',')
			for index, item in enumerate(object_placement_value):
				object_placement_value[index] = item.strip()
			if '#' in object_placement_value[1]:
				result1 = re.search('%s\s*=\s*(.*?)\s*;'%object_placement_value[1], ifc_str)
				if result1:
					result1 = result1.group(1)
					if 'IFCAXIS2PLACEMENT3D' in result1:
						object_placement_value[1] = self.get_axis2_placement3d(ifc_str, object_placement_value[1])
						self.relative.append(object_placement_value[1])
					else:
						pass
			if '#' in object_placement_value[0]:
				result2 = re.search('%s\s*=\s*(.*?)\s*;'%object_placement_value[0], ifc_str)
				if result2:
					result2 = result2.group(1)
					if 'IFCLOCALPLACEMENT' in result2:
						self.get_object_placement(ifc_str, object_placement_value[0])
					else:
						pass
			return self.relative
		else:
			print('No object placement beginning with %s'%line_number)

	def get_axis2_placement3d(self, ifc_str, line_number):
		result = re.search('%s\s*=\s*IFCAXIS2PLACEMENT3D\s*[\(|\[](.*?)[\)|\]]\s*;'%line_number, ifc_str)
		if result:
			axis2_placement3d_value = result.group(1).split(',')
			axis2_placement3d_value[0] = self.get_cartesian_point(ifc_str, axis2_placement3d_value[0].strip())
			axis2_placement3d_value[1] = self.get_direction(ifc_str, axis2_placement3d_value[1].strip())
			axis2_placement3d_value[2] = self.get_direction(ifc_str, axis2_placement3d_value[2].strip())			
			return axis2_placement3d_value
		else:
			print('No axis2 placement3d beginning with %s'%line_number)
			return line_number
	
	def get_cartesian_point(self, ifc_str, line_number):
		result = re.search('%s\s*=\s*IFCCARTESIANPOINT\s*[\(|\[](.*?)[\)|\]]\s*;'%line_number, ifc_str)
		if result:
			return eval(result.group(1))
		else:
			print('No cartesian point beginning with %s'%line_number)
			return line_number

	def get_direction(self, ifc_str, line_number):
		result = re.search('%s\s*=\s*IFCDIRECTION\s*[\(|\[](.*?)[\)|\]]\s*;'%line_number, ifc_str)
		if result:
			return eval(result.group(1))
		else:
			print('No direction beginning with %s'%line_number)
			return line_number

	def hash(self, ndim_list):
		if type(ndim_list) != list:
			print('List supported')
		else:
			for i in range(0, len(ndim_list), 1):
				if i <len(ndim_list)-1:
					ndim_list[i+1][0] = self.list_substract(ndim_list[i][0], ndim_list[i+1][0])
			return ndim_list[-1]

	def list_substract(self, list1, list2):
		if type(list1) in [list, tuple] or type(list2) in [list, tuple]:
			result = []
			if len(list1) == len(list2):
				for i in range(0, len(list1), 1):
					result.append(list1[i]-list2[i])
			else:
				print('Unequal length')
			return result

	def list_map(self, list1, list2):
		return list(map(lambda x,y:x-y, list1, list2))


class PropertySetInfo(object):
	def __init__(self):
		super(PropertySetInfo, self).__init__()

	def get_property_set(self, ifc_str, line_number):
		property_set_info = {}
		result = re.search('%s\s*=\s*IFCPROPERTYSET\s*[\(|\[](.*?)[\)|\]]\s*;'%line_number, ifc_str)
		if result:
			property_set_value = result.group(1).replace('$', "'$'")
			for i in re.findall('#\s*\d*', property_set_value):
				property_set_value = property_set_value.replace(i, "'%s'"%i, 1)
			property_set_value = eval(property_set_value)
			for i in property_set_value[-1]:
				single_value = re.search('%s\s*=\s*IFCPROPERTYSINGLEVALUE\s*[\(|\[](.*?)[\)|\]]\s*;'%i.strip(), ifc_str)
				if single_value:
					property_set_info.update(self.get_single_value(single_value.group(1)))
				else:
					print('No property single value beginning with %s'%i)
			print(property_set_info)
		else:
			print('No property set beginning with %s'%line_number)

	def get_single_value(self, string):
		single_value = string.split(',')
		single_value[2] = re.search('\w*[\(|\[](.*?)[\)|\]]', single_value[2]).group(1)
		return {single_value[0]: '%s(%s)'%(single_value[2], single_value[1])}


class ReldefinesByProperties(object):
	def __init__(self):
		super(ReldefinesByProperties, self).__init__()
		
ifc_str = codecs.open('example.ifc').read()
ifc_iso = IsoInfo().get_iso(ifc_str)
ifc_ergodic = Ergodic().get_ergodic_element(ifc_str)
ifc_header = HeaderInfo().get_header(ifc_str)
ifc_ergodic.update(ifc_iso)
ifc_ergodic.update(ifc_header)
print(PropertySetInfo().get_property_set(ifc_str, '#45'))

class TreeWidget(QTreeWidget):
	"""
	Doc: show a nested dictionary in a tree widget
	"""
	def __init__(self, nest_dict):
		"""
		Doc: none
		Param: a nested dictionary
		Return: none
		"""
		super(TreeWidget, self).__init__()
		self.update(nest_dict)
	def update(self, data):
		"""
		Doc: update the tree widget
		Param: a nested dictionary
		Return: none
		"""
		self.clear()
		self.setColumnCount(2)
		self.setHeaderLabels(['Property', 'Value'])
		self.root_list = []
		root = self
		self.generate_tree_widget(data, self)
		self.insertTopLevelItems(0, self.root_list)
		self.expandAll()
		for i in range(0, 5, 1):
			self.setColumnWidth(i, 400)

	def generate_tree_widget(self, data, root):
		"""
		Doc: none
		Params: data = a nested dictionary
				root = self
		Return: none
		"""
		if isinstance(data, dict):
			for key in data.keys():
				child = QTreeWidgetItem()
				child.setText(0, key)
				if isinstance(root, QTreeWidget) == False:
					root.addChild(child)
				self.root_list.append(child)
				value = data[key]
				self.generate_tree_widget(value, child)
		else:
			root.setText(1, str(data))


if __name__ == '__main__':
	app = QApplication(sys.argv)
	window = TreeWidget(ifc_ergodic)
	window.show()
	sys.exit(app.exec_())