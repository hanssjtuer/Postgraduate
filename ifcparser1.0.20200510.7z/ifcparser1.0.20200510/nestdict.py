def unpack(key, value):
	return {key[0]: value} if len(key) == 1 else {key.pop(0): unpack(key, value)}

def deflat(x: dict):
	for key, value in x.items():
		yield unpack(key.split('.'), value)

def merge(dst, src):
	for key, value in src.items():
		if key not in dst:
			dst[key] = value
		elif isinstance(dst[key], dict) and isinstance(value, dict):
			merge(dst[key], value)
