"""
Author: Cao Jinhao
E-mail1: caojinhao@sjtu.edu.cn
E-mail2: 1823164658@qq.com
Time: 2020/05/09 09:47 <class one>
Description: get the data of project unit <class one>
"""
import re
import codecs


class UnitAssignmentInfo(object):
	"""
	TODO: add decsription here
	"""
	def __init__(self):
		super(UnitAssignmentInfo, self).__init__()
		"""
		TODO: add decsription here
		"""
		#self.unit_assignment_attribute = ['Units']  #TODO
		self.measure_unit_attribute = ['ValueComponent', 'UnitComponent']
		self.dimensional_exponents_attribute = ['LengthExponent', 'MassExponent', 'TimeExponent', 'ElectricCurrentExponent', 'ThermondynamicTemperatureExponent', 'AmountOfSubstanceExponent', 'LuminousIntensityExponent']
		self.si_unit_key = ['Dimensions', 'UnitType', 'Prefix', 'Name']
		self.conversion_based_uint_key = ['Dimensions', 'UnitType', 'Name', 'ConversionFactor']
		self.context_dependent_unit = ['Dimensions', 'UnitType', 'Name']  #TODO

	def get_unit_assignment(self, file_path, line_number):
		"""
		TODO: add decsription here
		"""
		unit_data = {}
		with codecs.open(file_path, 'r', 'utf-8') as f:
			ifc_str = f.read()
			result = re.search('%s\s*=\s*IFCUNITASSIGNMENT\s*\(\s*\((.*?)\)\s*\)\s*;'%line_number, ifc_str)
			if result:
				unit_assignemnet_value = result.group(1).split(',')
				for index, item in enumerate(unit_assignemnet_value):
					unit_assignemnet_value[index] = item.lstrip().rstrip()
				for index, item in enumerate(unit_assignemnet_value):
					unit_data.update(self.get_unit(ifc_str, item))
				print('Unit assignment beginning with %s is %s'%(line_number, unit_data))
			else:
				print('No unit assignment beginning with %s. So get an empty %s'%(line_number, unit_data))
		return unit_data

	def get_unit(self, ifc_str, line_number):
		"""
		TODO: add decsription here
		"""
		result = re.search('%s\s*=(.*?);'%line_number, ifc_str)
		if result:
			unit_value = result.group(1)
			if 'IFCSIUNIT' in unit_value:
				si_unit = re.search('IFCSIUNIT\s*\((.*?)\)\s*', unit_value).group(1).split(',')
				for index, item in enumerate(si_unit):
					si_unit[index] = item.lstrip().rstrip()
				return {si_unit[1].lower().replace('.', ''): dict(zip(self.si_unit_key, si_unit))}

			elif 'IFCCONVERSIONBASEDUNIT' in unit_value:
				conversion_based_uint = re.search('IFCCONVERSIONBASEDUNIT\s*\((.*?)\)\s*', unit_value).group(1).split(',')
				for index, item in enumerate(conversion_based_uint):
					conversion_based_uint[index] = item.lstrip().rstrip()
				conversion_based_uint[0] = self.get_demensional_exponent(ifc_str, conversion_based_uint[0])
				conversion_based_uint[-1] = self.get_measure_unit(ifc_str, conversion_based_uint[-1])
				return {conversion_based_uint[1].lower().replace('.', ''): dict(zip(self.conversion_based_uint_key, conversion_based_uint))}

			elif 'IFCCONTEXTDEPENDENTUNIT' in unit_value:
				pass  #TODO
		else:
			print('No unit beginning with %s.'%line_number)
			return {line_number: None}

	def get_demensional_exponent(self, ifc_str, line_number):
		"""
		TODO: add decsription here
		"""
		result = re.search('%s\s*=\s*IFCDIMENSIONALEXPONENTS\s*\((.*?)\)\s*;'%line_number, ifc_str)
		if result:
			dimensional_exponent_value = result.group(1).split(',')
			return dict(zip(self.dimensional_exponents_attribute, dimensional_exponent_value))
		else:
			print('No dimensional exponent beginning with %s.'%line_number)
			return {line_number: None}

	def get_measure_unit(self, ifc_str, line_number):
		"""
		TODO: add decsription here
		"""	
		result = re.search('%s\s*=\s*IFCMEASUREWITHUNIT\s*\((.*?)\)\s*;'%line_number, ifc_str)
		if result:
			measure_unit_value = result.group(1).split(',')
			measure_unit_value[-1] = self.get_unit(ifc_str, measure_unit_value[-1])
			return dict(zip(self.measure_unit_attribute, measure_unit_value))
		else:
			print('No measure unit beginning with %s.'%line_number)
			return {line_number: None}


UnitAssignmentInfo().get_unit_assignment('example.ifc', '#7')