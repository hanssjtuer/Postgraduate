import re

class projectinfo(object):
	def __init__(self):
		super(projectinfo, self).__init__()
		self.projectinfo = {}
		self.prepare = ['ifcproject'.upper(), 'ifcrelaggregates'.upper()]
		
	def fillprojectinfo(self, filepath):
		ifcstr = open(filepath).read().replace('(', '[').replace(')', ']')
		pro = re.search(self.prepare[0] + '(.*?);\s*\n', ifcstr).group(1).replace('$', 'None')
		num = int(re.search('#(.*?)=\s*' + self.prepare[0], ifcstr).group(1))
		for i in re.findall('#\s*\d*', pro):
			pro = pro.replace(i, "'" + i + "'", 1)
		protuple = eval(pro)
		self.projectinfo['private.globalid'] = protuple[0]
		self.projectinfo['private.ownerhistory'] = protuple[1]
		self.projectinfo['private.name'] = protuple[2]
		self.projectinfo['private.description'] = protuple[3]
		self.projectinfo['private.objecttype'] = protuple[4]
		self.projectinfo['private.longname'] = protuple[5]
		self.projectinfo['private.phase'] = protuple[6]
		self.projectinfo['private.representationcontexts'] = protuple[7]
		self.projectinfo['private.unitsincontext'] = protuple[8]
		self.projectinfo['private.hasassignment'] = []
		self.projectinfo['private.decomposes'] = []
		self.projectinfo['private.hasassociations'] = []
		self.projectinfo['private.isdefinedby'] = ''
		buff = re.search('#(.*?)#\s*' + str(num) + '\s*,', ifcstr).group(0)
		relate = re.match('#\s*\d*', buff).group()
		self.projectinfo['private.isdecomposedby'] = relate
		self.projectinfo['geometry'] = {}
		self.projectinfo['properties'] = {}
		sit = re.search(relate + '\s*=\s*(.*?);\s*\n', ifcstr).group(1).replace(self.prepare[1], '')
		for i in re.findall('#\s*\d*', sit):
			sit = sit.replace(i, "'"+i+"'", 1)
		sit = eval(sit)
		siteset = sit[-1]
		for index, item in enumerate(siteset):
			self.projectinfo['decomposition.sites.site' + str(index + 1)] = item
		cuff = {}
		for key, value in self.projectinfo.items():
			cuff['ifcproject '+protuple[2]+'('+protuple[3]+').' + key] = value
		return cuff