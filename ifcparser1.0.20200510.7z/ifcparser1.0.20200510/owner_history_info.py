import re
import codecs

class OwnerHistoryInfo(object):
    """
    TODO
    """
    def __init__(self):
        super(OwnerHistoryInfo, self).__init__()
        self.owner_history_key = ['OwningUser', 'OwningApplication', 'State', 'ChangeAction', 'LastModifiedDate', 'LastModifyingUser', 'LastModifyingApplication', 'CreationDate']
        self.person_organization_attribute = ['ThePerson', 'TheOrganization', 'Roles']
        self.person_attribute = ['Id', 'FamilyName', 'GivenName', 'MiddleNames', 'PrefixTitles', 'SuffixTitles', 'Roles', 'Addresses', 'EngagedIn']
        self.organization_attribute = ['Id', 'Name', 'Description', 'Roles', 'Addresses', 'IsRelatedBy', 'Relates', 'Engages']
        self.application_attribute = ['ApplicationDeveloper', 'Version', 'ApplicationFullName', 'ApplicationIdentifier']
    
    def get_owner_history(self, file_path, line_number):
        """
        TODO
        """
        with codecs.open(file_path, 'r', 'utf-8') as f:
        	ifc_str = f.read()
        	result = re.search('%s\s*=\s*IFCOWNERHISTORY\s*\((.*?)\)\s*;'%line_number, ifc_str)
        	if result:
        		owner_history_value = result.group(1).split(',')
        		for index, item in enumerate(owner_history_value):
        			owner_history_value[index] = item.lstrip().rstrip()
        		owner_history_value[0] = self.get_person_organization(ifc_str, owner_history_value[0])
        		owner_history_value[1] = self.get_application(ifc_str, owner_history_value[1])
        		owner_history_data = dict(zip(self.owner_history_key, owner_history_value))
        		print('Owner history beginning with %s is %s'%(line_number, owner_history_data))
        	else:
        		print('No owner history beginning with %s'%line_number)
        return owner_history_data

    def get_person_organization(self, ifc_str, line_number):
    	result = re.search('%s\s*=\s*IFCPERSONANDORGANIZATION\s*\((.*?)\)\s*;'%line_number, ifc_str)
    	if result:
    		person_organization_value = result.group(1).split(',')
    		for index, item in enumerate(person_organization_value):
    			person_organization_value[index] = item.lstrip().rstrip()
    		person_organization_value[0] = self.get_person(ifc_str, person_organization_value[0])
    		person_organization_value[1] = self.get_organization(ifc_str, person_organization_value[1])
    		return person_organization_value
    	else:
    		print('No person and organization beginning with %s.'%line_number)
    		return line_number

    def get_person(self, ifc_str, line_number):
    	result = re.search('%s\s*=\s*IFCPERSON\s*\((.*?)\)\s*;'%line_number, ifc_str)
    	if result:
    		person_value = result.group(1).split(',')
    		for index, item in enumerate(person_value):
    			person_value[index] = item.lstrip().rstrip()
    		return person_value
    	else:
    		print('No person beginning with %s'%line_number)
    		return line_number

    def get_organization(self, ifc_str, line_number):
    	result = re.search('%s\s*=\s*IFCORGANIZATION\s*\((.*?)\)\s*;'%line_number, ifc_str)
    	if result:
    		organization_value = result.group(1).split(',')
    		for index, item in enumerate(organization_value):
    			organization_value[index] = item.lstrip().rstrip()
    		return organization_value
    	else:
    		print('No organization beginning with %s'%line_number)
    		return line_number

    def get_application(self, ifc_str, line_number):
    	result = re.search('%s\s*=\s*IFCAPPLICATION\s*\((.*?)\)\s*;'%line_number, ifc_str)
    	if result:
    		application_value = result.group(1).split(',')
    		for index, item in enumerate(application_value):
    			application_value[index] = item.lstrip().rstrip()
    		application_value[0] = self.get_organization(ifc_str, application_value[0])
    		return application_value
    	else:
    		print('No application beginning with %s'%line_number)
    		return line_number


OwnerHistoryInfo().get_owner_history('example.ifc', '#2')