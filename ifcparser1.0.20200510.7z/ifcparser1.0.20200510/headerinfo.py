import re

class headerinfo(object):
	def __init__(self):
		super(headerinfo, self).__init__()
		self.headerinfo = {}
		self.prepare = ['file_description'.upper(), 'file_name'.upper(), 'file_schema'.upper()]

	def fillheaderinfo(self, filepath):
		ifcstr = open(filepath).read().replace('(', '[').replace(')', ']')
		des = eval(re.search(self.prepare[0]+'(.*?);\s*\n', ifcstr).group(1))
		nam = eval(re.search(self.prepare[1]+'(.*?);\s*\n', ifcstr).group(1))
		sch = eval(re.search(self.prepare[2]+'(.*?);\s*\n', ifcstr).group(1))
		for index, item in enumerate(des[0]):
			self.headerinfo['setofdescriptions.descriptions.description'+str(index+1)] = item
		self.headerinfo['implementationlevel'] = des[1]
		self.headerinfo['name'] = nam[0]
		self.headerinfo['timestamp'] = nam[1]
		for index, item in enumerate(nam[2]):
			self.headerinfo['setofauthors.authors.author' + str(index + 1)] = item
		for index, item in enumerate(nam[3]):
			self.headerinfo['setoforganizations.organizations.organization' + str(index + 1)] = item
		self.headerinfo['preprocessorversion'] = nam[4]
		self.headerinfo['originatingsystem'] = nam[5]
		self.headerinfo['authorization'] = nam[6]
		for index, item in enumerate(sch[0]):
			self.headerinfo['setofileschemas.fileschemas.fileschema' + str(index + 1)] = item
		buff = {}
		for key, value in self.headerinfo.items():
			buff["header ''('')." + key] = value
		return buff
