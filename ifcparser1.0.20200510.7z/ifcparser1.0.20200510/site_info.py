import re

class siteinfo(object):
    def __init__(self):
        super(siteinfo, self).__init__()
        self.site_data = {}
        self.prepare = ['ifcsite'.upper(), 'ifcrelaggregates'.upper()]
        self.site_key = [['GlobalId', 'OwnerHistory', 'Name', 'Description',
                        'ObjectType', 'IsDefinedBy',
                        'ObjectPlacement', 'Representation', 'ReferencedBy',
                        'LongName', 'CompositionType', 'ReferencesElements', 'ServicedBySystems', 'ContainsElements'],
                         ['RefLatitude', 'RefLongitude', 'RefElevation', 'LandTitleNumber', 'SiteAddress'],
                         ['HasAssignments', 'IsDecomposedBy', 'Decomposes', 'HasAssociations']]

    def fillsiteinfo(self, filepath, relate):
        ifcstr = open(filepath).read().replace('(', '[').replace(')', ']')
        sit = re.search(relate + '\s*=\s*(.*?);\s*\n', ifcstr).group(1).replace(self.prepare[1], '')
        for i in re.findall('#\s*\d*', sit):
            sit = sit.replace(i, "'" + i + "'", 1)
        for index, item in enumerate(eval(sit)[-1]):
            site = re.search(item + '\s*=\s*' + self.prepare[0] + '(.*?);\s*\n', ifcstr).group(1).replace('.element.'.upper(), "'.element.'").replace('$', "'$'")
            for i in re.findall('#\s*\d*', site):
                site = site.replace(i, "'" + i + "'", 1)
            site = eval(site)
            for index, item in enumerate(site):
            	self.site_data['%s.private.%s'%(("ifcSite %s(%s)"%(site[2], site[3]), self.site_key[0][index]))] = item
            print(self.site_data)


        return {}

_dict = siteinfo().fillsiteinfo('exampleWall.ifc', '#45')
nestdict = {}

def unpack(key, value):
    return {key[0]: value} if len(key) == 1 else {key.pop(0): unpack(key, value)}

def deflat(x: dict):
    for key, value in x.items():
        yield unpack(key.split('.'), value)

def merge(dst, src):
    for key, value in src.items():
        if key not in dst:
            dst[key] = value
        elif isinstance(dst[key], dict) and isinstance(value, dict):
            merge(dst[key], value)

for d in deflat(_dict):
    merge(nestdict, d)
