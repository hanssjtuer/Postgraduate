﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Diagnostics;
using System.Runtime.InteropServices;
using SharpDX.Direct3D9;
using SharpDX;
using SharpDX.Mathematics.Interop;

#if _WIN64
using int_t = System.Int64;
#else
using int_t = System.Int32;
#endif

namespace IFCViewer
{
    /// <summary>
    /// IFC Model
    /// </summary>
    class IFCModel
    {
        #region Members

        /// <summary>
        /// IFC Model
        /// </summary>
        private int_t _iModel = 0;

        /// <summary>
        /// The root of an the IFC tree
        /// </summary>
        private IFCItem _rootIfcItem = null;

        /// <summary>
        /// List of the IFCItems with a geometry
        /// </summary>
        private List<IFCItem> _lsGeometry = new List<IFCItem>();

        /// <summary>
        /// Materials
        /// </summary>
        private IFCMaterialsBuilder _materailsBuilder = null;

        /// <summary>
        /// Groups of faces
        /// </summary>
        private Dictionary<Material, List<KeyValuePair<IFCItem, STRUCT_MATERIALS>>> _dicFacesGroups = new Dictionary<Material, List<KeyValuePair<IFCItem, STRUCT_MATERIALS>>>();

        public static List<string> data = new List<string>() { };
        #endregion // Members

        #region Events

        /// <summary>
        /// An IFC model has been loaded
        /// </summary>
        public event EventHandler ModelLoaded;

        #endregion // Events

        /// <summary>
        /// ctor
        /// </summary>
        public IFCModel()
        {
        }

        /// <summary>
        /// Loads an IFC file
        /// </summary>
        /// <param name="strIfcFilePath"></param>
        /// <returns></returns>
        public bool Load(string strIfcFilePath)
        {
            _iModel = 0;
            _rootIfcItem = null;
            _lsGeometry = new List<IFCItem>();
            _materailsBuilder = null;
            _dicFacesGroups = new Dictionary<Material, List<KeyValuePair<IFCItem, STRUCT_MATERIALS>>>();

            return ParseIFCFile(strIfcFilePath);
        }

        /// <summary>
        /// Getter
        /// </summary>
        public int_t Model
        {
            get
            {
                return _iModel;
            }
        }

        /// <summary>
        /// Getter
        /// </summary>
        public IFCItem Root
        {
            get
            {
                return _rootIfcItem;
            }
        }

        /// <summary>
        /// Getter
        /// </summary>
        public List<IFCItem> Geometry
        {
            get
            {
                return _lsGeometry;
            }
        }

        /// <summary>
        /// Getter
        /// </summary>
        public IFCMaterialsBuilder MaterailsBuilder
        {
            get
            {
                return _materailsBuilder;
            }
        }

        /// <summary>
        /// Getter
        /// </summary>
        public Dictionary<Material, List<KeyValuePair<IFCItem, STRUCT_MATERIALS>>> FacesGroups
        {
            get
            {
                return _dicFacesGroups;
            }
        }

        /// <summary>
        /// Fires ModelLoaded event
        /// </summary>
        private void FireModelLoaded()
        {
            if (ModelLoaded != null)
            {
                ModelLoaded(this, new EventArgs());
            }
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="strPath"></param>
        /// <returns></returns>
        private bool ParseIFCFile(string strPath)
        {
            if (!File.Exists(strPath))
            {
                return false;
            }

            _iModel = IfcEngine.x86_64.sdaiOpenModelBN(0, strPath, "IFC2X3_TC1.exp");
            if (_iModel == 0)
            {
                return false;
            }

            string xmlSettings_IFC2x3 = @"IFC2X3-Settings.xml";
            string xmlSettings_IFC4 = @"IFC4-Settings.xml";

            IntPtr outputValue = IntPtr.Zero;
            IfcEngine.x86_64.GetSPFFHeaderItem(_iModel, 9, 0, IfcEngine.x86_64.sdaiUNICODE, out outputValue);

            string strVersion = Marshal.PtrToStringUni(outputValue);

            XmlTextReader textReader = null;
            if (strVersion.Contains("IFC2") == true)
            {
                textReader = new XmlTextReader(xmlSettings_IFC2x3);
            }
            else
            {
                if (strVersion.Contains("IFC4x") == true)
                {
                    IfcEngine.x86_64.sdaiCloseModel(_iModel);
                    _iModel = IfcEngine.x86_64.sdaiOpenModelBN(0, strPath, "IFC4X1.exp");

                    if (_iModel != 0)
                    {
                        textReader = new XmlTextReader(xmlSettings_IFC4);
                    }
                }
                else
                {
                    if (strVersion.Contains("IFC4") == true)
                    {
                        IfcEngine.x86_64.sdaiCloseModel(_iModel);
                        _iModel = IfcEngine.x86_64.sdaiOpenModelBN(0, strPath, "IFC4_ADD2.exp");

                        if (_iModel != 0)
                        {
                            textReader = new XmlTextReader(xmlSettings_IFC4);
                        }
                    }
                }
            }

            if (textReader == null)
            {
                return false;
            }

            // if node type us an attribute
            while (textReader.Read())
            {
                textReader.MoveToElement();

                if (textReader.AttributeCount > 0)
                {
                    if (textReader.LocalName == "object")
                    {
                        if (textReader.GetAttribute("name") != null)
                        {
                            string strNameAttribute = textReader.GetAttribute("name").ToString();

                            int_t iCircleSegments = IFCItem.DEFAULT_CIRCLE_SEGMENTS;
                            if (textReader.GetAttribute("segments") != null)
                            {
                                string strSegmentsAttribute = textReader.GetAttribute("segments").ToString();

                                iCircleSegments = int_t.Parse(strSegmentsAttribute);
                            }

                            RetrieveObjects(_iModel, strNameAttribute, iCircleSegments);
                        }
                    } // if (textReader.GetAttribute("name") != null)
                }
            } // while (textReader.Read())

            _materailsBuilder = new IFCMaterialsBuilder(_iModel);

            GenerateGeometry(_iModel, _rootIfcItem);

            _materailsBuilder.finalizeMaterials();

            /*
             * Group the items
             */
            if (_materailsBuilder != null)
            {
                for (int iMaterial = 0; iMaterial < _materailsBuilder.Materials.Count; iMaterial++)
                {
                    List<KeyValuePair<IFCItem, STRUCT_MATERIALS>> lsFaces = new List<KeyValuePair<IFCItem, STRUCT_MATERIALS>>();

                    for (int iItem = 0; iItem < _lsGeometry.Count; iItem++)
                    {
                        STRUCT_MATERIALS materials = _lsGeometry[iItem].materials;
                        while (materials != null)
                        {
                            if (materials.material.MTRL.Equals(_materailsBuilder.Materials[iMaterial]))
                            {
                                lsFaces.Add(new KeyValuePair<IFCItem, STRUCT_MATERIALS>(_lsGeometry[iItem], materials));
                            }

                            materials = materials.next;
                        } // while (materials != null) 
                    }

                    _dicFacesGroups[_materailsBuilder.Materials[iMaterial]] = lsFaces;
                } // for (int iMaterial = ...
            } // if (_materailsBuilder != null)

            /*
             * Notify the clients
             */
            FireModelLoaded();

            IfcEngine.x86_64.sdaiCloseModel(_iModel);

            return true;
        }

        /// <summary>
        /// Generates the indices/vertices
        /// </summary>
        /// <param name="ifcModel"></param>
        /// <param name="ifcItem"></param>
        private void GenerateGeometry(int_t ifcModel, IFCItem ifcItem)
        {
            while (ifcItem != null)
            {
                RetrieveGeometry(ifcModel, ifcItem);

                IfcEngine.x86_64.cleanMemory(ifcModel, 0);

                GenerateGeometry(ifcModel, ifcItem.child);

                ifcItem = ifcItem.next;
            } // while (ifcItem != ...
        }


        /// <summary>
        /// Retrieves the geometry
        /// </summary>
        /// <param name="ifcModel"></param>
        /// <param name="ifcItem"></param>
        private void RetrieveGeometry(int_t ifcModel, IFCItem ifcItem)
        {
            if (ifcItem.instance == 0)
            {
                return;
            }

//            SetFormat(ifcModel, false);
            SetFormat(ifcModel, true);

            if (ifcItem.circleSegments != IFCItem.DEFAULT_CIRCLE_SEGMENTS)
            {
                IfcEngine.x86_64.circleSegments(ifcItem.circleSegments, 5);
            }

            int_t iVerticesCount = 0;
            int_t iIndicesCount = 0;
            IfcEngine.x86_64.initializeModellingInstance(ifcModel, ref iVerticesCount, ref iIndicesCount, 0, ifcItem.instance);

            if ((iVerticesCount == 0) || (iIndicesCount == 0))
            {
                if (ifcItem.circleSegments != IFCItem.DEFAULT_CIRCLE_SEGMENTS)
                {
                    IfcEngine.x86_64.circleSegments(IFCItem.DEFAULT_CIRCLE_SEGMENTS, 5);
                }

                return;
            }

            ifcItem.verticesCount = iVerticesCount;
            ifcItem.vertices = new float[6 * iVerticesCount];

            int[] indices = new int[iIndicesCount];

            IfcEngine.x86_64.finalizeModelling(ifcModel, ifcItem.vertices, indices, 0);

            if (ifcItem.circleSegments != IFCItem.DEFAULT_CIRCLE_SEGMENTS)
            {
                IfcEngine.x86_64.circleSegments(IFCItem.DEFAULT_CIRCLE_SEGMENTS, 5);
            }

            List<int> lsFacesIndices = new List<int>();
            List<int> lsWireframesIndices = new List<int>();
            List<int_t> lsPrimitivesForFaces = new List<int_t>();

            Int64 iFacesCount = IfcEngine.x86_64.GetConceptualFaceCnt(ifcItem.instance);

            List<int_t> lsMaxIndex = new List<int_t>();

            for (Int64 iFace = 0; iFace < iFacesCount; iFace++)
            {
                Int64 iStartIndexTriangles = 0;
                Int64 iIndicesCountTriangles = 0;

                Int64 iStartIndexLines = 0;
                Int64 iIndicesCountLines = 0;

                Int64 iStartIndexPoints = 0;
                Int64 iIndicesCountPoints = 0;

                Int64 iStartIndexFacesPolygons = 0;
                Int64 iIndicesCountFacesPolygons = 0;

                Int64 iValue = 0;
                IfcEngine.x86_64.GetConceptualFaceEx(ifcItem.instance,
                    iFace,
                    ref iStartIndexTriangles,
                    ref iIndicesCountTriangles,
                    ref iStartIndexLines,
                    ref iIndicesCountLines,
                    ref iStartIndexPoints,
                    ref iIndicesCountPoints,
                    ref iStartIndexFacesPolygons,
                    ref iIndicesCountFacesPolygons,
                    ref iValue,
                    ref iValue);

                lsMaxIndex.Add(0);

                if (iFace > 0)
                {
                    lsMaxIndex[(int)iFace] = lsMaxIndex[(int)iFace - 1];
                }
                else
                {
                    lsMaxIndex[(int)iFace] = 0;
                }

                if ((iIndicesCountTriangles > 0) && (lsMaxIndex[(int)iFace] < iStartIndexTriangles + iIndicesCountTriangles))
                {
                    lsMaxIndex[(int)iFace] = (int_t) (iStartIndexTriangles + iIndicesCountTriangles);
                }

                if ((iIndicesCountLines > 0) && (lsMaxIndex[(int)iFace] < iStartIndexLines + iIndicesCountLines))
                {
                    lsMaxIndex[(int)iFace] = (int_t) (iStartIndexLines + iIndicesCountLines);
                }

                if ((iIndicesCountPoints > 0) && (lsMaxIndex[(int)iFace] < iStartIndexPoints + iIndicesCountPoints))
                {
                    lsMaxIndex[(int)iFace] = (int_t)  (iStartIndexPoints + iIndicesCountPoints);
                }

                if ((iIndicesCountFacesPolygons > 0) && (lsMaxIndex[(int)iFace] < iStartIndexFacesPolygons + iIndicesCountFacesPolygons)) 
                {
                    lsMaxIndex[(int)iFace] = (int_t) (iStartIndexFacesPolygons + iIndicesCountFacesPolygons);
                }

                lsPrimitivesForFaces.Add((int_t)iIndicesCountTriangles / 3);

                for (int_t iIndexTriangles = (int_t)iStartIndexTriangles; iIndexTriangles < iStartIndexTriangles + iIndicesCountTriangles; iIndexTriangles++)
                {
                    lsFacesIndices.Add(indices[iIndexTriangles]);
                }

                int_t iIndexWireframes = 0;
                int iLastIndex = -1;
                while (iIndexWireframes < iIndicesCountFacesPolygons)
                {
                    if ((iLastIndex >= 0) && (indices[iStartIndexFacesPolygons + iIndexWireframes] >= 0))
                    {
                        lsWireframesIndices.Add(iLastIndex);

                        lsWireframesIndices.Add(indices[iStartIndexFacesPolygons + iIndexWireframes]);
                    }

                    iLastIndex = indices[iStartIndexFacesPolygons + iIndexWireframes];
                    iIndexWireframes++;
                }
            } // for (int_t iFace ...

            ifcItem.indicesForFaces = lsFacesIndices.ToArray();
            ifcItem.indicesForWireFrameLineParts = lsWireframesIndices.ToArray();

            ifcItem.materials = _materailsBuilder.extractMaterials(ifcItem.instance);

            ///////////////////////////////////////////////////////////////////////////////////////////////////
            if (ifcItem.materials != null)
            {
                STRUCT_MATERIALS materials = ifcItem.materials;
                if (materials.next != null)
                {
                    int_t indexBufferSize = 0, indexArrayOffset = 0, j = 0;
                    while (materials != null)
                    {
                        Debug.Assert(materials.__indexBufferSize >= 0);
                        Debug.Assert(materials.__noPrimitivesForFaces == 0);
                        indexBufferSize += materials.__indexBufferSize;
                        materials.__indexArrayOffset = indexArrayOffset;
                        while ((j < iFacesCount) && (lsMaxIndex[(int)j] <= indexBufferSize))
                        {
                            materials.__noPrimitivesForFaces += lsPrimitivesForFaces[(int)j];
                            indexArrayOffset += 3 * lsPrimitivesForFaces[(int)j];
                            j++;
                        }
                        materials = materials.next;
                    }

//                    Debug.Assert(j == iFacesCount && indexBufferSize == ifcItem.indicesForFaces.Length);
                }
                else
                {
                    Debug.Assert(materials.__indexBufferSize == -1);
                    materials.__indexArrayOffset = 0;
                    materials.__noPrimitivesForFaces = ifcItem.TrianglesCount;
                }
            } // if (ifcItem.materials != null)
            ///////////////////////////////////////////////////////////////////////////////////////////////////
            _lsGeometry.Add(ifcItem);
            float[] temp = ifcItem.vertices;
            //foreach (int ol in ifcItem.TrianglesCount)
            //{
            //Console.WriteLine(ifcItem.TrianglesCount);
            List<double> str_temp =  new List<double>(){ };
            for (int ol=0;ol< ifcItem.TrianglesCount;ol++)
            {
                double X = (ifcItem.vertices[6 * ifcItem.indicesForFaces[3 * ol + 0] + 0]);
                double Y = (ifcItem.vertices[6 * ifcItem.indicesForFaces[3 * ol + 0] + 1]);
                double Z = (ifcItem.vertices[6 * ifcItem.indicesForFaces[3 * ol + 0] + 2]);
                double X1 = (ifcItem.vertices[6 * ifcItem.indicesForFaces[3 * ol + 1] + 0]);
                double Y1 = (ifcItem.vertices[6 * ifcItem.indicesForFaces[3 * ol + 1] + 1]);
                double Z1 = (ifcItem.vertices[6 * ifcItem.indicesForFaces[3 * ol + 1] + 2]);
                double X2 = (ifcItem.vertices[6 * ifcItem.indicesForFaces[3 * ol + 2] + 0]);
                double Y2 = (ifcItem.vertices[6 * ifcItem.indicesForFaces[3 * ol + 2] + 1]);
                double Z2 = (ifcItem.vertices[6 * ifcItem.indicesForFaces[3 * ol + 2] + 2]);
                //Console.WriteLine(X+","+Y+","+Z);
                str_temp.Add(X);
                str_temp.Add(Y);
                str_temp.Add(Z);
                str_temp.Add(X1);
                str_temp.Add(Y1);
                str_temp.Add(Z1);
                str_temp.Add(X2);
                str_temp.Add(Y2);
                str_temp.Add(Z2);
            }
            data.Add(string.Join(",", str_temp));
        }
        
        /// <summary>
        /// Format
        /// </summary>
        /// <param name="ifcModel"></param>
        /// <param name="bWireframes"></param>
        private void SetFormat(Int64 ifcModel, bool bWireframes = true)
        {
            Int64 mask = 0;
            mask += IfcEngine.x86_64.flagbit2;                          // PRECISION (32/64 bit)
            mask += IfcEngine.x86_64.flagbit3;                          // INDEX ARRAY (32/64 bit)
            mask += IfcEngine.x86_64.flagbit5;                          // NORMALS
            mask += IfcEngine.x86_64.flagbit8;                          // TRIANGLES
            mask += IfcEngine.x86_64.flagbit12;                         // WIREFRAME

            Int64 setting = 0;
            setting += 0;                                               // SINGLE PRECISION (float)
            //  - IndexBuffer() doesn't support 64 bits
            //setting += IfcEngine.x86.flagbit3;                        // 64 BIT INDEX ARRAY (Int64)
            setting += IfcEngine.x86_64.flagbit5;                       // NORMALS ON
            setting += IfcEngine.x86_64.flagbit8;                       // TRIANGLES ON
            setting += bWireframes ? IfcEngine.x86_64.flagbit12 : 0;    // WIREFRAME ON
            IfcEngine.x86_64.SetFormat(ifcModel, setting, mask);
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="ifcModel"></param>
        /// <param name="strIfcType"></param>
        /// <param name="iCircleSegments"></param>
        private void RetrieveObjects(int_t ifcModel, string strIfcType, int_t iCircleSegments)
        {
            int_t ifcObjectInstances = IfcEngine.x86_64.sdaiGetEntityExtentBN(ifcModel, strIfcType),
                noIfcObjectIntances = IfcEngine.x86_64.sdaiGetMemberCount(ifcObjectInstances);

            if (noIfcObjectIntances != 0)
            {
                IFCItem NewItem = null;
                if (_rootIfcItem == null)
                {
                    _rootIfcItem = new IFCItem();
                    _rootIfcItem.CreateItem(null, 0, "");

                    NewItem = _rootIfcItem;
                }
                else
                {
                    IFCItem LastItem = _rootIfcItem;
                    while (LastItem != null)
                    {
                        if (LastItem.next == null)
                        {
                            LastItem.next = new IFCItem();
                            LastItem.next.CreateItem(null, 0, "");

                            NewItem = LastItem.next;

                            break;
                        }
                        else
                            LastItem = LastItem.next;
                    };
                }


                for (int_t i = 0; i < noIfcObjectIntances; ++i)
                {
                    int_t ifcObjectIns = 0;
                    IfcEngine.x86_64.engiGetAggrElement(ifcObjectInstances, i, IfcEngine.x86_64.sdaiINSTANCE, out ifcObjectIns);                    

                    IFCItem subItem = new IFCItem();
                    subItem.circleSegments = iCircleSegments;
                    subItem.CreateItem(NewItem, ifcObjectIns, strIfcType);
                }
            }
        }
    }
}
