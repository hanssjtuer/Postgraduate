﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Diagnostics;
using System.Runtime.InteropServices;
using SharpDX.Direct3D9;
using SharpDX;
using SharpDX.Mathematics.Interop;

#if _WIN64
using int_t = System.Int64;
#else
using int_t = System.Int32;
#endif

namespace IFCViewer
{
    /// <summary>
    /// Types of supported movements
    /// </summary>
    enum MOVE_TYPE
    {
        ROTATE,
        PAN,
        ZOOM,
        NONE,
    }

    /// <summary>
    /// Renderer 
    /// </summary>
    class SharpDXRenderer : IIFCRenderer
    {
        #region Members

        /// <summary>
        /// Direct3D engine
        /// </summary>
        private Direct3D _direct3D = null;

        /// <summary>
        /// Direct3D device
        /// </summary>
        private Device _device = null;

        /// <summary>
        /// IFC Model
        /// </summary>
        private IFCModel _model = null;

        /// <summary>
        /// Show/Hide the faces
        /// </summary>
        private bool _bShowFaces = true;

        /// <summary>
        /// Show/Hide the wireframes
        /// </summary>
        private bool _bShowWireframes = true;

        /// <summary>
        /// Select on mouse hover
        /// </summary>
        private bool _bSelectOnMouseHover = true;

        /// <summary>
        /// UI
        /// </summary>
        private Control _destControl = null;

        /// <summary>
        /// Eye point
        /// </summary>
        private Vector3 _vecEyePoint = new Vector3(2.0f, 0f, 0f);

        /// <summary>
        /// Target point
        /// </summary>
        private Vector3 _vecTargetPoint = new Vector3(0.0f, 0.0f, 0.0f);

        /// <summary>
        ///  Up vector
        /// </summary>
        private Vector3 _vecUpVector = new Vector3(0.0f, 0.0f, 1.0f);

        /// <summary>
        /// Counter for MouseMove events
        /// </summary>
        private int _counter = 0;        

        /// <summary>
        /// Translate by Y
        /// </summary>
        private float _fTranslateY = 0;

        /// <summary>
        /// Translate by Z
        /// </summary>
        private float _fTranslateZ = 0;

        /// <summary>
        /// User's interaction
        /// </summary>
        private MOVE_TYPE _currentMoveType = MOVE_TYPE.NONE;

        /// <summary>
        /// User's interaction
        /// </summary>
        private System.Drawing.Point _startPoint = new System.Drawing.Point(-1, -1);

        /// <summary>
        /// User's interaction
        /// </summary>
        private System.Drawing.Point _endPoint = new System.Drawing.Point(-1, -1);

        /// <summary>
        /// The position in the Vertex buffer array
        /// </summary>
        private int_t iCurrentPosVertextBuffer = 0;

        /// <summary>
        /// The position in the Index buffer array
        /// </summary>        
        private int_t _iCurrentPosIndexBuffer = 0;

        /// <summary>
        /// ?
        /// </summary>
        private float roll_val = 0.0f;

        /// <summary>
        /// ?
        /// </summary>
        private float pitch_val = 0.0f;

        /// <summary>
        /// ?
        /// </summary>
        private float yaw_val = 0.0f;

        /// <summary>
        /// ?
        /// </summary>
        private float _zoomIndex = 0F;

        /// <summary>
        /// Material
        /// </summary>
        Material _mtrlBlack;

        /// <summary>
        /// Material
        /// </summary>
        Material _mtrSelect;

        /// <summary>
        /// Target IFC item
        /// </summary>
        private IFCItem _hoverIfcItem = null;

        /// <summary>
        /// Target IFC item
        /// </summary>
        private IFCItem _selectedIfcItem = null;

        /// <summary>
        /// Scale/center support
        /// </summary>
        Vector3 _center = new Vector3();

        /// <summary>
        /// Scale/center support
        /// </summary>
        float _size = 0;        

        /// <summary>
        /// Describes a vertex
        /// </summary>
        private VertexElement[] _vertexElements = null;

        /// <summary>
        /// Describes a vertex
        /// </summary>
        private VertexDeclaration _vertexDeclaration = null;

        /// <summary>
        /// Vertices - faces and wireframes
        /// </summary>
        private VertexBuffer _vertexBuffer = null;

        /// <summary>
        /// Indices - faces
        /// </summary>
        private IndexBuffer _facesIndexBuffer = null;

        /// <summary>
        /// Indices - wireframes
        /// </summary>
        private IndexBuffer _wireframesIndexBuffer = null;

        #endregion // Members

        /// <summary>
        /// ctor
        /// </summary>
        public SharpDXRenderer(IFCModel model, Control control)
        {
            if ((model == null) || (control == null))
            {
                throw new ArgumentNullException();
            }

            /*
             * Model
             */ 
            _model = model;

            /*
             * ModelLoaded event handler
             */
            _model.ModelLoaded += (s, e) =>
                {
                    Reset();

                    InitalizeDeviceBuffer();

                    this.Redraw();
                };

            /*
             * UI
             */
            _destControl = control;

            /*
             * Paint event handler
             */
            _destControl.Paint += (s, e) =>
                {
                    this.Redraw();
                };

            /*
             * MouseMove event handler
             */
            _destControl.MouseMove += (s, e) =>
                {
                    if (_counter == 0)
                    {
                        _startPoint = _endPoint;
                        _counter = 10;
                    }
                    else
                    {
                        _counter--;
                    }                        

                    _endPoint = e.Location;
                    float _stepTranslate = 0.01F;

                    // check direction of movement
                    bool MoveRight = (_startPoint.X <= _endPoint.X);

                    // check direction of movement
                    bool MoveUp = (_startPoint.Y >= _endPoint.Y);
                    int deltaY = Math.Abs(_startPoint.Y - _endPoint.Y);
                    int deltaX = Math.Abs(_startPoint.X - _endPoint.X);

                    switch (_currentMoveType)
                    {
                        case MOVE_TYPE.ROTATE:
                            {
                                float stepRotate = 1.5F;

                                if (deltaY >= deltaX)
                                {
                                    pitch_val += (MoveUp) ? stepRotate : -stepRotate;
                                }
                                else
                                {
                                    yaw_val += (MoveRight) ? -stepRotate : stepRotate;
                                }                                
                            }
                            break;

                        case MOVE_TYPE.PAN:
                            {
                                _stepTranslate = 0.005F;
                                if (deltaY >= deltaX)
                                {
                                    _fTranslateZ += (MoveUp) ? _stepTranslate : -_stepTranslate;
                                }
                                else
                                {
                                    _fTranslateY += (MoveRight) ? -_stepTranslate : _stepTranslate;

                                }
                            } 
                            break;

                        case MOVE_TYPE.ZOOM:
                            {
                                _zoomIndex += (MoveUp) ? -_stepTranslate : _stepTranslate;
                            }
                            break;
                    } // switch (_currentMoveType)

                    if (_currentMoveType != MOVE_TYPE.NONE)
                    {
                        this.Redraw();
                    }
                    else
                    {
                        if (_bSelectOnMouseHover)
                        {
                            IFCPicker picker = null;
                            picker = new IFCPicker(_device, _center, _size, _model.Root);

                            IFCItem newPickedItem = picker.PickObject(e.Location);

                            if (_hoverIfcItem != null && newPickedItem == null)
                            {
                                _hoverIfcItem = null;

                                this.Redraw();
                            }
                            else
                            {
                                if (_hoverIfcItem != newPickedItem)
                                {
                                    _hoverIfcItem = newPickedItem;

                                    this.Redraw();
                                }
                            }
                        } // if (_bSelectOnMouseHover)
                    }
                };

            /*
             * MouseUp event handler
             */
            _destControl.MouseUp += (s, e) =>
                {
                    _currentMoveType = MOVE_TYPE.NONE;

                    this.Redraw();
                };

            /*
             * MouseUp event handler
             */
            _destControl.MouseDown += (s, e) =>
            {
                _currentMoveType = MOVE_TYPE.NONE;
                _startPoint = e.Location;
                _endPoint = _startPoint;

                switch (e.Button)
                {
                    case MouseButtons.Left: _currentMoveType = MOVE_TYPE.ROTATE; break;
                    case MouseButtons.Right: _currentMoveType = MOVE_TYPE.PAN; break;
                    case MouseButtons.Middle: _currentMoveType = MOVE_TYPE.ZOOM; break;

                }

                if (e.Button == MouseButtons.Left)
                {
                    IFCPicker picker = null;
                    picker = new IFCPicker(_device, _center, _size, _model.Root);

                    IFCItem newPickedItem = picker.PickObject(e.Location);

                    if (_selectedIfcItem != null && newPickedItem == null)
                    {
                        OnSelect(null);
                    }
                    else
                    {
                        if (_selectedIfcItem != newPickedItem)
                        {
                            OnSelect(newPickedItem);

                            /*
                            * Notify the Viewer
                            */
                            if (this.Viewer != null)
                            {
                                this.Viewer.OnSelect(_selectedIfcItem);
                            }
                        }
                    }
                }
            };

            _direct3D = new Direct3D();

            PresentParameters presentParameters = new PresentParameters(_destControl.Width, _destControl.Height);
            presentParameters.SwapEffect = SwapEffect.Discard;
            presentParameters.EnableAutoDepthStencil = true;
            presentParameters.AutoDepthStencilFormat = Format.D16;

            MultisampleType maxMultisampleType = MultisampleType.None;
            for (MultisampleType multisampleType = MultisampleType.None; multisampleType < MultisampleType.SixteenSamples; multisampleType++)
            {
                if (_direct3D.CheckDeviceMultisampleType(0, DeviceType.Hardware, Format.D16, true, multisampleType))
                {
                    maxMultisampleType = multisampleType;
                }
            }

            presentParameters.MultiSampleType = maxMultisampleType;

            _device = new Device(_direct3D, 0, DeviceType.Hardware, control.Handle, CreateFlags.HardwareVertexProcessing, presentParameters);

            _destControl.Resize += (o, args) =>
            {
                presentParameters.BackBufferWidth = _destControl.Width;
                presentParameters.BackBufferHeight = _destControl.Height;

                _device.Reset(presentParameters);
            };

            /*
             * Vertices
             */
            _vertexElements = new[] 
            {
        		new VertexElement(0, 0, DeclarationType.Float3, DeclarationMethod.Default, DeclarationUsage.Position, 0),
                new VertexElement(0, 12/*bytes*/, DeclarationType.Float3, DeclarationMethod.Default, DeclarationUsage.Normal, 0),
				VertexElement.VertexDeclarationEnd
        	};

            _vertexDeclaration = new VertexDeclaration(_device, _vertexElements);

            /*
             * Materials
             */
            _mtrlBlack = new Material();
            _mtrlBlack.Diffuse = _mtrlBlack.Ambient = _mtrlBlack.Specular = new RawColor4(0.0f, 0.0f, 0.0f, 1.0f);
            _mtrlBlack.Emissive = new RawColor4(0.0f, 0.0f, 0.0f, 0.5f);
            _mtrlBlack.Power = 0.5f;

            /*
             * Materials
             */
            _mtrSelect = new Material();
            _mtrSelect.Diffuse = _mtrSelect.Ambient = _mtrSelect.Specular = new RawColor4(0.4f, 0.05f, 0.05f, 0.4f);
            _mtrSelect.Emissive = new RawColor4(0.1f, 0.02f, 0.02f, 0.2f);
            _mtrSelect.Power = 0.5f;
        }
        
        /// <summary>
        /// Sets up format
        /// </summary>
        /// <param name="ifcModel"></param>
        private void SetFormat(Int64 ifcModel)
        {
            Int64 mask = 0;
            mask += IfcEngine.x86_64.flagbit2;        // PRECISION (32/64 bit)
            mask += IfcEngine.x86_64.flagbit3;        // INDEX ARRAY (32/64 bit)
            mask += IfcEngine.x86_64.flagbit5;        // NORMALS
            mask += IfcEngine.x86_64.flagbit8;        // TRIANGLES
            mask += IfcEngine.x86_64.flagbit12;       // WIREFRAME

            Int64 setting = 0;
            setting += 0;                             // SINGLE PRECISION (float)
            //  - IndexBuffer() doesn't support 64 bits
            //setting += IfcEngine.x86.flagbit3;      // 64 BIT INDEX ARRAY (Int64)
            setting += IfcEngine.x86_64.flagbit5;     // NORMALS ON
            setting += IfcEngine.x86_64.flagbit8;     // TRIANGLES ON
            setting += IfcEngine.x86_64.flagbit12;    // WIREFRAME ON
            IfcEngine.x86_64.SetFormat(ifcModel, setting, mask);
        }

        /// <summary>
        /// Setup the lights and materials
        /// </summary>
        private void SetupLights()
        {
            _device.EnableLight(0, true);

            Light light = _device.GetLight(0);
            light.Type = LightType.Directional;
            light.Diffuse = new RawColor4(3.4f, 3.4f, 3.4f, 3.4f);
            light.Specular = new RawColor4(0.1f, 0.1f, 0.1f, 0.5f);
            light.Ambient = new RawColor4(0.5f, 0.5f, 0.5f, 1.0f);
            light.Position = new Vector3(-2.0f, -2.0f, -2.0f);
            light.Direction = Vector3.Normalize(new Vector3(-2.0f, -6.0f, -1.0f));
            light.Range = 5.0f;

            _device.EnableLight(1, true);
            Light light1 = _device.GetLight(1);
            light1.Type = LightType.Directional;
            light1.Diffuse = new RawColor4(3.4f, 3.4f, 3.4f, 3.4f);
            light1.Specular = new RawColor4(0.1f, 0.1f, 0.1f, 0.5f);
            light1.Ambient = new RawColor4(0.5f, 0.5f, 0.5f, 1.0f);
            light1.Position = new Vector3(2.0f, 2.0f, 2.0f);
            light1.Direction = Vector3.Normalize(new Vector3(2.0f, 6.0f, 1.0f));
            light1.Range = 5.0f;

            _device.SetRenderState(RenderState.Lighting, true);
            _device.SetRenderState(RenderState.Ambient, 0x00707070);
            _device.SetRenderState(RenderState.CullMode, 0);
        }

        /// <summary>
        /// Sets up the matrices
        /// </summary>
        private void SetupMatrices()
        {
            // -------------------------------------------------
            // reset World Matrix
            var World = Matrix.Identity;
            World.M22 = -1f;

            _device.SetTransform(TransformState.World, World);

            // -------------------------------------------------
            // apply mouse rotation
            if (roll_val != 0 || pitch_val != 0 || yaw_val != 0)
            {
                Matrix rotationMatrix = Matrix.RotationYawPitchRoll(
                    MathUtil.DegreesToRadians(roll_val),
                    MathUtil.DegreesToRadians(pitch_val),
                    MathUtil.DegreesToRadians(yaw_val));

                _device.SetTransform(TransformState.World, Matrix.Multiply(_device.GetTransform(TransformState.World), rotationMatrix));
            }

            // -------------------------------------------------
            // apply mouse zoom

            if (_zoomIndex != 0)
            {
                Matrix zoomMatrix = Matrix.Translation(new Vector3(_zoomIndex * _vecEyePoint.X, _zoomIndex * _vecEyePoint.Y, _zoomIndex * _vecEyePoint.Z));

                _device.SetTransform(TransformState.World, Matrix.Multiply(_device.GetTransform(TransformState.World), zoomMatrix));
            }

            // -------------------------------------------------
            // apply mouse pan by Z
            if (_fTranslateZ != 0)
            {
                _device.SetTransform(TransformState.World, Matrix.Multiply(_device.GetTransform(TransformState.World), Matrix.Translation(new Vector3(0, 0, _fTranslateZ))));
            }

            // -------------------------------------------------
            // apply mouse pan by X
            if (_fTranslateY != 0)
            {
                _device.SetTransform(TransformState.World, Matrix.Multiply(_device.GetTransform(TransformState.World), Matrix.Translation(new Vector3(0, _fTranslateY, 0))));
            }

            // -------------------------------------------------
            // setup Projection Matrix
            _device.SetTransform(TransformState.Projection, 
                Matrix.PerspectiveFovLH((float)Math.PI / 4.0F, (float)_destControl.Width / (float)_destControl.Height, 0.03f, 10.0f));            

            // -------------------------------------------------
            // setup View Matrix
            _device.SetTransform(TransformState.View, Matrix.LookAtLH(_vecEyePoint, _vecTargetPoint, _vecUpVector));
        }

        /// <summary>
        /// ?
        /// </summary>
        /// <param name="ifcItem"></param>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <param name="InitMinMax"></param>
        private void GetDimensions(IFCItem ifcItem, ref Vector3 min, ref Vector3 max, ref bool InitMinMax)
        {         
            while (ifcItem != null)
            {
                if (ifcItem.verticesCount != 0)
                {
                    if (InitMinMax == false)
                    {
                        min.X = ifcItem.vertices[3 * 0 + 0];
                        min.Y = ifcItem.vertices[3 * 0 + 1];
                        min.Z = ifcItem.vertices[3 * 0 + 2];
                        max = min;

                        InitMinMax = true;
                    }

                    int_t i = 0;
                    while (i < ifcItem.verticesCount)
                    {

                        min.X = Math.Min(min.X, ifcItem.vertices[6 * i + 0]);
                        min.Y = Math.Min(min.Y, ifcItem.vertices[6 * i + 1]);
                        min.Z = Math.Min(min.Z, ifcItem.vertices[6 * i + 2]);

                        max.X = Math.Max(max.X, ifcItem.vertices[6 * i + 0]);
                        max.Y = Math.Max(max.Y, ifcItem.vertices[6 * i + 1]);
                        max.Z = Math.Max(max.Z, ifcItem.vertices[6 * i + 2]);

                        i++;
                    }
                }

                GetDimensions(ifcItem.child, ref min, ref max, ref InitMinMax);

                ifcItem = ifcItem.next; 
            }
        }
  
        /// <summary>
        /// Initializes the vertex and indices buffers
        /// </summary>
        private void InitalizeDeviceBuffer()
        {
            ReleaseMemory();

            Vector3 min = new Vector3();
            Vector3 max = new Vector3();

            bool InitMinMax = false;
            GetDimensions(_model.Root, ref min, ref max, ref InitMinMax);

            //Vector3 center = new Vector3();
            _center = new Vector3();
            _center.X = (max.X + min.X) / 2f;
            _center.Y = (max.Y + min.Y) / 2f;
            _center.Z = (max.Z + min.Z) / 2f;

            //float 
            _size = max.X - min.X;

            if (_size < max.Y - min.Y) _size = max.Y - min.Y;
            if (_size < max.Z - min.Z) _size = max.Z - min.Z;

            /*
             * Faces
             */
            int_t iVertexBuffSize = 0;
            int_t iIndexBuffSize = 0;
            GetBufferSizesFaces(_model.Root, ref iVertexBuffSize, ref iIndexBuffSize);

            if ((iVertexBuffSize > 0) && (iIndexBuffSize > 0))
            {
                _vertexBuffer = new VertexBuffer(_device, Utilities.SizeOf<Vector3>() * 2 * (int)iVertexBuffSize, Usage.WriteOnly, VertexFormat.None, Pool.Managed);

                DataStream verticesDataStream = _vertexBuffer.Lock(0, 0, LockFlags.None);

                _facesIndexBuffer = new IndexBuffer(_device, Utilities.SizeOf<int>() * (int)iIndexBuffSize, Usage.WriteOnly, Pool.Managed, false);

                DataStream facesIndicesDataStream = _facesIndexBuffer.Lock(0, 0, LockFlags.None);

                iCurrentPosVertextBuffer = 0;
                _iCurrentPosIndexBuffer = 0;

                FillVertexBuffer(verticesDataStream, _center, _size);

                Debug.Assert(iCurrentPosVertextBuffer == iVertexBuffSize);

                int_t iIndexOffsetForFaces = 0;
                foreach (Material material in _model.MaterailsBuilder.Materials)
                {
                    FillFacesIndexBuffer(facesIndicesDataStream, ref iIndexOffsetForFaces, material);
                }

//                Debug.Assert(iIndexOffsetForFaces == iIndexBuffSize);
                Debug.Assert(iIndexOffsetForFaces <= iIndexBuffSize);

                _facesIndexBuffer.Unlock();
                _vertexBuffer.Unlock();
            } // if ((iVertexBuffSize > 0) && ...

            /*
            * Wireframes
            */
            iVertexBuffSize = 0;
            iIndexBuffSize = 0;
            GetBufferSizesWireFrame(_model.Root, ref iVertexBuffSize, ref iIndexBuffSize);

            if ((iVertexBuffSize > 0) && (iIndexBuffSize > 0))
            {
                _wireframesIndexBuffer = new IndexBuffer(_device, Utilities.SizeOf<int>() * (int)iIndexBuffSize, Usage.WriteOnly, Pool.Managed, false);

                DataStream wireframesIndicesDataStream = _wireframesIndexBuffer.Lock(0, 0, LockFlags.None);

                iCurrentPosVertextBuffer = 0;
                _iCurrentPosIndexBuffer = 0;

                FillWireframesIndexBuffer(wireframesIndicesDataStream);

//                Debug.Assert(iCurrentPosVertextBuffer == iVertexBuffSize);
                Debug.Assert(_iCurrentPosIndexBuffer == iIndexBuffSize);

                _wireframesIndexBuffer.Unlock();
            } // if ((iVertexBuffSize > 0) && ...          
        }

        /// <summary>
        /// ?
        /// </summary>
        /// <param name="item"></param>
        /// <param name="pVBuffSize"></param>
        /// <param name="pIBuffSize"></param>
        private void GetBufferSizesFaces(IFCItem item, ref int_t pVBuffSize, ref int_t pIBuffSize)
        {
            while( item != null )
            {
                if (item.instance != 0 && item.verticesCount != 0 && item.TrianglesCount != 0)
                {
                    item.vertexOffsetForFaces = pVBuffSize;
                    item.indexOffsetForFaces = pIBuffSize;

                    pVBuffSize += item.verticesCount;
                    pIBuffSize += 3 * item.TrianglesCount;
                }

                GetBufferSizesFaces(item.child, ref pVBuffSize, ref pIBuffSize);

                item = item.next;
            }
        }

        /// <summary>
        /// ?
        /// </summary>
        /// <param name="item"></param>
        /// <param name="pVBuffSize"></param>
        /// <param name="pIBuffSize"></param>
        private void GetBufferSizesWireFrame(IFCItem item, ref int_t pVBuffSize, ref int_t pIBuffSize)
        {
            while (item != null)
            {
                if (item.instance != 0 && item.verticesCount != 0 && item.LinesCount != 0)
                {
                    item.vertexOffsetForWireFrame = pVBuffSize;
                    item.indexOffsetForWireFrame = pIBuffSize;

                    pVBuffSize += item.verticesCount;
                    pIBuffSize += 2 * item.LinesCount;
                }

                GetBufferSizesWireFrame(item.child, ref pVBuffSize, ref pIBuffSize);

                item = item.next;
            }
        }

        /// <summary>
        /// Populates the vertex buffer (SharpDX data stream)
        /// </summary>
        /// <param name="verticesDataStream"></param>
        /// <param name="center"></param>
        /// <param name="size"></param>
        private void FillVertexBuffer(DataStream verticesDataStream, Vector3 center, float size)
        {
            foreach (var item in _model.Geometry)
            {
                if ((item.instance != 0) && (item.verticesCount != 0) && (item.TrianglesCount != 0))
                {
                    /*
                    * Vertices
                    */
                    if (item.vertices != null)
                    {
                        Vector3[] vertices = new Vector3[item.verticesCount * 2];

                        /*
                         * Scale and copy
                         */
                        int_t iVertex = 0;
                        for (int_t i = 0; i < item.verticesCount; i++)
                        {
                            vertices[iVertex].X = (item.vertices[6 * i + 0] - center.X) / size;
                            vertices[iVertex].Y = (item.vertices[6 * i + 1] - center.Y) / size;
                            vertices[iVertex].Z = (item.vertices[6 * i + 2] - center.Z) / size;
                            vertices[iVertex + 1].X = item.vertices[6 * i + 3];
                            vertices[iVertex + 1].Y = item.vertices[6 * i + 4];
                            vertices[iVertex + 1].Z = item.vertices[6 * i + 5];

                            iVertex += 2;
                        }

                        Debug.Assert(item.vertices.Length == item.verticesCount * 6);

                        /*
                         * Write
                         */
                        verticesDataStream.WriteRange(vertices);
                    }

                    Debug.Assert(iCurrentPosVertextBuffer == item.vertexOffsetForFaces);

                    iCurrentPosVertextBuffer += item.verticesCount;
                } // if ((item.instance != 0) && ...
            } // foreach (var item in ...
        }

        /// <summary>
        /// Populates the index buffer for the wireframes (SharpDX data stream)
        /// </summary>
        /// <param name="indicesDataStream"></param>
        private void FillWireframesIndexBuffer(DataStream indicesDataStream)
        {
            foreach (var item in _model.Geometry)
            {
                /*
                * Indices
                */

                int i = 0;
                while (i < item.LinesCount)
                {
                    indicesDataStream.Write<int>(item.indicesForWireFrameLineParts[2 * i + 0] + (int)item.vertexOffsetForWireFrame);
                    indicesDataStream.Write<int>(item.indicesForWireFrameLineParts[2 * i + 1] + (int)item.vertexOffsetForWireFrame);

                    i++;
                }

//                Debug.Assert(item.vertexOffsetForWireFrame == iCurrentPosVertextBuffer);
                Debug.Assert(item.indexOffsetForWireFrame == _iCurrentPosIndexBuffer);

                iCurrentPosVertextBuffer += item.verticesCount;
                _iCurrentPosIndexBuffer += 2 * item.LinesCount;
            } // foreach (var item in ...
        }
        
        /// <summary>
        /// Populates the index buffer for the faces (SharpDX data stream)
        /// </summary>
        /// <param name="indicesDataStream"></param>
        /// <param name="iIndexOffsetForFaces"></param>
        /// <param name="material"></param>
        private void FillFacesIndexBuffer(DataStream indicesDataStream, ref int_t iIndexOffsetForFaces, Material material)
        {
            foreach (var item in _model.Geometry)
            {
                /*
                * Indices
                */
                STRUCT_MATERIALS materials = item.materials;
                while (materials != null)
                {
                    if (materials.material.MTRL.Equals(material))
                    {
                        int i = 0;
                        while (i < materials.__noPrimitivesForFaces)
                        {
                            indicesDataStream.Write<int>(item.indicesForFaces[3 * i + materials.__indexArrayOffset + 0] + (int)item.vertexOffsetForFaces);
                            indicesDataStream.Write<int>(item.indicesForFaces[3 * i + materials.__indexArrayOffset + 1] + (int)item.vertexOffsetForFaces);
                            indicesDataStream.Write<int>(item.indicesForFaces[3 * i + materials.__indexArrayOffset + 2] + (int)item.vertexOffsetForFaces);

                            i++;
                        }

                        materials.__indexOffsetForFaces = iIndexOffsetForFaces;
                        System.Diagnostics.Debug.Assert(materials.__indexOffsetForFaces == iIndexOffsetForFaces);

                        iIndexOffsetForFaces += 3 * materials.__noPrimitivesForFaces;
                    }

                    materials = materials.next;
                } // while (materials != null)
            } // foreach (var item in ...
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="bTransparent"></param>
        private void RenderFaces(bool bTransparent)
        {
            if (_model.MaterailsBuilder == null)
            {
                return;
            }

            for (int iMaterial = 0; iMaterial < _model.MaterailsBuilder.Materials.Count; iMaterial++)
            {
                Material material = _model.MaterailsBuilder.Materials[iMaterial];

                if (bTransparent)
                {
                    if (material.Ambient.A == 1.0F)
                    {
                        continue;
                    }
                }
                else
                {
                    if (material.Ambient.A < 1.0F)
                    {
                        continue;
                    }
                }                

                _device.Material = material;

                var facesGroup = _model.FacesGroups[material];

                bool bPendingDraw = false;
                int iVertexOffsetForFaces = -1;
                int iVerticesCount = -1;
                int iIndexOffsetForFaces = -1;
                int iTrianglesCount = -1;

                for (int iItem = 0; iItem < facesGroup.Count; iItem++)
                {
                    IFCItem ifcItem = facesGroup[iItem].Key;
                    STRUCT_MATERIALS materials = facesGroup[iItem].Value;

                    if ((ifcItem == _selectedIfcItem) || !ifcItem.ifcTreeView.IsVisible)
                    {
                        _device.DrawIndexedPrimitive(
                                PrimitiveType.TriangleList,
                                0,
                                iVertexOffsetForFaces,
                                iVerticesCount,
                                iIndexOffsetForFaces,
                                iTrianglesCount);

                        bPendingDraw = false;

                        continue;
                    }

                    if (bPendingDraw)
                    {
                        if ((iTrianglesCount + (int)ifcItem.TrianglesCount) >= 65535)
                        {
                            _device.DrawIndexedPrimitive(
                                PrimitiveType.TriangleList,
                                0,
                                iVertexOffsetForFaces,
                                iVerticesCount,
                                iIndexOffsetForFaces,
                                iTrianglesCount);

                            iVertexOffsetForFaces = (int)ifcItem.vertexOffsetForFaces;
                            iVerticesCount = (int)ifcItem.verticesCount;
                            iIndexOffsetForFaces = (int)facesGroup[iItem].Value.__indexOffsetForFaces;
                            iTrianglesCount = (int)facesGroup[iItem].Value.__noPrimitivesForFaces;

                            continue;
                        }

                        if ((iIndexOffsetForFaces + (3 * iTrianglesCount)) == materials.__indexOffsetForFaces)
                        {
                            if (ifcItem.vertexOffsetForFaces < iVertexOffsetForFaces)
                            {
                                System.Diagnostics.Debug.Assert(iVertexOffsetForFaces - ifcItem.vertexOffsetForFaces >= 0);

                                iVerticesCount += iVertexOffsetForFaces - (int)ifcItem.vertexOffsetForFaces;
                                if (iVerticesCount < ifcItem.verticesCount)
                                {
                                    iVerticesCount = (int)ifcItem.verticesCount;
                                }

                                iVertexOffsetForFaces = (int)ifcItem.vertexOffsetForFaces;
                            }
                            else
                            {
                                System.Diagnostics.Debug.Assert(ifcItem.vertexOffsetForFaces - iVertexOffsetForFaces >= 0);

                                if (iVerticesCount < ifcItem.verticesCount + ifcItem.vertexOffsetForFaces - iVertexOffsetForFaces)
                                {
                                    iVerticesCount = (int)ifcItem.verticesCount + (int)ifcItem.vertexOffsetForFaces - iVertexOffsetForFaces;
                                }
                            }

                            iTrianglesCount += (int)materials.__noPrimitivesForFaces;
                        } // if ((iIndexOffsetForFaces + ...
                        else
                        {
                            _device.DrawIndexedPrimitive(
                                PrimitiveType.TriangleList,
                                0,
                                iVertexOffsetForFaces,
                                iVerticesCount,
                                iIndexOffsetForFaces,
                                iTrianglesCount);

                            bPendingDraw = false;
                        } // else if ((iIndexOffsetForFaces + ...
                    } // if (bPendingDraw)
                    else
                    {
                        bPendingDraw = true;
                        iVertexOffsetForFaces = (int)ifcItem.vertexOffsetForFaces;
                        iVerticesCount = (int)ifcItem.verticesCount;
                        iIndexOffsetForFaces = (int)facesGroup[iItem].Value.__indexOffsetForFaces;
                        iTrianglesCount = (int)facesGroup[iItem].Value.__noPrimitivesForFaces;
                    } // else if (bPendingDraw)
                } // for (int iItem = ...

                if (bPendingDraw)
                {
                    _device.DrawIndexedPrimitive(
                        PrimitiveType.TriangleList,
                        0,
                        iVertexOffsetForFaces,
                        iVerticesCount,
                        iIndexOffsetForFaces,
                        iTrianglesCount);
                } // if (bPendingDraw)
            } // for (int iMaterial = ...
        }

        /// <summary>
        /// Helper
        /// </summary>
        private void RenderWireframes()
        {
            _device.Material = _mtrlBlack;

            bool bPendingDraw = false;
            int iVertexOffsetForWireframes = -1;
            int iVerticesCount = -1;
            int iIndexOffsetForWireframe = -1;
            int iLinesCount = -1;

            foreach (var ifcItem in _model.Geometry)
            {
                if (!ifcItem.ifcTreeView.IsVisible)
                {
                    _device.DrawIndexedPrimitive(
                            PrimitiveType.LineList,
                            0,
                            iVertexOffsetForWireframes,
                            iVerticesCount,
                            iIndexOffsetForWireframe,
                            iLinesCount);

                    bPendingDraw = false;

                    continue;
                }

                if (bPendingDraw)
                {
                    if ((iLinesCount + (int)ifcItem.LinesCount) >= 65535)
                    {
                        _device.DrawIndexedPrimitive(
                            PrimitiveType.LineList,
                            0,
                            iVertexOffsetForWireframes,
                            iVerticesCount,
                            iIndexOffsetForWireframe,
                            iLinesCount);

                        iVertexOffsetForWireframes = (int)ifcItem.vertexOffsetForWireFrame;
                        iVerticesCount = (int)ifcItem.verticesCount;
                        iIndexOffsetForWireframe = (int)ifcItem.indexOffsetForWireFrame;
                        iLinesCount = (int)ifcItem.LinesCount;

                        continue;
                    }

                    if ((iIndexOffsetForWireframe + (2 * iLinesCount)) == ifcItem.indexOffsetForWireFrame)
                    {
                        if (ifcItem.vertexOffsetForWireFrame < iVertexOffsetForWireframes)
                        {
                            System.Diagnostics.Debug.Assert(iVertexOffsetForWireframes - ifcItem.vertexOffsetForWireFrame >= 0);

                            iVerticesCount += iVertexOffsetForWireframes - (int)ifcItem.vertexOffsetForWireFrame;
                            if (iVerticesCount < ifcItem.verticesCount)
                            {
                                iVerticesCount = (int)ifcItem.verticesCount;
                            }

                            iVertexOffsetForWireframes = (int)ifcItem.vertexOffsetForWireFrame;
                        }
                        else
                        {
                            System.Diagnostics.Debug.Assert(ifcItem.vertexOffsetForWireFrame - iVertexOffsetForWireframes >= 0);

                            if (iVerticesCount < ifcItem.verticesCount + ifcItem.vertexOffsetForWireFrame - iVertexOffsetForWireframes)
                            {
                                iVerticesCount = (int)ifcItem.verticesCount + (int)ifcItem.vertexOffsetForWireFrame - iVertexOffsetForWireframes;
                            }
                        }

                        iLinesCount += ifcItem.LinesCount;
                    } // if ((iIndexOffsetForFaces + ...
                    else
                    {
                        _device.DrawIndexedPrimitive(
                            PrimitiveType.LineList,
                            0,
                            iVertexOffsetForWireframes,
                            iVerticesCount,
                            iIndexOffsetForWireframe,
                            iLinesCount);

                        bPendingDraw = false;
                    } // else if ((iIndexOffsetForFaces + ...
                } // if (bPendingDraw)
                else
                {
                    bPendingDraw = true;
                    iVertexOffsetForWireframes = (int)ifcItem.vertexOffsetForWireFrame;
                    iVerticesCount = (int)ifcItem.verticesCount;
                    iIndexOffsetForWireframe = (int)ifcItem.indexOffsetForWireFrame;
                    iLinesCount = (int)ifcItem.LinesCount;
                } // else if (bPendingDraw)
            } // foreach (var item in ...

            if (bPendingDraw)
            {
                _device.DrawIndexedPrimitive(
                    PrimitiveType.LineList,
                    0,
                    iVertexOffsetForWireframes,
                    iVerticesCount,
                    iIndexOffsetForWireframe,
                    iLinesCount);
            } // if (bPendingDraw)
        }

        /// <summary>
        /// Release all unmanaged resources
        /// </summary>
        private void ReleaseMemory()
        {
            if (_vertexBuffer != null)
            {
                _vertexBuffer.Dispose();
                _vertexBuffer = null;
            }

            if (_facesIndexBuffer != null)
            {
                _facesIndexBuffer.Dispose();
                _facesIndexBuffer = null;
            }

            if (_wireframesIndexBuffer != null)
            {
                _wireframesIndexBuffer.Dispose();
                _wireframesIndexBuffer = null;
            }
        }

        /// <summary>
        /// IIFCViewer => IDisposable
        /// </summary>
        public void Dispose()
        {
            ReleaseMemory();

            if (_direct3D != null)
            {
                _direct3D.Dispose();
                _direct3D = null;
            }
        }

        /// <summary>
        /// IIFCRenderer
        /// </summary>
        public IIFCViewer Viewer
        {
            get;
            set;
        }

        /// <summary>
        /// IIFCRenderer
        /// </summary>
        public bool ShowFaces
        {
            get
            {
                return _bShowFaces;
            }

            set
            {
                _bShowFaces = value;

                this.Redraw();
            }
        }

        /// <summary>
        /// IIFCRenderer
        /// </summary>
        public bool ShowWireframes
        {
            get
            {
                return _bShowWireframes;
            }

            set
            {
                _bShowWireframes = value;

                this.Redraw();
            }
        }

        /// <summary>
        /// Accessor
        /// </summary>
        public bool SelectOnMouseHover
        {
            get
            {
                return _bSelectOnMouseHover;

            }

            set
            {
                _bSelectOnMouseHover = value;

                this.Redraw();
            }
        }

        /// <summary>
        /// IIFCRenderer
        /// </summary>
        public void Reset()
        {
            roll_val = 0.0f;
            pitch_val = 0.0f;
            yaw_val = 45.0f;
            _zoomIndex = 0F;
            _currentMoveType = MOVE_TYPE.NONE;
            _fTranslateZ = 0;
            _fTranslateY = 0;

            this.Redraw();
        }

        /// <summary>
        /// IIFCRenderer
        /// </summary>
        public void Redraw()
        {
            /*
            * Light 
            */
            SetupLights();

            /*
             * Matrices 
             */
            SetupMatrices();

            /*
             * Initialize
             */
            _device.Clear(ClearFlags.Target | ClearFlags.ZBuffer, Color.White, 1.0f, 0);
            _device.BeginScene();

            if (_vertexBuffer != null)
            {
                /*
                * Vertices 
                */
                _device.SetStreamSource(0, _vertexBuffer, 0, Utilities.SizeOf<Vector3>() * 2);
                _device.VertexDeclaration = _vertexDeclaration;

                /*
                * Faces 
                */
                if (_facesIndexBuffer != null)
                {   
                    _device.Indices = _facesIndexBuffer;

                    /*
                     * Non-transparent Faces 
                     */
                    if (this.ShowFaces)
                    {
                        RenderFaces(false);
                    }

                    /*
                     * Transparent Faces 
                     */
                    if (this.ShowFaces)
                    {
                        _device.SetRenderState(RenderState.AlphaBlendEnable, true);
                        _device.SetRenderState(RenderState.SourceBlend, Blend.SourceAlpha);
                        _device.SetRenderState(RenderState.DestinationBlend, Blend.InverseSourceAlpha);

                        RenderFaces(true);

                        _device.SetRenderState(RenderState.AlphaBlendEnable, false);
                    }

                    /*
                     * Selected Face
                     */
                    if (this.ShowFaces && (_selectedIfcItem != null) && _selectedIfcItem.ifcTreeView.IsVisible)
                    {
                        _device.SetRenderState(RenderState.AlphaBlendEnable, true);
                        _device.SetRenderState(RenderState.SourceBlend, Blend.SourceAlpha);
                        _device.SetRenderState(RenderState.DestinationBlend, Blend.InverseSourceAlpha);

                        _device.Material = _mtrSelect;

                        STRUCT_MATERIALS materials = _selectedIfcItem.materials;
                        while (materials != null)
                        {
                            _device.DrawIndexedPrimitive(
                                PrimitiveType.TriangleList,
                                0,
                                (Int32)_selectedIfcItem.vertexOffsetForFaces,
                                (Int32)_selectedIfcItem.verticesCount,
                                (Int32)materials.__indexOffsetForFaces,
                                (Int32)materials.__noPrimitivesForFaces);

                            materials = materials.next;
                        } // while (materials != null) 

                        _device.SetRenderState(RenderState.AlphaBlendEnable, false);
                    }

                    /*
                     * Picked Face
                     */
                    if (_hoverIfcItem != null)
                    {
                        _device.Material = _mtrSelect;

                        STRUCT_MATERIALS materials = _hoverIfcItem.materials;
                        while (materials != null)
                        {
                            _device.DrawIndexedPrimitive(
                                PrimitiveType.TriangleList,
                                0,
                                (Int32)_hoverIfcItem.vertexOffsetForFaces,
                                (Int32)_hoverIfcItem.verticesCount,
                                (Int32)materials.__indexOffsetForFaces,
                                (Int32)materials.__noPrimitivesForFaces);

                            materials = materials.next;
                        } // while (materials != null) 
                    }
                } // if (_facesIndexBuffer != null)

                /*
                * Wireframes 
                */
                if (_wireframesIndexBuffer != null)
                {   
                    _device.Indices = _wireframesIndexBuffer;

                    if (this.ShowWireframes)
                    {
                        RenderWireframes();
                    }
                } // if (_wireframesIndexBuffer != null)
            } // if (_vertexBuffer != null)

            /*
             * End
             */
            _device.EndScene();
            _device.Present();
        }

        /// <summary>
        /// IIFCRenderer
        /// </summary>
        public void OnSelect(IFCItem ifcItem)
        {
            _selectedIfcItem = ifcItem;

            /*
             * Zoom to item
             */
            if ((_selectedIfcItem != null) && (_selectedIfcItem.verticesCount > 0))
            {
                Vector3 min = new Vector3(float.MaxValue, float.MaxValue, float.MaxValue);
                Vector3 max = new Vector3(-float.MaxValue, -float.MaxValue, -float.MaxValue);

                int_t iVertex = 0;
                while (iVertex < ifcItem.verticesCount)
                {
                    min.X = Math.Min(min.X, (_selectedIfcItem.vertices[6 * iVertex + 0] - _center.X) / _size);
                    min.Y = Math.Min(min.Y, (_selectedIfcItem.vertices[6 * iVertex + 1] - _center.Y) / _size);
                    min.Z = Math.Min(min.Z, (_selectedIfcItem.vertices[6 * iVertex + 2] - _center.Z) / _size);

                    max.X = Math.Max(max.X, (_selectedIfcItem.vertices[6 * iVertex + 0] - _center.X) / _size);
                    max.Y = Math.Max(max.Y, (_selectedIfcItem.vertices[6 * iVertex + 1] - _center.Y) / _size);
                    max.Z = Math.Max(max.Z, (_selectedIfcItem.vertices[6 * iVertex + 2] - _center.Z) / _size);

                    iVertex++;
                } // while (iVertex < ...

                float fMaxDistance = max.X - min.X;
                fMaxDistance = Math.Max(fMaxDistance, max.Y - min.Y);
                fMaxDistance = Math.Max(fMaxDistance, max.Z - min.Z);

                /*
                 * Transform
                 */
                if ((roll_val != 0) || (pitch_val != 0) || (yaw_val != 0))
                {
                    Matrix rotationMatrix = Matrix.RotationYawPitchRoll(
                        MathUtil.DegreesToRadians(roll_val),
                        MathUtil.DegreesToRadians(pitch_val),
                        MathUtil.DegreesToRadians(yaw_val));

                    rotationMatrix.Invert();

                    Vector3.Transform(ref max, ref rotationMatrix, out max);
                    Vector3.Transform(ref min, ref rotationMatrix, out min);
                }                

                /*
                 * Reset
                 */
                _fTranslateY = (max.Y + min.Y) / 2f;
                _fTranslateZ = -(max.Z + min.Z) / 2f;
            } // if ((_selectedIfcItem != null) && ...

            this.Redraw();
        }

        /// <summary>
        /// IIFCRenderer
        /// </summary>
        public void SaveToFile(string strFile, ImageFileFormat imageFileFormat)
        {
            Surface.ToFile(_device.GetRenderTarget(0), strFile, imageFileFormat);
        }
    }
}
